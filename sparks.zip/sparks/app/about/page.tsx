import { Award, Globe2, Target, Users } from "lucide-react";
import {
  Breadcrumbs,
  Container,
  Section,
  SectionHeading,
} from "@/components/ui/primitives";
import { ButtonLink } from "@/components/ui/Button";
import { buildMetadata } from "@/lib/seo";
import { certifications, company, markets, trustMetrics } from "@/lib/site";

export const metadata = buildMetadata({
  title: "About Sparks Chemicals — East Africa's Chemical Supply Partner",
  description:
    "Sparks Chemicals supplies certified industrial, laboratory, food and water treatment chemicals across East Africa — combining global sourcing with local technical expertise from Nairobi.",
  path: "/about",
  keywords: [
    "about Sparks Chemicals",
    "chemical company Kenya",
    "ISO certified chemical supplier East Africa",
  ],
});

const VALUES = [
  {
    icon: Target,
    title: "Specification before sale",
    body: "We would rather talk you out of the wrong product than book the order. Our engineers size dosing and verify compatibility before quoting.",
  },
  {
    icon: Award,
    title: "Quality that is provable",
    body: "Every consignment is batch-tested with a certificate of analysis, and we retain samples so claims can always be verified against the record.",
  },
  {
    icon: Globe2,
    title: "Global sourcing, local accountability",
    body: "Direct manufacturer relationships across Asia, the Gulf and Europe — but a Nairobi team that answers the phone when something goes wrong.",
  },
  {
    icon: Users,
    title: "Built for how the region trades",
    body: "Bonded transit paperwork, flexible packaging and payment terms that reflect how East African manufacturers actually operate.",
  },
];

export default function AboutPage() {
  const crumbs = [
    { label: "Home", href: "/" },
    { label: "About", href: "/about" },
  ];

  return (
    <div className="pt-32">
      <Container>
        <Breadcrumbs items={crumbs} className="mb-6" />

        <header className="max-w-3xl">
          <h1 className="text-4xl font-extrabold tracking-tight sm:text-5xl lg:text-6xl">
            The chemical partner East African industry was missing
          </h1>
          <p className="mt-6 text-base leading-relaxed text-fg-muted sm:text-lg">
            {company.description}
          </p>
        </header>
      </Container>

      {/* Metrics */}
      <Section>
        <Container>
          <dl className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {trustMetrics.map((metric) => (
              <div
                key={metric.label}
                className="rounded-2xl border border-border-base bg-surface p-7"
              >
                <dt className="sr-only">{metric.label}</dt>
                <dd>
                  <span className="block font-mono text-3xl font-extrabold tracking-tight text-fg">
                    {metric.value}
                  </span>
                  <span className="mt-2 block text-sm leading-relaxed text-fg-muted">
                    {metric.label}
                  </span>
                </dd>
              </div>
            ))}
          </dl>
        </Container>
      </Section>

      {/* Story */}
      <Section className="border-y border-border-base bg-surface-2/40">
        <Container>
          <div className="grid gap-12 lg:grid-cols-2 lg:gap-20">
            <SectionHeading
              eyebrow="Our story"
              title="Founded to fix a supply chain that kept failing"
            />
            <div className="flex flex-col gap-5 text-base leading-relaxed text-fg-muted">
              <p>
                Sparks Chemicals began in {company.foundingYear} after a decade
                of watching East African manufacturers struggle with the same
                three problems: opaque pricing, unverifiable quality, and
                consignments stuck at the border on paperwork nobody had
                prepared properly.
              </p>
              <p>
                We built the company around removing those failure points. That
                meant sourcing directly from manufacturers rather than through
                layers of traders, running our own testing and repacking
                operation in Nairobi, and employing chemical engineers on the
                sales desk rather than salespeople with a price list.
              </p>
              <p>
                Today we supply water utilities, food processors, mines,
                hospitals, universities and manufacturers across{" "}
                {markets.length} markets — and the technology behind this
                catalogue exists so that finding the right chemical takes
                seconds rather than a week of phone calls.
              </p>
            </div>
          </div>
        </Container>
      </Section>

      {/* Values */}
      <Section>
        <Container>
          <SectionHeading
            eyebrow="How we operate"
            title="Four commitments we hold ourselves to"
            align="center"
            className="mx-auto items-center"
          />
          <ul className="mt-14 grid gap-5 md:grid-cols-2">
            {VALUES.map((value) => (
              <li
                key={value.title}
                className="rounded-2xl border border-border-base bg-surface p-7"
              >
                <span className="mb-5 flex size-11 items-center justify-center rounded-xl bg-spark-50 text-spark-600 dark:bg-spark-500/12 dark:text-spark-400">
                  <value.icon aria-hidden className="size-5" />
                </span>
                <h3 className="text-base font-bold text-fg">{value.title}</h3>
                <p className="mt-2.5 text-sm leading-relaxed text-fg-muted">
                  {value.body}
                </p>
              </li>
            ))}
          </ul>
        </Container>
      </Section>

      {/* Certifications */}
      <Section className="border-t border-border-base bg-surface-2/40">
        <Container>
          <SectionHeading
            eyebrow="Compliance"
            title="Accreditations and licences we hold"
            description="Chemical supply is a regulated business. These are the approvals that let us import, store, repack and distribute legally across the region."
          />
          <ul className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {certifications.map((cert) => (
              <li
                key={cert.name}
                className="flex items-start gap-3.5 rounded-2xl border border-border-base bg-surface p-6"
              >
                <Award
                  aria-hidden
                  className="mt-0.5 size-5 shrink-0 text-spark-600 dark:text-spark-400"
                />
                <div>
                  <h3 className="text-sm font-bold text-fg">{cert.name}</h3>
                  <p className="mt-1 text-xs leading-relaxed text-fg-muted">
                    {cert.detail}
                  </p>
                </div>
              </li>
            ))}
          </ul>

          <div className="mt-12 flex flex-wrap gap-3">
            <ButtonLink href="/contact" variant="accent">
              Talk to our team
            </ButtonLink>
            <ButtonLink href="/products" variant="outline">
              Browse the catalogue
            </ButtonLink>
          </div>
        </Container>
      </Section>
    </div>
  );
}
