import { notFound } from "next/navigation";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import {
  Badge,
  Breadcrumbs,
  Container,
  JsonLd,
  Section,
} from "@/components/ui/primitives";
import { Markdown } from "@/components/blog/Markdown";
import { ButtonLink } from "@/components/ui/Button";
import { fetchArticleBySlug, fetchArticles, fetchChemicals } from "@/lib/api";
import { articleSchema, buildMetadata } from "@/lib/seo";
import { formatDate, truncate } from "@/lib/utils";

export async function generateStaticParams() {
  const articles = await fetchArticles();
  return articles.map((article) => ({ slug: article.slug }));
}

export async function generateMetadata({ params }: PageProps<"/blog/[slug]">) {
  const { slug } = await params;
  const article = await fetchArticleBySlug(slug);

  if (!article) {
    return buildMetadata({
      title: "Article not found",
      description: "This article is no longer available.",
      path: `/blog/${slug}`,
      noIndex: true,
    });
  }

  return buildMetadata({
    title: article.title,
    description: truncate(article.summary, 158),
    path: `/blog/${article.slug}`,
    image: article.image_url,
    type: "article",
    publishedTime: article.published_at,
    authors: [article.author],
    keywords: article.category_name
      ? [article.category_name, "chemical guidance Kenya", article.title]
      : undefined,
  });
}

export default async function ArticlePage({
  params,
}: PageProps<"/blog/[slug]">) {
  const { slug } = await params;
  const article = await fetchArticleBySlug(slug);
  if (!article) notFound();

  const [allArticles, featuredChemicals] = await Promise.all([
    fetchArticles(),
    fetchChemicals({ featured: true }),
  ]);

  const more = allArticles.filter((a) => a.slug !== article.slug).slice(0, 3);

  const crumbs = [
    { label: "Home", href: "/" },
    { label: "Knowledge", href: "/blog" },
    { label: article.title, href: `/blog/${article.slug}` },
  ];

  return (
    <article className="pt-32">
      <Container>
        <Breadcrumbs items={crumbs} className="mb-6" />

        <div className="grid gap-14 lg:grid-cols-[minmax(0,1fr)_18rem] lg:gap-20">
          <div className="min-w-0">
            <header className="max-w-3xl">
              {article.category_name && (
                <Badge tone="accent">{article.category_name}</Badge>
              )}
              <h1 className="mt-5 text-3xl font-extrabold leading-tight tracking-tight sm:text-4xl lg:text-5xl">
                {article.title}
              </h1>
              <p className="mt-5 text-lg leading-relaxed text-fg-muted">
                {article.summary}
              </p>

              <div className="mt-7 flex flex-wrap items-center gap-x-3 gap-y-1.5 border-y border-border-base py-4 text-sm text-fg-subtle">
                <span className="font-semibold text-fg">{article.author}</span>
                <span aria-hidden>·</span>
                <span>{article.author_role}</span>
                <span aria-hidden>·</span>
                <time dateTime={article.published_at}>
                  {formatDate(article.published_at)}
                </time>
                <span aria-hidden>·</span>
                <span>{article.read_time_minutes} min read</span>
              </div>
            </header>

            <div className="mt-10 max-w-3xl">
              <Markdown content={article.content} />
            </div>

            <div className="mt-14 rounded-2xl border border-border-base bg-surface-2/60 p-8">
              <h2 className="text-lg font-bold text-fg">
                Need this chemistry for your plant?
              </h2>
              <p className="mt-2 max-w-xl text-sm leading-relaxed text-fg-muted">
                Our technical desk will size the dosing, recommend the grade and
                quote delivered pricing to your site.
              </p>
              <div className="mt-5 flex flex-wrap gap-3">
                <ButtonLink href="/quote" variant="accent">
                  Request a quotation
                </ButtonLink>
                <ButtonLink href="/products" variant="outline">
                  Browse the catalogue
                </ButtonLink>
              </div>
            </div>

            <Link
              href="/blog"
              className="mt-10 inline-flex items-center gap-2 text-sm font-semibold text-fg-muted transition-colors hover:text-spark-600 dark:hover:text-spark-400"
            >
              <ArrowLeft aria-hidden className="size-4" />
              Back to the knowledge centre
            </Link>
          </div>

          {/* Sidebar: related products keep editorial traffic flowing to the
              catalogue, which is where enquiries actually originate. */}
          <aside className="lg:sticky lg:top-32 lg:self-start">
            <h2 className="font-mono text-[0.65rem] font-semibold uppercase tracking-[0.16em] text-fg-subtle">
              Popular products
            </h2>
            <ul className="mt-4 flex flex-col gap-2.5">
              {featuredChemicals.slice(0, 5).map((chemical) => (
                <li key={chemical.slug}>
                  <Link
                    href={`/products/${chemical.slug}`}
                    className="block rounded-xl border border-border-base bg-surface p-3.5 transition-colors hover:border-spark-500/50"
                  >
                    <span className="line-clamp-2 text-sm font-semibold text-fg">
                      {chemical.name}
                    </span>
                    <span className="mt-1 block font-mono text-[0.68rem] text-fg-subtle">
                      CAS {chemical.cas_number}
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          </aside>
        </div>
      </Container>

      {more.length > 0 && (
        <Section className="mt-16 border-t border-border-base bg-surface-2/40">
          <Container>
            <h2 className="text-2xl font-bold tracking-tight">
              More from the knowledge centre
            </h2>
            <div className="mt-10 grid gap-5 md:grid-cols-3">
              {more.map((item) => (
                <Link
                  key={item.slug}
                  href={`/blog/${item.slug}`}
                  className="group flex flex-col rounded-2xl border border-border-base bg-surface p-6 lift"
                >
                  {item.category_name && (
                    <span className="font-mono text-[0.65rem] font-semibold uppercase tracking-[0.16em] text-spark-600 dark:text-spark-400">
                      {item.category_name}
                    </span>
                  )}
                  <h3 className="mt-3 text-base font-bold leading-snug text-fg group-hover:text-spark-700 dark:group-hover:text-spark-300">
                    {item.title}
                  </h3>
                  <p className="mt-2.5 line-clamp-2 text-sm leading-relaxed text-fg-muted">
                    {item.summary}
                  </p>
                </Link>
              ))}
            </div>
          </Container>
        </Section>
      )}

      <JsonLd data={articleSchema(article)} />
    </article>
  );
}
