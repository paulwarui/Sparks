import Link from "next/link";
import { BookOpen } from "lucide-react";
import {
  Badge,
  Breadcrumbs,
  Container,
  JsonLd,
  Section,
} from "@/components/ui/primitives";
import { ButtonLink } from "@/components/ui/Button";
import { fetchArticles } from "@/lib/api";
import { buildMetadata } from "@/lib/seo";
import { SITE_URL } from "@/lib/site";
import { formatDate } from "@/lib/utils";
import type { Article } from "@/lib/types";

export const metadata = buildMetadata({
  title: "Knowledge Centre — Chemical Safety, Guides & Industry Insight",
  description:
    "Technical guidance from the Sparks Chemicals engineering desk: chemical safety, water treatment, storage, regulations and buying guides for East African industry.",
  path: "/blog",
  keywords: [
    "chemical safety guide Kenya",
    "water treatment guide East Africa",
    "chemical storage regulations Kenya",
    "chemical buying guide",
  ],
});

export default async function BlogPage() {
  const articles = await fetchArticles();

  const crumbs = [
    { label: "Home", href: "/" },
    { label: "Knowledge", href: "/blog" },
  ];

  const [lead, ...rest] = articles;

  return (
    <div className="pt-32">
      <Container>
        <Breadcrumbs items={crumbs} className="mb-6" />

        <header className="max-w-3xl">
          <h1 className="text-4xl font-extrabold tracking-tight sm:text-5xl lg:text-6xl">
            Knowledge centre
          </h1>
          <p className="mt-5 text-base leading-relaxed text-fg-muted sm:text-lg">
            Practical guidance from the engineers who specify, handle and
            deliver these materials every day — written for the realities of
            operating in East Africa.
          </p>
        </header>
      </Container>

      <Section>
        <Container>
          {articles.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-border-strong px-8 py-16 text-center">
              <span className="mx-auto mb-5 flex size-14 items-center justify-center rounded-2xl bg-surface-2 text-fg-subtle">
                <BookOpen aria-hidden className="size-6" />
              </span>
              <h2 className="text-lg font-bold text-fg">
                Articles are being published shortly
              </h2>
              <p className="mx-auto mt-2.5 max-w-md text-sm leading-relaxed text-fg-muted">
                Our engineering team is preparing guidance on chemical safety,
                water treatment and storage compliance. In the meantime, our
                technical desk answers questions directly.
              </p>
              <ButtonLink href="/contact" variant="accent" className="mt-6">
                Ask our technical desk
              </ButtonLink>
            </div>
          ) : (
            <>
              {lead && <LeadArticle article={lead} />}

              {rest.length > 0 && (
                <div className="mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
                  {rest.map((article) => (
                    <ArticleCard key={article.slug} article={article} />
                  ))}
                </div>
              )}
            </>
          )}
        </Container>
      </Section>

      {articles.length > 0 && (
        <JsonLd
          data={{
            "@context": "https://schema.org",
            "@type": "Blog",
            name: "Sparks Chemicals Knowledge Centre",
            url: `${SITE_URL}/blog`,
            publisher: { "@id": `${SITE_URL}/#organization` },
            blogPost: articles.slice(0, 20).map((article) => ({
              "@type": "BlogPosting",
              headline: article.title,
              url: `${SITE_URL}/blog/${article.slug}`,
              datePublished: article.published_at,
              author: { "@type": "Person", name: article.author },
            })),
          }}
        />
      )}
    </div>
  );
}

function LeadArticle({ article }: { article: Article }) {
  return (
    <Link
      href={`/blog/${article.slug}`}
      className="group grid gap-8 rounded-3xl border border-border-base bg-surface p-8 lift lg:grid-cols-[1.2fr_1fr] lg:p-10"
    >
      <div className="flex flex-col">
        <div className="flex flex-wrap items-center gap-2">
          <Badge tone="accent">Featured</Badge>
          {article.category_name && <Badge>{article.category_name}</Badge>}
        </div>
        <h2 className="mt-5 text-2xl font-bold leading-tight tracking-tight text-fg group-hover:text-spark-700 sm:text-3xl dark:group-hover:text-spark-300">
          {article.title}
        </h2>
        <p className="mt-4 flex-1 text-base leading-relaxed text-fg-muted">
          {article.summary}
        </p>
        <footer className="mt-6 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-fg-subtle">
          <span className="font-medium text-fg-muted">{article.author}</span>
          <span aria-hidden>·</span>
          <span>{article.author_role}</span>
          <span aria-hidden>·</span>
          <time dateTime={article.published_at}>
            {formatDate(article.published_at)}
          </time>
          <span aria-hidden>·</span>
          <span>{article.read_time_minutes} min read</span>
        </footer>
      </div>

      <div
        aria-hidden
        className="hidden items-center justify-center rounded-2xl bg-navy-900 p-10 lg:flex dark:bg-navy-950"
      >
        <div className="relative">
          <div className="absolute inset-0 rounded-full bg-spark-500/25 blur-3xl" />
          <BookOpen className="relative size-20 text-spark-400" />
        </div>
      </div>
    </Link>
  );
}

function ArticleCard({ article }: { article: Article }) {
  return (
    <Link
      href={`/blog/${article.slug}`}
      className="group flex flex-col rounded-2xl border border-border-base bg-surface p-6 lift"
    >
      {article.category_name && (
        <span className="font-mono text-[0.65rem] font-semibold uppercase tracking-[0.16em] text-spark-600 dark:text-spark-400">
          {article.category_name}
        </span>
      )}
      <h2 className="mt-3 text-base font-bold leading-snug text-fg group-hover:text-spark-700 dark:group-hover:text-spark-300">
        {article.title}
      </h2>
      <p className="mt-2.5 line-clamp-3 flex-1 text-sm leading-relaxed text-fg-muted">
        {article.summary}
      </p>
      <footer className="mt-5 flex items-center gap-2 text-xs text-fg-subtle">
        <time dateTime={article.published_at}>
          {formatDate(article.published_at)}
        </time>
        <span aria-hidden>·</span>
        <span>{article.read_time_minutes} min read</span>
      </footer>
    </Link>
  );
}
