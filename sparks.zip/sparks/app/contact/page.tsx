import {
  AlertTriangle,
  Clock,
  Mail,
  MapPin,
  MessageCircle,
  Phone,
} from "lucide-react";
import {
  Breadcrumbs,
  Container,
  JsonLd,
  Section,
} from "@/components/ui/primitives";
import { ContactForm } from "@/components/contact/ContactForm";
import { buildMetadata, localBusinessSchema } from "@/lib/seo";
import { contact } from "@/lib/site";

export const metadata = buildMetadata({
  title: "Contact Sparks Chemicals — Nairobi, Kenya",
  description:
    "Reach the Sparks Chemicals technical sales desk in Nairobi by phone, WhatsApp or email. Same-day quotations, 24/7 emergency chemical response across Kenya and East Africa.",
  path: "/contact",
  keywords: [
    "chemical supplier Nairobi contact",
    "buy chemicals Kenya phone",
    "chemical company Industrial Area Nairobi",
  ],
});

const CHANNELS = [
  {
    icon: Phone,
    label: "Call the sales desk",
    value: contact.phone,
    href: contact.phoneHref,
    note: "Mon–Fri 8am–6pm, Sat 8am–1pm",
  },
  {
    icon: MessageCircle,
    label: "WhatsApp",
    value: "Message us instantly",
    href: contact.whatsappHref,
    note: "Fastest response — usually under 10 minutes",
    external: true,
  },
  {
    icon: Mail,
    label: "Email",
    value: contact.email,
    href: contact.emailHref,
    note: "Quotations returned within 2 working hours",
  },
];

export default function ContactPage() {
  const crumbs = [
    { label: "Home", href: "/" },
    { label: "Contact", href: "/contact" },
  ];

  // Google Maps embed centred on the Industrial Area premises. Uses the
  // keyless embed endpoint so no API key is exposed client-side.
  const mapSrc = `https://www.google.com/maps?q=${contact.geo.latitude},${contact.geo.longitude}&hl=en&z=15&output=embed`;

  return (
    <div className="pt-32">
      <Container>
        <Breadcrumbs items={crumbs} className="mb-6" />

        <header className="max-w-3xl">
          <h1 className="text-4xl font-extrabold tracking-tight sm:text-5xl lg:text-6xl">
            Talk to our technical desk
          </h1>
          <p className="mt-5 text-base leading-relaxed text-fg-muted sm:text-lg">
            Real engineers, not a ticket queue. Tell us the chemical, the
            process or the problem — we&apos;ll come back with a specification
            and delivered pricing.
          </p>
        </header>
      </Container>

      <Section>
        <Container>
          <div className="grid gap-10 lg:grid-cols-[1fr_1.1fr] lg:gap-16">
            {/* Channels */}
            <div>
              <ul className="flex flex-col gap-3">
                {CHANNELS.map((channel) => (
                  <li key={channel.label}>
                    <a
                      href={channel.href}
                      {...(channel.external
                        ? { target: "_blank", rel: "noopener noreferrer" }
                        : {})}
                      className="flex items-start gap-4 rounded-2xl border border-border-base bg-surface p-5 transition-colors hover:border-spark-500/50"
                    >
                      <span className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-spark-50 text-spark-600 dark:bg-spark-500/12 dark:text-spark-400">
                        <channel.icon aria-hidden className="size-5" />
                      </span>
                      <span className="min-w-0">
                        <span className="block text-xs font-medium text-fg-subtle">
                          {channel.label}
                        </span>
                        <span className="mt-0.5 block text-base font-bold text-fg">
                          {channel.value}
                        </span>
                        <span className="mt-1 block text-xs text-fg-muted">
                          {channel.note}
                        </span>
                      </span>
                    </a>
                  </li>
                ))}
              </ul>

              {/* Emergency */}
              <div
                id="emergency"
                className="mt-5 scroll-mt-32 rounded-2xl border border-red-300/60 bg-red-50/70 p-5 dark:border-red-500/25 dark:bg-red-500/8"
              >
                <div className="flex items-start gap-3.5">
                  <AlertTriangle
                    aria-hidden
                    className="mt-0.5 size-5 shrink-0 text-red-600 dark:text-red-400"
                  />
                  <div>
                    <h2 className="text-sm font-bold text-red-900 dark:text-red-200">
                      Chemical emergency — 24/7
                    </h2>
                    <p className="mt-1.5 text-xs leading-relaxed text-red-900/80 dark:text-red-200/80">
                      Spill, exposure or transport incident involving a product
                      we supplied? Call immediately for handling guidance.
                    </p>
                    <a
                      href={contact.emergencyHref}
                      className="mt-2.5 inline-block font-mono text-base font-bold text-red-700 hover:underline dark:text-red-300"
                    >
                      {contact.emergency}
                    </a>
                  </div>
                </div>
              </div>

              {/* Address + hours */}
              <div
                id="technical"
                className="mt-5 scroll-mt-32 rounded-2xl border border-border-base bg-surface p-5"
              >
                <h2 className="flex items-center gap-2 text-sm font-bold text-fg">
                  <MapPin
                    aria-hidden
                    className="size-4 text-spark-600 dark:text-spark-400"
                  />
                  Head office &amp; warehouse
                </h2>
                <address className="mt-2.5 text-sm not-italic leading-relaxed text-fg-muted">
                  {contact.address.street}
                  <br />
                  {contact.address.locality} {contact.address.postalCode}
                  <br />
                  {contact.address.countryName}
                </address>

                <h3 className="mt-5 flex items-center gap-2 text-sm font-bold text-fg">
                  <Clock
                    aria-hidden
                    className="size-4 text-spark-600 dark:text-spark-400"
                  />
                  Opening hours
                </h3>
                <dl className="mt-2.5 flex flex-col gap-1.5 text-sm">
                  {contact.hours.map((entry) => (
                    <div
                      key={entry.days}
                      className="flex justify-between gap-4 text-fg-muted"
                    >
                      <dt>{entry.days}</dt>
                      <dd className="text-right font-medium text-fg">
                        {entry.time}
                      </dd>
                    </div>
                  ))}
                </dl>
              </div>
            </div>

            {/* Form */}
            <div>
              <ContactForm />
            </div>
          </div>
        </Container>
      </Section>

      {/* Map */}
      <Section className="pt-0">
        <Container>
          <div className="overflow-hidden rounded-2xl border border-border-base">
            <iframe
              src={mapSrc}
              title="Sparks Chemicals location on Google Maps — Enterprise Road, Industrial Area, Nairobi"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              className="h-[420px] w-full border-0"
            />
          </div>
        </Container>
      </Section>

      <JsonLd data={localBusinessSchema()} />
    </div>
  );
}
