"use client";

import { useEffect } from "react";
import { Container } from "@/components/ui/primitives";
import { Button, ButtonLink } from "@/components/ui/Button";
import { contact } from "@/lib/site";

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    // Surface the digest so a production incident can be traced in the logs.
    console.error("Application error:", error);
  }, [error]);

  return (
    <Container className="flex min-h-[70vh] flex-col items-center justify-center py-32 text-center">
      <p className="font-mono text-sm font-semibold uppercase tracking-[0.2em] text-spark-600 dark:text-spark-400">
        Unexpected error
      </p>
      <h1 className="mt-5 text-4xl font-extrabold tracking-tight sm:text-5xl">
        Something went wrong on our side
      </h1>
      <p className="mx-auto mt-5 max-w-md text-base leading-relaxed text-fg-muted">
        This one is on us. Try again, or reach our team directly — quotations
        never wait on a website.
      </p>
      {error.digest && (
        <p className="mt-3 font-mono text-xs text-fg-subtle">
          Reference: {error.digest}
        </p>
      )}
      <div className="mt-9 flex flex-wrap justify-center gap-3">
        <Button variant="accent" onClick={reset}>
          Try again
        </Button>
        <ButtonLink href={contact.whatsappHref} variant="outline">
          WhatsApp our team
        </ButtonLink>
      </div>
    </Container>
  );
}
