import { notFound } from "next/navigation";
import { AlertCircle, CheckCircle2 } from "lucide-react";
import {
  Breadcrumbs,
  Container,
  JsonLd,
  Section,
  SectionHeading,
} from "@/components/ui/primitives";
import { ChemicalCard } from "@/components/catalog/ChemicalCard";
import { ButtonLink } from "@/components/ui/Button";
import {
  fetchChemicals,
  fetchIndustries,
  fetchIndustryBySlug,
} from "@/lib/api";
import { buildMetadata, faqSchema } from "@/lib/seo";
import { SITE_URL, certifications } from "@/lib/site";
import { toBullets, truncate } from "@/lib/utils";

export async function generateStaticParams() {
  const industries = await fetchIndustries();
  return industries.map((industry) => ({ slug: industry.slug }));
}

export async function generateMetadata({
  params,
}: PageProps<"/industries/[slug]">) {
  const { slug } = await params;
  const industry = await fetchIndustryBySlug(slug);

  if (!industry) {
    return buildMetadata({
      title: "Industry not found",
      description: "This industry page is no longer available.",
      path: `/industries/${slug}`,
      noIndex: true,
    });
  }

  return buildMetadata({
    title: `${industry.name} Chemicals — Supplier in Kenya & East Africa`,
    description: truncate(
      `${industry.description} Sparks Chemicals supplies the ${industry.name.toLowerCase()} sector across Kenya, Uganda, Tanzania and Rwanda with certified products and technical support.`,
      158,
    ),
    path: `/industries/${industry.slug}`,
    keywords: [
      `${industry.name} chemicals`,
      `${industry.name} chemical supplier Kenya`,
      `${industry.name} chemicals East Africa`,
      "chemical supplier Nairobi",
    ],
  });
}

export default async function IndustryPage({
  params,
}: PageProps<"/industries/[slug]">) {
  const { slug } = await params;
  const industry = await fetchIndustryBySlug(slug);
  if (!industry) notFound();

  const [chemicals, allIndustries] = await Promise.all([
    fetchChemicals({ industry: industry.slug }),
    fetchIndustries(),
  ]);

  const challenges = toBullets(industry.key_challenges);
  const otherIndustries = allIndustries
    .filter((other) => other.slug !== industry.slug)
    .slice(0, 6);

  const crumbs = [
    { label: "Home", href: "/" },
    { label: "Industries", href: "/industries" },
    { label: industry.name, href: `/industries/${industry.slug}` },
  ];

  const faqs = [
    {
      question: `Which chemicals does Sparks supply to the ${industry.name.toLowerCase()} sector?`,
      answer:
        chemicals.length > 0
          ? `We stock ${chemicals.length} products for this sector, including ${chemicals
              .slice(0, 4)
              .map((c) => c.name)
              .join(", ")}. Each is supplied with a certificate of analysis and safety data sheet.`
          : `We source a full range of ${industry.name.toLowerCase()} chemicals to order, with certificates of analysis and safety data sheets supplied on every consignment.`,
    },
    {
      question: `Do you deliver ${industry.name.toLowerCase()} chemicals outside Nairobi?`,
      answer:
        "Yes. We dispatch same-day within Nairobi, next-day to Mombasa and Kisumu, and handle bonded transit documentation for Uganda, Tanzania, Rwanda, Burundi, South Sudan and Ethiopia.",
    },
    {
      question: "What compliance documentation do you provide?",
      answer: `Every consignment ships with a batch certificate of analysis, GHS-compliant safety data sheet and labelling. We hold ${certifications
        .slice(0, 3)
        .map((c) => c.name)
        .join(", ")} accreditations and prepare import documentation as required.`,
    },
  ];

  return (
    <div className="pt-32">
      {/* Hero */}
      <Container>
        <Breadcrumbs items={crumbs} className="mb-6" />
        <div className="relative isolate overflow-hidden rounded-3xl border border-border-base bg-navy-900 px-8 py-16 text-white sm:px-14 dark:bg-navy-950">
          <div aria-hidden className="absolute inset-0 -z-10 grid-bg opacity-40" />
          <div
            aria-hidden
            className="absolute -right-24 -top-24 -z-10 size-96 rounded-full bg-spark-500/20 blur-[110px]"
          />

          <p className="font-mono text-[0.7rem] font-semibold uppercase tracking-[0.2em] text-spark-400">
            Industry solutions
          </p>
          <h1 className="mt-4 max-w-3xl text-3xl font-extrabold leading-tight tracking-tight sm:text-5xl">
            {industry.hero_title || `${industry.name} chemicals`}
          </h1>
          <p className="mt-5 max-w-2xl text-base leading-relaxed text-navy-100/85 sm:text-lg">
            {industry.description}
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <ButtonLink href="/quote" variant="accent">
              Request a quotation
            </ButtonLink>
            <ButtonLink
              href={`/products?industry=${industry.slug}`}
              variant="outline"
              className="border-white/25 text-white hover:border-spark-400 hover:text-spark-300"
            >
              View all {industry.name.toLowerCase()} products
            </ButtonLink>
          </div>
        </div>
      </Container>

      {/* Challenges */}
      {challenges.length > 0 && (
        <Section>
          <Container>
            <SectionHeading
              eyebrow="The problem"
              title={`What makes ${industry.name.toLowerCase()} chemistry difficult`}
              description="These are the failure points we see most often in this sector — and what we do about them."
            />
            <ul className="mt-12 grid gap-4 md:grid-cols-2">
              {challenges.map((challenge) => (
                <li
                  key={challenge}
                  className="flex gap-3.5 rounded-2xl border border-border-base bg-surface p-6"
                >
                  <AlertCircle
                    aria-hidden
                    className="mt-0.5 size-5 shrink-0 text-amber-500"
                  />
                  <p className="text-sm leading-relaxed text-fg-muted">
                    {challenge}
                  </p>
                </li>
              ))}
            </ul>
          </Container>
        </Section>
      )}

      {/* Recommended products */}
      <Section className={challenges.length > 0 ? "pt-0" : undefined}>
        <Container>
          <SectionHeading
            eyebrow="Recommended products"
            title={`Chemicals we supply for ${industry.name.toLowerCase()}`}
            description="Held in stock with full specifications, certificates of analysis and safety data sheets."
          />

          {chemicals.length > 0 ? (
            <>
              <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                {chemicals.map((chemical) => (
                  <ChemicalCard key={chemical.slug} chemical={chemical} />
                ))}
              </div>
              <ButtonLink
                href={`/products?industry=${industry.slug}`}
                variant="outline"
                className="mt-10"
              >
                See all in the catalogue
              </ButtonLink>
            </>
          ) : (
            <div className="mt-10 rounded-2xl border border-dashed border-border-strong p-8">
              <p className="text-sm leading-relaxed text-fg-muted">
                We source {industry.name.toLowerCase()} chemicals to order
                through our global manufacturer network. Send us your
                specification and we will return availability, lead time and
                delivered pricing.
              </p>
              <ButtonLink href="/quote" variant="accent" className="mt-5">
                Request a sourcing quote
              </ButtonLink>
            </div>
          )}
        </Container>
      </Section>

      {/* Assurance */}
      <Section className="border-y border-border-base bg-surface-2/40">
        <Container>
          <div className="grid gap-12 lg:grid-cols-2">
            <div>
              <SectionHeading
                eyebrow="How we support you"
                title="Beyond supply"
              />
              <ul className="mt-8 flex flex-col gap-4">
                {[
                  "Dosing calculations and process troubleshooting from our technical desk",
                  "Substitute recommendations when a raw material is constrained or priced out",
                  "Batch retention samples so any consignment can be re-tested against its COA",
                  "Scheduled contract supply so your line never waits on a reorder",
                ].map((item) => (
                  <li key={item} className="flex gap-3">
                    <CheckCircle2
                      aria-hidden
                      className="mt-0.5 size-5 shrink-0 text-spark-600 dark:text-spark-400"
                    />
                    <span className="text-sm leading-relaxed text-fg-muted">
                      {item}
                    </span>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h2 className="text-xl font-bold tracking-tight">
                Common questions
              </h2>
              <div className="mt-6 flex flex-col gap-3">
                {faqs.map((faq) => (
                  <details
                    key={faq.question}
                    className="group rounded-xl border border-border-base bg-surface px-5 py-4"
                  >
                    <summary className="cursor-pointer list-none text-sm font-semibold text-fg marker:content-none">
                      <span className="flex items-center justify-between gap-4">
                        {faq.question}
                        <span
                          aria-hidden
                          className="shrink-0 text-lg leading-none text-spark-500 transition-transform group-open:rotate-45"
                        >
                          +
                        </span>
                      </span>
                    </summary>
                    <p className="mt-3 text-sm leading-relaxed text-fg-muted">
                      {faq.answer}
                    </p>
                  </details>
                ))}
              </div>
            </div>
          </div>
        </Container>
      </Section>

      {/* Cross-links to sibling industries */}
      <Section>
        <Container>
          <h2 className="text-xl font-bold tracking-tight">
            Other industries we serve
          </h2>
          <ul className="mt-6 flex flex-wrap gap-2.5">
            {otherIndustries.map((other) => (
              <li key={other.slug}>
                <ButtonLink
                  href={`/industries/${other.slug}`}
                  variant="outline"
                  size="sm"
                >
                  {other.name}
                </ButtonLink>
              </li>
            ))}
          </ul>
        </Container>
      </Section>

      <JsonLd data={faqSchema(faqs)} />
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "Service",
          name: `${industry.name} chemical supply`,
          serviceType: `${industry.name} chemicals`,
          provider: { "@id": `${SITE_URL}/#organization` },
          areaServed: [
            "Kenya",
            "Uganda",
            "Tanzania",
            "Rwanda",
            "Burundi",
            "South Sudan",
            "Ethiopia",
          ],
          description: industry.description,
          url: `${SITE_URL}/industries/${industry.slug}`,
        }}
      />
    </div>
  );
}
