import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import {
  Breadcrumbs,
  Container,
  JsonLd,
  Section,
} from "@/components/ui/primitives";
import { ButtonLink } from "@/components/ui/Button";
import { fetchIndustries } from "@/lib/api";
import { buildMetadata } from "@/lib/seo";
import { SITE_URL } from "@/lib/site";

export const metadata = buildMetadata({
  title: "Industries We Supply — Chemical Solutions by Sector",
  description:
    "From municipal water treatment to pharmaceutical manufacturing, Sparks Chemicals supplies sector-specific chemicals with the compliance documentation each industry requires across Kenya and East Africa.",
  path: "/industries",
  keywords: [
    "water treatment chemicals Kenya",
    "food grade chemicals supplier",
    "mining chemicals East Africa",
    "pharmaceutical excipients Kenya",
    "industrial chemical solutions",
  ],
});

export default async function IndustriesPage() {
  const industries = await fetchIndustries();

  const crumbs = [
    { label: "Home", href: "/" },
    { label: "Industries", href: "/industries" },
  ];

  return (
    <div className="pt-32">
      <Container>
        <Breadcrumbs items={crumbs} className="mb-6" />

        <header className="max-w-3xl">
          <h1 className="text-4xl font-extrabold tracking-tight sm:text-5xl lg:text-6xl">
            Chemistry, matched to your sector
          </h1>
          <p className="mt-5 text-base leading-relaxed text-fg-muted sm:text-lg">
            Every industry we serve has its own purity thresholds, regulatory
            regime and delivery constraints. Choose your sector to see the
            products we hold, the challenges we solve and the documentation we
            provide.
          </p>
        </header>
      </Container>

      <Section>
        <Container>
          <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
            {industries.map((industry) => (
              <Link
                key={industry.slug}
                href={`/industries/${industry.slug}`}
                className="group flex flex-col rounded-2xl border border-border-base bg-surface p-7 lift"
              >
                <div className="flex items-start justify-between gap-3">
                  <h2 className="text-lg font-bold leading-snug text-fg group-hover:text-spark-700 dark:group-hover:text-spark-300">
                    {industry.name}
                  </h2>
                  <ArrowUpRight
                    aria-hidden
                    className="size-4 shrink-0 text-fg-subtle transition-colors group-hover:text-spark-500"
                  />
                </div>
                <p className="mt-3 flex-1 text-sm leading-relaxed text-fg-muted">
                  {industry.description}
                </p>
                {typeof industry.chemical_count === "number" &&
                  industry.chemical_count > 0 && (
                    <p className="mt-6 font-mono text-[0.68rem] uppercase tracking-wider text-fg-subtle">
                      {industry.chemical_count} products stocked
                    </p>
                  )}
              </Link>
            ))}
          </div>
        </Container>
      </Section>

      <Section className="border-t border-border-base bg-surface-2/40">
        <Container>
          <div className="max-w-2xl">
            <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">
              Operating in a sector we haven&apos;t listed?
            </h2>
            <p className="mt-3 text-base leading-relaxed text-fg-muted">
              Our technical desk has supplied everything from geothermal well
              treatment to speciality printing inks. Tell us the process and
              we&apos;ll identify the right chemistry.
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <ButtonLink href="/contact" variant="accent">
                Talk to an engineer
              </ButtonLink>
              <ButtonLink href="/products" variant="outline">
                Browse all chemicals
              </ButtonLink>
            </div>
          </div>
        </Container>
      </Section>

      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "ItemList",
          name: "Industries served by Sparks Chemicals",
          itemListElement: industries.map((industry, index) => ({
            "@type": "ListItem",
            position: index + 1,
            name: industry.name,
            url: `${SITE_URL}/industries/${industry.slug}`,
          })),
        }}
      />
    </div>
  );
}
