import type { Metadata, Viewport } from "next";
import { Inter, JetBrains_Mono } from "next/font/google";
import "./globals.css";

import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { GlobalSearch } from "@/components/search/GlobalSearch";
import { QuoteDrawer } from "@/components/quote/QuoteDrawer";
import { AIAssistant } from "@/components/ai/AIAssistant";
import { ThemeProvider, themeInitScript } from "@/components/providers/ThemeProvider";
import { QuoteProvider } from "@/components/providers/QuoteProvider";
import { UIProvider } from "@/components/providers/UIProvider";
import { JsonLd } from "@/components/ui/primitives";
import { fetchIndustries } from "@/lib/api";
import { SITE_URL, company } from "@/lib/site";
import {
  localBusinessSchema,
  organizationSchema,
  websiteSchema,
} from "@/lib/seo";

const inter = Inter({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-inter",
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-mono-stack",
});

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default:
      "Sparks Chemicals | Leading Chemical Supplier in Kenya & East Africa",
    template: "%s | Sparks Chemicals",
  },
  description: company.description,
  applicationName: company.name,
  keywords: [
    "chemical supplier Kenya",
    "industrial chemicals Nairobi",
    "water treatment chemicals East Africa",
    "laboratory reagents Kenya",
    "food grade chemicals Kenya",
    "caustic soda Kenya",
    "sulphuric acid supplier",
    "chemical distributor Uganda Tanzania",
  ],
  authors: [{ name: company.legalName, url: SITE_URL }],
  creator: company.legalName,
  publisher: company.legalName,
  alternates: { canonical: SITE_URL },
  manifest: "/manifest.webmanifest",
  icons: {
    icon: [
      { url: "/icon-192.png", sizes: "192x192", type: "image/png" },
      { url: "/icon-512.png", sizes: "512x512", type: "image/png" },
    ],
    apple: "/apple-icon.png",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, "max-image-preview": "large" },
  },
  formatDetection: { telephone: true, address: true, email: true },
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#ffffff" },
    { media: "(prefers-color-scheme: dark)", color: "#00080f" },
  ],
  width: "device-width",
  initialScale: 1,
  colorScheme: "light dark",
};

export default async function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // Fetched once in the layout and shared by the header mega-menu, the search
  // palette and the footer, so navigation always reflects the live taxonomy.
  const industries = await fetchIndustries();

  return (
    <html lang="en-KE" suppressHydrationWarning>
      <head>
        {/* Applies the stored theme before first paint to avoid a flash. */}
        <script dangerouslySetInnerHTML={{ __html: themeInitScript }} />
      </head>
      <body
        className={`${inter.variable} ${jetbrainsMono.variable} flex min-h-screen flex-col`}
      >
        <a href="#main" className="sr-only-focusable">
          Skip to main content
        </a>

        <ThemeProvider>
          <UIProvider>
            <QuoteProvider>
              <Header industries={industries} />
              <main id="main" className="flex-1">
                {children}
              </main>
              <Footer industries={industries} />

              <GlobalSearch industries={industries} />
              <QuoteDrawer />
              <AIAssistant />
            </QuoteProvider>
          </UIProvider>
        </ThemeProvider>

        <JsonLd data={organizationSchema()} />
        <JsonLd data={localBusinessSchema()} />
        <JsonLd data={websiteSchema()} />
      </body>
    </html>
  );
}
