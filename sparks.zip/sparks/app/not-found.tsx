import { Container } from "@/components/ui/primitives";
import { ButtonLink } from "@/components/ui/Button";

export default function NotFound() {
  return (
    <Container className="flex min-h-[70vh] flex-col items-center justify-center py-32 text-center">
      <p className="font-mono text-sm font-semibold uppercase tracking-[0.2em] text-spark-600 dark:text-spark-400">
        Error 404
      </p>
      <h1 className="mt-5 text-4xl font-extrabold tracking-tight sm:text-5xl">
        This page has been decanted elsewhere
      </h1>
      <p className="mx-auto mt-5 max-w-md text-base leading-relaxed text-fg-muted">
        The page you were looking for doesn&apos;t exist. Try searching the
        catalogue by product name, CAS number or formula.
      </p>
      <div className="mt-9 flex flex-wrap justify-center gap-3">
        <ButtonLink href="/products" variant="accent">
          Browse chemicals
        </ButtonLink>
        <ButtonLink href="/" variant="outline">
          Back to home
        </ButtonLink>
      </div>
    </Container>
  );
}
