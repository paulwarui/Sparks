import { Hero } from "@/components/home/Hero";
import {
  Capabilities,
  ClosingCTA,
  FeaturedChemicals,
  IndustriesGrid,
  KnowledgeTeaser,
  ProcessSection,
  TrustBar,
} from "@/components/home/sections";
import { fetchArticles, fetchChemicals, fetchIndustries } from "@/lib/api";
import { buildMetadata } from "@/lib/seo";
import { company } from "@/lib/site";

export const metadata = buildMetadata({
  title:
    "Sparks Chemicals | Leading Chemical Supplier in Kenya & East Africa",
  description: company.description,
  path: "/",
});

export default async function HomePage() {
  // Fetched in parallel — these are independent and each is individually cached.
  const [featured, industries, articles] = await Promise.all([
    fetchChemicals({ featured: true }),
    fetchIndustries(),
    fetchArticles(),
  ]);

  return (
    <>
      <Hero />
      <TrustBar />
      <FeaturedChemicals chemicals={featured} />
      <IndustriesGrid industries={industries} />
      <Capabilities />
      <ProcessSection />
      <KnowledgeTeaser articles={articles} />
      <ClosingCTA />
    </>
  );
}
