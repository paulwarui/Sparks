import { notFound } from "next/navigation";
import Link from "next/link";
import {
  AlertTriangle,
  Beaker,
  BookOpen,
  Factory,
  PackageCheck,
  ShieldAlert,
  Thermometer,
} from "lucide-react";
import {
  Badge,
  Breadcrumbs,
  Container,
  Formula,
  JsonLd,
  Section,
} from "@/components/ui/primitives";
import { ProductQuoteCard } from "@/components/catalog/ProductQuoteCard";
import { ChemicalCard } from "@/components/catalog/ChemicalCard";
import { ButtonLink } from "@/components/ui/Button";
import {
  fetchChemicalBySlug,
  fetchChemicals,
  fetchIndustries,
  fetchRelatedChemicals,
} from "@/lib/api";
import { buildMetadata, chemicalFaqs, faqSchema, productSchema } from "@/lib/seo";
import { splitList, toBullets, truncate } from "@/lib/utils";

/** Pre-render every catalogue entry at build time for instant, indexable pages. */
export async function generateStaticParams() {
  const chemicals = await fetchChemicals();
  return chemicals.map((chemical) => ({ slug: chemical.slug }));
}

export async function generateMetadata({ params }: PageProps<"/products/[slug]">) {
  const { slug } = await params;
  const chemical = await fetchChemicalBySlug(slug);

  if (!chemical) {
    return buildMetadata({
      title: "Product not found",
      description: "This product is no longer listed in our catalogue.",
      path: `/products/${slug}`,
      noIndex: true,
    });
  }

  return buildMetadata({
    title: `${chemical.name} | CAS ${chemical.cas_number}`,
    description: truncate(
      `Buy ${chemical.name} (CAS ${chemical.cas_number}, ${chemical.chemical_formula}) in Kenya and East Africa. ${chemical.description}`,
      158,
    ),
    path: `/products/${chemical.slug}`,
    image: chemical.image_url,
    keywords: [
      chemical.name,
      `${chemical.name} Kenya`,
      `CAS ${chemical.cas_number}`,
      chemical.chemical_formula,
      ...splitList(chemical.synonyms),
      `${chemical.name} supplier Nairobi`,
    ],
  });
}

export default async function ProductPage({
  params,
}: PageProps<"/products/[slug]">) {
  const { slug } = await params;
  const chemical = await fetchChemicalBySlug(slug);
  if (!chemical) notFound();

  const [related, industries] = await Promise.all([
    fetchRelatedChemicals(chemical),
    fetchIndustries(),
  ]);

  // Products carry industry *names*; resolve them to real slugs rather than
  // guessing a URL from the label.
  const industryHrefByName = new Map(
    industries.map((industry) => [industry.name, `/industries/${industry.slug}`]),
  );
  const linkedIndustries = (chemical.industries_names ?? [])
    .map((name) => ({ name, href: industryHrefByName.get(name) }))
    .filter((entry): entry is { name: string; href: string } =>
      Boolean(entry.href),
    );
  const faqs = chemicalFaqs(chemical);
  const synonyms = splitList(chemical.synonyms);
  const applications = toBullets(chemical.applications);
  const benefits = toBullets(chemical.benefits);
  const hazards = toBullets(chemical.hazard_statements);

  const crumbs = [
    { label: "Home", href: "/" },
    { label: "Chemicals", href: "/products" },
    { label: chemical.name, href: `/products/${chemical.slug}` },
  ];

  const specs = [
    { label: "CAS number", value: chemical.cas_number, mono: true },
    { label: "Chemical formula", value: chemical.chemical_formula, formula: true },
    { label: "Molecular weight", value: chemical.molecular_weight },
    { label: "Grade", value: `${chemical.grade} grade` },
    { label: "Purity", value: chemical.purity_percentage },
    { label: "Appearance", value: chemical.appearance },
    { label: "Density", value: chemical.density },
    { label: "UN number", value: chemical.un_number, mono: true },
  ].filter((spec) => Boolean(spec.value));

  return (
    <article className="pt-32">
      <Container>
        <Breadcrumbs items={crumbs} className="mb-6" />

        <div className="grid gap-12 lg:grid-cols-[1.6fr_1fr] lg:gap-16">
          {/* ---------------------------------------------------------- Main */}
          <div className="min-w-0">
            <header>
              <div className="flex flex-wrap items-center gap-2">
                <Badge tone="accent">{chemical.grade} grade</Badge>
                {chemical.category_name && (
                  <Badge tone="navy">{chemical.category_name}</Badge>
                )}
                {chemical.in_stock !== false && (
                  <Badge tone="accent">In stock</Badge>
                )}
              </div>

              <h1 className="mt-5 text-3xl font-extrabold leading-tight tracking-tight sm:text-4xl lg:text-5xl">
                {chemical.name}
              </h1>

              <p className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-2 text-sm text-fg-muted">
                <span className="font-mono">CAS {chemical.cas_number}</span>
                <span aria-hidden className="text-fg-subtle">
                  ·
                </span>
                <Formula value={chemical.chemical_formula} className="text-base" />
                {chemical.molecular_weight && (
                  <>
                    <span aria-hidden className="text-fg-subtle">
                      ·
                    </span>
                    <span>{chemical.molecular_weight}</span>
                  </>
                )}
              </p>

              <p className="mt-6 text-base leading-relaxed text-fg-muted sm:text-lg">
                {chemical.description}
              </p>

              {synonyms.length > 0 && (
                <div className="mt-6">
                  <h2 className="mb-2 font-mono text-[0.65rem] font-semibold uppercase tracking-[0.16em] text-fg-subtle">
                    Also known as
                  </h2>
                  <ul className="flex flex-wrap gap-1.5">
                    {synonyms.map((synonym) => (
                      <li
                        key={synonym}
                        className="rounded-lg bg-surface-2 px-2.5 py-1 text-xs text-fg-muted"
                      >
                        {synonym}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </header>

            {/* Quote card appears here on mobile, before the deep detail. */}
            <div className="mt-10 lg:hidden">
              <ProductQuoteCard chemical={chemical} />
            </div>

            {/* Specifications */}
            <ProductSection
              id="specifications"
              icon={Beaker}
              title="Technical specifications"
            >
              <dl className="grid gap-x-8 gap-y-0 sm:grid-cols-2">
                {specs.map((spec) => (
                  <div
                    key={spec.label}
                    className="flex justify-between gap-4 border-b border-border-base py-3"
                  >
                    <dt className="text-sm text-fg-muted">{spec.label}</dt>
                    <dd
                      className={`text-right text-sm font-semibold text-fg ${
                        spec.mono ? "font-mono" : ""
                      }`}
                    >
                      {spec.formula ? (
                        <Formula value={spec.value as string} />
                      ) : (
                        spec.value
                      )}
                    </dd>
                  </div>
                ))}
              </dl>

              {chemical.technical_overview && (
                <p className="mt-6 text-sm leading-relaxed text-fg-muted">
                  {chemical.technical_overview}
                </p>
              )}
            </ProductSection>

            {/* Applications */}
            {applications.length > 0 && (
              <ProductSection
                id="applications"
                icon={Factory}
                title="Applications & uses"
              >
                <ul className="grid gap-3 sm:grid-cols-2">
                  {applications.map((application) => (
                    <li
                      key={application}
                      className="flex gap-2.5 rounded-xl bg-surface-2 px-4 py-3 text-sm leading-relaxed text-fg-muted"
                    >
                      <span
                        aria-hidden
                        className="mt-1.5 size-1.5 shrink-0 rounded-full bg-spark-500"
                      />
                      {application}
                    </li>
                  ))}
                </ul>
              </ProductSection>
            )}

            {/* Industries — an important internal-linking surface */}
            {linkedIndustries.length > 0 && (
              <ProductSection
                id="industries"
                icon={Factory}
                title="Industries we supply this to"
              >
                <ul className="flex flex-wrap gap-2">
                  {linkedIndustries.map((industry) => (
                    <li key={industry.name}>
                      <Link
                        href={industry.href}
                        className="inline-flex rounded-xl border border-border-base px-3.5 py-2 text-sm font-medium text-fg-muted transition-colors hover:border-spark-500/50 hover:text-spark-600 dark:hover:text-spark-400"
                      >
                        {industry.name}
                      </Link>
                    </li>
                  ))}
                </ul>
              </ProductSection>
            )}

            {/* Benefits */}
            {benefits.length > 0 && (
              <ProductSection
                id="benefits"
                icon={PackageCheck}
                title="Why buy this from Sparks"
              >
                <ul className="flex flex-col gap-2.5">
                  {benefits.map((benefit) => (
                    <li
                      key={benefit}
                      className="flex gap-2.5 text-sm leading-relaxed text-fg-muted"
                    >
                      <span
                        aria-hidden
                        className="mt-1.5 size-1.5 shrink-0 rounded-full bg-spark-500"
                      />
                      {benefit}
                    </li>
                  ))}
                </ul>
              </ProductSection>
            )}

            {/* Safety — visually distinct because it carries real risk. */}
            <ProductSection
              id="safety"
              icon={ShieldAlert}
              title="Safety, handling & storage"
            >
              <div className="rounded-2xl border border-amber-300/60 bg-amber-50/70 p-5 dark:border-amber-500/25 dark:bg-amber-500/8">
                <div className="flex items-start gap-3">
                  <AlertTriangle
                    aria-hidden
                    className="mt-0.5 size-5 shrink-0 text-amber-600 dark:text-amber-400"
                  />
                  <div className="min-w-0">
                    {chemical.ghs_hazard_class && (
                      <p className="text-sm font-bold text-amber-900 dark:text-amber-200">
                        GHS classification: {chemical.ghs_hazard_class}
                      </p>
                    )}
                    {hazards.length > 0 && (
                      <ul className="mt-2.5 flex flex-col gap-1.5">
                        {hazards.map((hazard) => (
                          <li
                            key={hazard}
                            className="text-sm leading-relaxed text-amber-900/85 dark:text-amber-200/85"
                          >
                            {hazard}
                          </li>
                        ))}
                      </ul>
                    )}
                    <p className="mt-3 text-xs leading-relaxed text-amber-900/70 dark:text-amber-200/70">
                      Always consult the full Safety Data Sheet before handling.
                      Personnel must use appropriate PPE and follow local
                      regulations for storage, transport and disposal.
                    </p>
                  </div>
                </div>
              </div>

              {chemical.storage_conditions && (
                <div className="mt-5 flex items-start gap-3 rounded-2xl bg-surface-2 p-5">
                  <Thermometer
                    aria-hidden
                    className="mt-0.5 size-5 shrink-0 text-navy-600 dark:text-navy-300"
                  />
                  <div>
                    <h3 className="text-sm font-bold text-fg">
                      Storage conditions
                    </h3>
                    <p className="mt-1.5 text-sm leading-relaxed text-fg-muted">
                      {chemical.storage_conditions}
                    </p>
                  </div>
                </div>
              )}
            </ProductSection>

            {/* FAQ */}
            <ProductSection
              id="faq"
              icon={BookOpen}
              title="Frequently asked questions"
            >
              <div className="flex flex-col gap-3">
                {faqs.map((faq) => (
                  <details
                    key={faq.question}
                    className="group rounded-xl border border-border-base bg-surface px-5 py-4 open:bg-surface-2"
                  >
                    <summary className="cursor-pointer list-none text-sm font-semibold text-fg marker:content-none">
                      <span className="flex items-center justify-between gap-4">
                        {faq.question}
                        <span
                          aria-hidden
                          className="shrink-0 text-lg leading-none text-spark-500 transition-transform group-open:rotate-45"
                        >
                          +
                        </span>
                      </span>
                    </summary>
                    <p className="mt-3 text-sm leading-relaxed text-fg-muted">
                      {faq.answer}
                    </p>
                  </details>
                ))}
              </div>
            </ProductSection>
          </div>

          {/* -------------------------------------------------------- Sidebar */}
          <aside className="hidden lg:block">
            <div className="sticky top-32">
              <ProductQuoteCard chemical={chemical} />
            </div>
          </aside>
        </div>
      </Container>

      {/* Related products */}
      {related.length > 0 && (
        <Section className="mt-12 border-t border-border-base bg-surface-2/40">
          <Container>
            <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">
              Related chemicals
            </h2>
            <p className="mt-2.5 text-sm text-fg-muted">
              Frequently bought together with {chemical.name}, or used as
              alternatives in the same processes.
            </p>
            <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
              {related.map((item) => (
                <ChemicalCard key={item.slug} chemical={item} />
              ))}
            </div>
            <ButtonLink href="/products" variant="outline" className="mt-10">
              Browse the full catalogue
            </ButtonLink>
          </Container>
        </Section>
      )}

      <JsonLd data={productSchema(chemical)} />
      <JsonLd data={faqSchema(faqs)} />
    </article>
  );
}

function ProductSection({
  id,
  icon: Icon,
  title,
  children,
}: {
  id: string;
  icon: React.ElementType;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <section id={id} className="mt-14 scroll-mt-32">
      <h2 className="mb-6 flex items-center gap-2.5 text-xl font-bold tracking-tight text-fg">
        <span className="flex size-9 items-center justify-center rounded-lg bg-spark-50 text-spark-600 dark:bg-spark-500/12 dark:text-spark-400">
          <Icon aria-hidden className="size-4" />
        </span>
        {title}
      </h2>
      {children}
    </section>
  );
}
