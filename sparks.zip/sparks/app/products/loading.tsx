import { Container } from "@/components/ui/primitives";

/** Skeleton shown while the catalogue query resolves. */
export default function Loading() {
  return (
    <div className="pt-32">
      <Container>
        <div className="skeleton h-3 w-40 rounded" />
        <div className="mt-8 skeleton h-12 w-80 rounded-lg" />
        <div className="mt-5 skeleton h-4 w-full max-w-2xl rounded" />
        <div className="mt-2 skeleton h-4 w-full max-w-xl rounded" />

        <div className="mt-12 flex flex-col gap-6 lg:flex-row lg:gap-10">
          <div className="hidden w-64 shrink-0 flex-col gap-6 lg:flex">
            {[0, 1, 2].map((group) => (
              <div key={group}>
                <div className="skeleton h-3 w-24 rounded" />
                <div className="mt-4 flex flex-col gap-2">
                  {[0, 1, 2, 3].map((row) => (
                    <div key={row} className="skeleton h-8 w-full rounded-lg" />
                  ))}
                </div>
              </div>
            ))}
          </div>

          <div className="grid flex-1 gap-5 sm:grid-cols-2 xl:grid-cols-3">
            {Array.from({ length: 9 }).map((_, index) => (
              <div
                key={index}
                className="rounded-2xl border border-border-base bg-surface p-5"
              >
                <div className="skeleton h-6 w-24 rounded-full" />
                <div className="mt-4 skeleton h-5 w-full rounded" />
                <div className="mt-2 skeleton h-5 w-2/3 rounded" />
                <div className="mt-4 skeleton h-3 w-40 rounded" />
                <div className="mt-4 skeleton h-12 w-full rounded" />
                <div className="mt-5 skeleton h-9 w-full rounded-lg" />
              </div>
            ))}
          </div>
        </div>
      </Container>
    </div>
  );
}
