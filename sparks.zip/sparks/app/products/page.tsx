import { Suspense } from "react";
import Link from "next/link";
import { FlaskConical, SearchX } from "lucide-react";
import {
  Breadcrumbs,
  Container,
  JsonLd,
} from "@/components/ui/primitives";
import { ChemicalCard } from "@/components/catalog/ChemicalCard";
import { CatalogFilters } from "@/components/catalog/CatalogFilters";
import { ButtonLink } from "@/components/ui/Button";
import {
  fetchCategories,
  fetchChemicals,
  fetchIndustries,
} from "@/lib/api";
import { buildMetadata } from "@/lib/seo";
import { SITE_URL } from "@/lib/site";
import type { ChemicalQuery, Grade } from "@/lib/types";

const VALID_GRADES: Grade[] = [
  "Technical",
  "Food",
  "AR",
  "Pharma",
  "Industrial",
];

export async function generateMetadata({
  searchParams,
}: PageProps<"/products">) {
  const params = await searchParams;
  const q = typeof params.q === "string" ? params.q : undefined;
  const grade = typeof params.grade === "string" ? params.grade : undefined;
  const industry =
    typeof params.industry === "string" ? params.industry : undefined;

  // A filtered view gets a descriptive title but is kept out of the index —
  // the facet permutations would otherwise flood Google with thin duplicates.
  const isFiltered = Boolean(q || grade || industry);

  let title = "Chemical Catalogue — 1,500+ Products in Stock";
  if (q) title = `Search results for “${q}”`;
  else if (grade) title = `${grade} Grade Chemicals`;
  else if (industry) title = `Chemicals for ${industry.replace(/-/g, " ")}`;

  return buildMetadata({
    title,
    description:
      "Browse the Sparks Chemicals catalogue — industrial, laboratory, food grade, water treatment, agricultural and pharmaceutical chemicals with full specifications, CAS numbers and safety data. Delivered across Kenya and East Africa.",
    path: "/products",
    keywords: [
      "chemical catalogue Kenya",
      "buy chemicals Nairobi",
      "industrial chemical suppliers East Africa",
      "laboratory chemicals Kenya",
    ],
    noIndex: isFiltered,
  });
}

export default async function ProductsPage({
  searchParams,
}: PageProps<"/products">) {
  const params = await searchParams;

  const asString = (value: string | string[] | undefined) =>
    typeof value === "string" && value.trim() ? value.trim() : undefined;

  const rawGrade = asString(params.grade);
  const query: ChemicalQuery = {
    q: asString(params.q),
    cas: asString(params.cas),
    formula: asString(params.formula),
    industry: asString(params.industry),
    category: asString(params.category),
    // Only forward a grade the API actually understands.
    grade: VALID_GRADES.find((g) => g === rawGrade),
  };

  const [chemicals, industries, categories] = await Promise.all([
    fetchChemicals(query),
    fetchIndustries(),
    fetchCategories(),
  ]);

  const crumbs = [
    { label: "Home", href: "/" },
    { label: "Chemicals", href: "/products" },
  ];

  return (
    <div className="pt-32">
      <Container>
        <Breadcrumbs items={crumbs} className="mb-6" />

        <header className="max-w-3xl">
          <h1 className="text-4xl font-extrabold tracking-tight sm:text-5xl">
            {query.q ? (
              <>
                Results for{" "}
                <span className="text-spark-600 dark:text-spark-400">
                  “{query.q}”
                </span>
              </>
            ) : (
              "Chemical catalogue"
            )}
          </h1>
          <p className="mt-4 text-base leading-relaxed text-fg-muted sm:text-lg">
            Full specifications, CAS numbers, safety data and packaging options
            for every product we supply. Add items to your list and request one
            consolidated quotation.
          </p>
        </header>

        <div className="mt-12 flex flex-col items-start gap-6 lg:flex-row lg:gap-10">
          {/* Renders a trigger button on mobile and a sticky sidebar on
              desktop; reads filter state from the URL, hence the Suspense. */}
          <Suspense fallback={<div className="hidden w-64 shrink-0 lg:block" />}>
            <CatalogFilters industries={industries} categories={categories} />
          </Suspense>

          <div className="min-w-0 w-full flex-1">
            <div className="mb-6 flex items-center justify-between gap-4">
              <p className="text-sm text-fg-muted" aria-live="polite">
                <span className="font-semibold text-fg">{chemicals.length}</span>{" "}
                {chemicals.length === 1 ? "product" : "products"}
              </p>
            </div>

            {chemicals.length > 0 ? (
              <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
                {chemicals.map((chemical) => (
                  <ChemicalCard key={chemical.slug} chemical={chemical} />
                ))}
              </div>
            ) : (
              <EmptyState query={query.q} />
            )}
          </div>
        </div>

        {chemicals.length > 0 && (
          <JsonLd
            data={{
              "@context": "https://schema.org",
              "@type": "ItemList",
              name: "Sparks Chemicals catalogue",
              numberOfItems: chemicals.length,
              itemListElement: chemicals.slice(0, 30).map((c, index) => ({
                "@type": "ListItem",
                position: index + 1,
                url: `${SITE_URL}/products/${c.slug}`,
                name: c.name,
              })),
            }}
          />
        )}
      </Container>

      {/* Cross-links keep every catalogue view connected to the wider site. */}
      <Container className="mb-24 mt-20">
        <div className="rounded-2xl border border-border-base bg-surface-2/50 p-8">
          <h2 className="text-lg font-bold text-fg">
            Can&apos;t find what you need?
          </h2>
          <p className="mt-2 max-w-2xl text-sm leading-relaxed text-fg-muted">
            We stock a fraction of what we can source. Our network covers
            manufacturers across China, India, the Gulf and Europe — send us a
            specification and we will come back with availability, lead time and
            delivered pricing.
          </p>
          <div className="mt-5 flex flex-wrap gap-3">
            <ButtonLink href="/quote" variant="accent">
              Request a sourcing quote
            </ButtonLink>
            <ButtonLink href="/contact" variant="outline">
              Speak to a technical engineer
            </ButtonLink>
          </div>
        </div>
      </Container>
    </div>
  );
}

function EmptyState({ query }: { query?: string }) {
  return (
    <div className="rounded-2xl border border-dashed border-border-strong px-8 py-16 text-center">
      <span className="mx-auto mb-5 flex size-14 items-center justify-center rounded-2xl bg-surface-2 text-fg-subtle">
        <SearchX aria-hidden className="size-6" />
      </span>
      <h2 className="text-lg font-bold text-fg">
        {query ? `No results for “${query}”` : "No products match these filters"}
      </h2>
      <p className="mx-auto mt-2.5 max-w-md text-sm leading-relaxed text-fg-muted">
        Try a CAS number, a chemical formula, or a broader term. We also source
        to order — if it exists, we can usually supply it.
      </p>
      <div className="mt-6 flex flex-wrap justify-center gap-3">
        <ButtonLink href="/products" variant="outline">
          <FlaskConical aria-hidden className="size-4" />
          Clear filters
        </ButtonLink>
        <ButtonLink href="/quote" variant="accent">
          Request this chemical
        </ButtonLink>
      </div>
      <p className="mt-6 text-xs text-fg-subtle">
        Or browse by{" "}
        <Link
          href="/industries"
          className="font-semibold text-spark-600 hover:underline dark:text-spark-400"
        >
          industry
        </Link>
        .
      </p>
    </div>
  );
}
