import { Clock, FileCheck2, ShieldCheck, Truck } from "lucide-react";
import {
  Breadcrumbs,
  Container,
  Section,
} from "@/components/ui/primitives";
import { QuotePageForm } from "@/components/quote/QuotePageForm";
import { buildMetadata } from "@/lib/seo";

export const metadata = buildMetadata({
  title: "Request a Chemical Quotation — Response in 2 Hours",
  description:
    "Request delivered pricing on any chemical. Send your specification, volume and destination — the Sparks Chemicals technical desk responds within two working hours across Kenya and East Africa.",
  path: "/quote",
  keywords: [
    "chemical quotation Kenya",
    "chemical price request Nairobi",
    "bulk chemical pricing East Africa",
  ],
});

const ASSURANCES = [
  {
    icon: Clock,
    title: "Two-hour response",
    body: "Quotations returned within two working hours, Monday to Saturday.",
  },
  {
    icon: FileCheck2,
    title: "Full documentation",
    body: "COA, SDS and compliance marks issued with every consignment.",
  },
  {
    icon: Truck,
    title: "Delivered pricing",
    body: "Quotes include transport to your site, not just ex-warehouse.",
  },
  {
    icon: ShieldCheck,
    title: "No obligation",
    body: "Your details are used solely to prepare this quotation.",
  },
];

export default function QuotePage() {
  const crumbs = [
    { label: "Home", href: "/" },
    { label: "Request a quotation", href: "/quote" },
  ];

  return (
    <div className="pt-32">
      <Container>
        <Breadcrumbs items={crumbs} className="mb-6" />

        <header className="max-w-3xl">
          <h1 className="text-4xl font-extrabold tracking-tight sm:text-5xl lg:text-6xl">
            Request a quotation
          </h1>
          <p className="mt-5 text-base leading-relaxed text-fg-muted sm:text-lg">
            List the chemicals you need — by name, CAS number or description.
            If you&apos;re not sure exactly what to specify, describe the process
            and our engineers will identify the right material and grade.
          </p>
        </header>
      </Container>

      <Section>
        <Container>
          <div className="grid gap-10 lg:grid-cols-[1.3fr_1fr] lg:gap-16">
            <QuotePageForm />

            <aside className="lg:sticky lg:top-32 lg:self-start">
              <ul className="flex flex-col gap-3">
                {ASSURANCES.map((item) => (
                  <li
                    key={item.title}
                    className="flex items-start gap-3.5 rounded-2xl border border-border-base bg-surface p-5"
                  >
                    <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-spark-50 text-spark-600 dark:bg-spark-500/12 dark:text-spark-400">
                      <item.icon aria-hidden className="size-5" />
                    </span>
                    <span>
                      <span className="block text-sm font-bold text-fg">
                        {item.title}
                      </span>
                      <span className="mt-1 block text-xs leading-relaxed text-fg-muted">
                        {item.body}
                      </span>
                    </span>
                  </li>
                ))}
              </ul>
            </aside>
          </div>
        </Container>
      </Section>
    </div>
  );
}
