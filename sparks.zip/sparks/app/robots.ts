import type { MetadataRoute } from "next";
import { SITE_URL } from "@/lib/site";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      {
        userAgent: "*",
        allow: "/",
        // Filtered catalogue views are `noindex` anyway; disallowing the query
        // strings also stops crawl budget being spent on facet permutations.
        disallow: ["/api/", "/*?q=", "/*?grade=", "/*?industry=", "/*?category="],
      },
    ],
    sitemap: `${SITE_URL}/sitemap.xml`,
    host: SITE_URL,
  };
}
