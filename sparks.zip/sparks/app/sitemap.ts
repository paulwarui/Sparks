import type { MetadataRoute } from "next";
import { fetchArticles, fetchChemicals, fetchIndustries } from "@/lib/api";
import { SITE_URL } from "@/lib/site";

/** Regenerate the sitemap hourly so new catalogue entries surface quickly. */
export const revalidate = 3600;

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const now = new Date();

  const staticRoutes: MetadataRoute.Sitemap = [
    { url: SITE_URL, changeFrequency: "daily", priority: 1, lastModified: now },
    {
      url: `${SITE_URL}/products`,
      changeFrequency: "daily",
      priority: 0.9,
      lastModified: now,
    },
    {
      url: `${SITE_URL}/industries`,
      changeFrequency: "weekly",
      priority: 0.8,
      lastModified: now,
    },
    {
      url: `${SITE_URL}/quote`,
      changeFrequency: "monthly",
      priority: 0.8,
      lastModified: now,
    },
    {
      url: `${SITE_URL}/blog`,
      changeFrequency: "weekly",
      priority: 0.7,
      lastModified: now,
    },
    {
      url: `${SITE_URL}/about`,
      changeFrequency: "monthly",
      priority: 0.6,
      lastModified: now,
    },
    {
      url: `${SITE_URL}/contact`,
      changeFrequency: "monthly",
      priority: 0.6,
      lastModified: now,
    },
  ];

  const [chemicals, industries, articles] = await Promise.all([
    fetchChemicals(),
    fetchIndustries(),
    fetchArticles(),
  ]);

  return [
    ...staticRoutes,
    ...chemicals.map((chemical) => ({
      url: `${SITE_URL}/products/${chemical.slug}`,
      lastModified: now,
      changeFrequency: "weekly" as const,
      priority: 0.8,
    })),
    ...industries.map((industry) => ({
      url: `${SITE_URL}/industries/${industry.slug}`,
      lastModified: now,
      changeFrequency: "monthly" as const,
      priority: 0.7,
    })),
    ...articles.map((article) => ({
      url: `${SITE_URL}/blog/${article.slug}`,
      lastModified: new Date(article.published_at),
      changeFrequency: "monthly" as const,
      priority: 0.6,
    })),
  ];
}
