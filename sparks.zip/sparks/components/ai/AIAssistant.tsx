"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import {
  ArrowUp,
  Bot,
  ExternalLink,
  Loader2,
  MessageCircle,
  Sparkles,
  X,
} from "lucide-react";
import { useUI } from "@/components/providers/UIProvider";
import { queryAIAssistant, type AIReply } from "@/lib/api";
import { contact } from "@/lib/site";
import { cn } from "@/lib/utils";

interface Message {
  id: number;
  role: "user" | "assistant";
  text: string;
  suggestions?: AIReply["suggested_chemicals"];
}

const OPENERS = [
  "Which coagulant suits a 5,000 m³/day water plant?",
  "What can replace caustic soda in CIP cleaning?",
  "Do you supply food grade citric acid in 25kg bags?",
  "What safety gear is needed for 98% sulphuric acid?",
];

const GREETING: Message = {
  id: 0,
  role: "assistant",
  text: "I'm the Sparks technical advisor. Ask me to identify a chemical, suggest a substitute, explain an application, or start a quotation — and I'll hand you to a human engineer whenever you need one.",
};

/**
 * Floating AI advisor. Answers come from the Django `/ai/advisor/` endpoint;
 * every response offers an escalation path to a human, because a wrong answer
 * about a corrosive material is far costlier than an unanswered question.
 */
export function AIAssistant() {
  const { aiOpen, openAI, closeAI } = useUI();
  const [messages, setMessages] = useState<Message[]>([GREETING]);
  const [input, setInput] = useState("");
  const [thinking, setThinking] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({
      top: scrollRef.current.scrollHeight,
      behavior: "smooth",
    });
  }, [messages, thinking]);

  useEffect(() => {
    if (aiOpen) setTimeout(() => inputRef.current?.focus(), 60);
  }, [aiOpen]);

  useEffect(() => {
    if (!aiOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeAI();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [aiOpen, closeAI]);

  async function send(text: string) {
    const trimmed = text.trim();
    if (!trimmed || thinking) return;

    setMessages((current) => [
      ...current,
      { id: Date.now(), role: "user", text: trimmed },
    ]);
    setInput("");
    setThinking(true);

    const reply = await queryAIAssistant(trimmed);

    setMessages((current) => [
      ...current,
      {
        id: Date.now() + 1,
        role: "assistant",
        text: reply.reply,
        suggestions: reply.suggested_chemicals,
      },
    ]);
    setThinking(false);
  }

  return (
    <>
      {/* Launcher */}
      {!aiOpen && (
        <button
          type="button"
          onClick={openAI}
          aria-label="Open Sparks AI technical advisor"
          className="group fixed bottom-5 right-5 z-[80] flex items-center gap-2.5 rounded-full bg-navy-800 py-3 pl-3.5 pr-5 text-white shadow-2xl shadow-navy-900/30 transition-transform hover:scale-105 dark:bg-spark-500 dark:text-navy-950"
        >
          <span className="relative flex size-7 items-center justify-center rounded-full bg-spark-500 text-navy-950 dark:bg-navy-950 dark:text-spark-400">
            <Bot aria-hidden className="size-4" />
            <span
              aria-hidden
              className="absolute -right-0.5 -top-0.5 size-2.5 rounded-full bg-spark-300 ring-2 ring-navy-800 dark:ring-spark-500"
            />
          </span>
          <span className="text-sm font-semibold">Ask Sparks AI</span>
        </button>
      )}

      {/* Panel */}
      {aiOpen && (
        <div
          role="dialog"
          aria-label="Sparks AI technical advisor"
          className="fixed bottom-0 right-0 z-[85] flex h-[min(38rem,100dvh)] w-full flex-col overflow-hidden border-border-base bg-surface shadow-2xl sm:bottom-5 sm:right-5 sm:h-[36rem] sm:w-[25rem] sm:rounded-2xl sm:border"
        >
          <header className="flex items-center justify-between border-b border-border-base bg-navy-800 px-4 py-3.5 text-white dark:bg-navy-950">
            <div className="flex items-center gap-2.5">
              <span className="flex size-9 items-center justify-center rounded-lg bg-spark-500 text-navy-950">
                <Sparkles aria-hidden className="size-4" />
              </span>
              <div>
                <h2 className="text-sm font-bold">Sparks AI Advisor</h2>
                <p className="flex items-center gap-1.5 text-[0.68rem] text-white/70">
                  <span
                    aria-hidden
                    className="size-1.5 rounded-full bg-spark-400"
                  />
                  Technical desk online
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={closeAI}
              aria-label="Close advisor"
              className="rounded-lg p-2 text-white/70 transition-colors hover:bg-white/10 hover:text-white"
            >
              <X aria-hidden className="size-4" />
            </button>
          </header>

          <div ref={scrollRef} className="flex-1 space-y-3.5 overflow-y-auto px-4 py-4">
            {messages.map((message) => (
              <div key={message.id}>
                <div
                  className={cn(
                    "max-w-[85%] rounded-2xl px-3.5 py-2.5 text-sm leading-relaxed",
                    message.role === "user"
                      ? "ml-auto bg-navy-800 text-white dark:bg-navy-700"
                      : "bg-surface-2 text-fg",
                  )}
                >
                  {message.text}
                </div>

                {message.suggestions && message.suggestions.length > 0 && (
                  <ul className="mt-2 flex flex-col gap-1.5">
                    {message.suggestions.map((s) => (
                      <li key={s.slug}>
                        <Link
                          href={`/products/${s.slug}`}
                          onClick={closeAI}
                          className="flex items-center justify-between gap-2 rounded-xl border border-border-base bg-surface px-3 py-2 transition-colors hover:border-spark-500/50"
                        >
                          <span className="min-w-0">
                            <span className="block truncate text-xs font-semibold text-fg">
                              {s.name}
                            </span>
                            <span className="font-mono text-[0.65rem] text-fg-subtle">
                              CAS {s.cas}
                            </span>
                          </span>
                          <ExternalLink
                            aria-hidden
                            className="size-3.5 shrink-0 text-spark-500"
                          />
                        </Link>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            ))}

            {thinking && (
              <div className="flex items-center gap-2 rounded-2xl bg-surface-2 px-3.5 py-2.5 text-sm text-fg-muted">
                <Loader2 aria-hidden className="size-3.5 animate-spin" />
                Checking the catalogue…
              </div>
            )}

            {messages.length === 1 && (
              <div className="pt-1">
                <p className="mb-2 font-mono text-[0.65rem] font-semibold uppercase tracking-[0.16em] text-fg-subtle">
                  Try asking
                </p>
                <div className="flex flex-col gap-1.5">
                  {OPENERS.map((opener) => (
                    <button
                      key={opener}
                      type="button"
                      onClick={() => send(opener)}
                      className="rounded-xl border border-border-base px-3 py-2 text-left text-xs text-fg-muted transition-colors hover:border-spark-500/50 hover:text-fg"
                    >
                      {opener}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="border-t border-border-base p-3">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                send(input);
              }}
              className="flex items-center gap-2 rounded-xl border border-border-base bg-surface-2 px-3 py-1.5 focus-within:border-spark-500"
            >
              <label htmlFor="ai-input" className="sr-only">
                Ask the Sparks AI advisor a question
              </label>
              <input
                id="ai-input"
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask about a chemical or application…"
                className="min-w-0 flex-1 bg-transparent py-1.5 text-sm text-fg outline-none placeholder:text-fg-subtle"
              />
              <button
                type="submit"
                disabled={!input.trim() || thinking}
                aria-label="Send message"
                className="flex size-8 shrink-0 items-center justify-center rounded-lg bg-spark-500 text-white transition-opacity disabled:opacity-40 dark:text-navy-950"
              >
                <ArrowUp aria-hidden className="size-4" />
              </button>
            </form>

            <a
              href={contact.whatsappHref}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-2 flex items-center justify-center gap-1.5 text-[0.68rem] font-medium text-fg-subtle transition-colors hover:text-spark-600 dark:hover:text-spark-400"
            >
              <MessageCircle aria-hidden className="size-3" />
              Prefer a human? Talk to our engineers on WhatsApp
            </a>
          </div>
        </div>
      )}
    </>
  );
}
