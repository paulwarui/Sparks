import { Fragment, type ReactNode } from "react";

/**
 * Minimal Markdown renderer for editorial content.
 *
 * Deliberately renders to React elements rather than injecting HTML: article
 * bodies are authored in the Django admin, and `dangerouslySetInnerHTML` would
 * turn any compromised or careless admin account into stored XSS. Supports the
 * subset the knowledge centre actually uses — headings, bullet and numbered
 * lists, bold, italic, inline code and links.
 */

function renderInline(text: string, keyPrefix: string): ReactNode[] {
  const nodes: ReactNode[] = [];
  // Ordered by precedence: links, bold, italic, inline code.
  const pattern =
    /\[([^\]]+)\]\(([^)\s]+)\)|\*\*([^*]+)\*\*|(?<!\*)\*([^*]+)\*(?!\*)|`([^`]+)`/g;

  let lastIndex = 0;
  let match: RegExpExecArray | null;
  let i = 0;

  while ((match = pattern.exec(text)) !== null) {
    if (match.index > lastIndex) {
      nodes.push(text.slice(lastIndex, match.index));
    }

    const key = `${keyPrefix}-${i++}`;
    if (match[1] && match[2]) {
      const isExternal = /^https?:\/\//.test(match[2]);
      nodes.push(
        <a
          key={key}
          href={match[2]}
          {...(isExternal
            ? { target: "_blank", rel: "noopener noreferrer" }
            : {})}
          className="font-medium text-spark-600 underline underline-offset-2 hover:text-spark-700 dark:text-spark-400"
        >
          {match[1]}
        </a>,
      );
    } else if (match[3]) {
      nodes.push(
        <strong key={key} className="font-semibold text-fg">
          {match[3]}
        </strong>,
      );
    } else if (match[4]) {
      nodes.push(<em key={key}>{match[4]}</em>);
    } else if (match[5]) {
      nodes.push(
        <code
          key={key}
          className="rounded bg-surface-2 px-1.5 py-0.5 font-mono text-[0.85em] text-fg"
        >
          {match[5]}
        </code>,
      );
    }

    lastIndex = pattern.lastIndex;
  }

  if (lastIndex < text.length) nodes.push(text.slice(lastIndex));
  return nodes;
}

type Block =
  | { type: "heading"; level: 2 | 3 | 4; text: string }
  | { type: "paragraph"; text: string }
  | { type: "ul"; items: string[] }
  | { type: "ol"; items: string[] }
  | { type: "quote"; text: string };

function parseBlocks(markdown: string): Block[] {
  const lines = markdown.replace(/\r\n/g, "\n").split("\n");
  const blocks: Block[] = [];

  let paragraph: string[] = [];
  let list: { ordered: boolean; items: string[] } | null = null;

  const flushParagraph = () => {
    if (paragraph.length) {
      blocks.push({ type: "paragraph", text: paragraph.join(" ").trim() });
      paragraph = [];
    }
  };

  const flushList = () => {
    if (list) {
      blocks.push(
        list.ordered
          ? { type: "ol", items: list.items }
          : { type: "ul", items: list.items },
      );
      list = null;
    }
  };

  for (const rawLine of lines) {
    const line = rawLine.trim();

    if (!line) {
      flushParagraph();
      flushList();
      continue;
    }

    const heading = /^(#{2,4})\s+(.*)$/.exec(line);
    if (heading) {
      flushParagraph();
      flushList();
      blocks.push({
        type: "heading",
        level: heading[1].length as 2 | 3 | 4,
        text: heading[2],
      });
      continue;
    }

    const bullet = /^[-*+]\s+(.*)$/.exec(line);
    if (bullet) {
      flushParagraph();
      if (!list || list.ordered) {
        flushList();
        list = { ordered: false, items: [] };
      }
      list.items.push(bullet[1]);
      continue;
    }

    const numbered = /^\d+[.)]\s+(.*)$/.exec(line);
    if (numbered) {
      flushParagraph();
      if (!list || !list.ordered) {
        flushList();
        list = { ordered: true, items: [] };
      }
      list.items.push(numbered[1]);
      continue;
    }

    const quote = /^>\s+(.*)$/.exec(line);
    if (quote) {
      flushParagraph();
      flushList();
      blocks.push({ type: "quote", text: quote[1] });
      continue;
    }

    flushList();
    paragraph.push(line);
  }

  flushParagraph();
  flushList();
  return blocks;
}

export function Markdown({ content }: { content: string }) {
  const blocks = parseBlocks(content);

  return (
    <div className="flex flex-col gap-5">
      {blocks.map((block, index) => {
        const key = `block-${index}`;

        switch (block.type) {
          case "heading": {
            const cls =
              block.level === 2
                ? "mt-8 text-2xl font-bold tracking-tight text-fg"
                : block.level === 3
                  ? "mt-6 text-xl font-bold tracking-tight text-fg"
                  : "mt-4 text-base font-bold text-fg";
            const Tag = `h${block.level}` as "h2" | "h3" | "h4";
            return (
              <Tag key={key} className={cls}>
                {renderInline(block.text, key)}
              </Tag>
            );
          }

          case "ul":
            return (
              <ul key={key} className="flex flex-col gap-2.5 pl-1">
                {block.items.map((item, i) => (
                  <li key={i} className="flex gap-3">
                    <span
                      aria-hidden
                      className="mt-2 size-1.5 shrink-0 rounded-full bg-spark-500"
                    />
                    <span className="text-[0.975rem] leading-relaxed text-fg-muted">
                      {renderInline(item, `${key}-${i}`)}
                    </span>
                  </li>
                ))}
              </ul>
            );

          case "ol":
            return (
              <ol key={key} className="flex flex-col gap-2.5 pl-1">
                {block.items.map((item, i) => (
                  <li key={i} className="flex gap-3">
                    <span
                      aria-hidden
                      className="mt-0.5 font-mono text-sm font-bold text-spark-600 dark:text-spark-400"
                    >
                      {i + 1}.
                    </span>
                    <span className="text-[0.975rem] leading-relaxed text-fg-muted">
                      {renderInline(item, `${key}-${i}`)}
                    </span>
                  </li>
                ))}
              </ol>
            );

          case "quote":
            return (
              <blockquote
                key={key}
                className="border-l-2 border-spark-500 bg-surface-2 py-3 pl-5 pr-4 text-[0.975rem] italic leading-relaxed text-fg-muted"
              >
                {renderInline(block.text, key)}
              </blockquote>
            );

          default:
            return (
              <p
                key={key}
                className="text-[0.975rem] leading-[1.75] text-fg-muted"
              >
                <Fragment>{renderInline(block.text, key)}</Fragment>
              </p>
            );
        }
      })}
    </div>
  );
}
