import Image from "next/image";
import { cn } from "@/lib/utils";
import { company } from "@/lib/site";

interface SparksLogoProps {
  className?: string;
  /** Emblem pixel size; the wordmark scales alongside it. */
  size?: number;
  showWordmark?: boolean;
  showDescriptor?: boolean;
  priority?: boolean;
}

/**
 * The corporate lockup, rebuilt from the supplied logo: the flask-and-bolt
 * emblem is the supplied artwork, while the wordmark is set in live text so it
 * stays crisp at any size, remains selectable, and is readable to crawlers.
 */
export function SparksLogo({
  className,
  size = 40,
  showWordmark = true,
  showDescriptor = false,
  priority = false,
}: SparksLogoProps) {
  return (
    <span className={cn("inline-flex items-center gap-2.5", className)}>
      <Image
        src="/sparks-mark.png"
        alt=""
        aria-hidden="true"
        width={size}
        height={size}
        priority={priority}
        className="shrink-0 object-contain"
        style={{ width: size, height: "auto" }}
      />
      {showWordmark && (
        <span className="flex flex-col leading-none">
          <span className="flex items-baseline gap-1.5">
            <span
              className="font-extrabold tracking-tight text-navy-800 dark:text-white"
              style={{ fontSize: size * 0.46 }}
            >
              SPARKS
            </span>
            <span
              className="font-semibold tracking-tight text-spark-600 dark:text-spark-400"
              style={{ fontSize: size * 0.46 }}
            >
              CHEMICALS
            </span>
          </span>
          {showDescriptor && (
            <span
              className="mt-1 font-mono uppercase tracking-[0.18em] text-fg-subtle"
              style={{ fontSize: Math.max(8, size * 0.19) }}
            >
              {company.descriptor}
            </span>
          )}
        </span>
      )}
    </span>
  );
}
