"use client";

import { useRouter, useSearchParams, usePathname } from "next/navigation";
import { useCallback, useState } from "react";
import { SlidersHorizontal, X } from "lucide-react";
import type { Category, Grade, Industry } from "@/lib/types";
import { cn } from "@/lib/utils";

const GRADES: { value: Grade; label: string }[] = [
  { value: "Industrial", label: "Industrial" },
  { value: "Technical", label: "Technical" },
  { value: "Food", label: "Food & beverage" },
  { value: "AR", label: "Analytical reagent" },
  { value: "Pharma", label: "Pharmaceutical" },
];

/**
 * Faceted catalogue filters. State lives entirely in the URL so every filtered
 * view is linkable, shareable and server-rendered — which also means the
 * result set is real HTML for crawlers rather than a client-side render.
 */
export function CatalogFilters({
  industries,
  categories,
}: {
  industries: Industry[];
  categories: Category[];
}) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [mobileOpen, setMobileOpen] = useState(false);

  const setParam = useCallback(
    (key: string, value: string | null) => {
      const params = new URLSearchParams(searchParams.toString());
      if (value === null || params.get(key) === value) params.delete(key);
      else params.set(key, value);
      const qs = params.toString();
      router.push(qs ? `${pathname}?${qs}` : pathname, { scroll: false });
    },
    [pathname, router, searchParams],
  );

  const activeGrade = searchParams.get("grade");
  const activeIndustry = searchParams.get("industry");
  const activeCategory = searchParams.get("category");
  const query = searchParams.get("q");

  const activeCount = [activeGrade, activeIndustry, activeCategory, query].filter(
    Boolean,
  ).length;

  const clearAll = () => router.push(pathname, { scroll: false });

  const panel = (
    <div className="flex flex-col gap-8">
      {activeCount > 0 && (
        <button
          type="button"
          onClick={clearAll}
          className="flex items-center gap-1.5 self-start text-xs font-semibold text-spark-600 hover:underline dark:text-spark-400"
        >
          <X aria-hidden className="size-3.5" />
          Clear all filters ({activeCount})
        </button>
      )}

      <FilterGroup title="Grade">
        {GRADES.map((grade) => (
          <FilterChip
            key={grade.value}
            label={grade.label}
            active={activeGrade === grade.value}
            onClick={() => setParam("grade", grade.value)}
          />
        ))}
      </FilterGroup>

      {categories.length > 0 && (
        <FilterGroup title="Category">
          {categories.map((category) => (
            <FilterChip
              key={category.slug}
              label={category.name}
              count={category.chemical_count}
              active={activeCategory === category.slug}
              onClick={() => setParam("category", category.slug)}
            />
          ))}
        </FilterGroup>
      )}

      <FilterGroup title="Industry">
        {industries.map((industry) => (
          <FilterChip
            key={industry.slug}
            label={industry.name}
            count={industry.chemical_count}
            active={activeIndustry === industry.slug}
            onClick={() => setParam("industry", industry.slug)}
          />
        ))}
      </FilterGroup>
    </div>
  );

  return (
    <>
      {/* Mobile trigger */}
      <button
        type="button"
        onClick={() => setMobileOpen(true)}
        className="flex items-center gap-2 rounded-xl border border-border-base bg-surface px-4 py-2.5 text-sm font-semibold text-fg lg:hidden"
      >
        <SlidersHorizontal aria-hidden className="size-4" />
        Filters
        {activeCount > 0 && (
          <span className="flex size-5 items-center justify-center rounded-full bg-spark-500 text-[10px] font-bold text-white">
            {activeCount}
          </span>
        )}
      </button>

      {/* Desktop sidebar */}
      <aside
        aria-label="Catalogue filters"
        className="hidden w-64 shrink-0 lg:block"
      >
        <div className="sticky top-32">{panel}</div>
      </aside>

      {/* Mobile sheet */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-[70] lg:hidden"
          role="dialog"
          aria-modal="true"
          aria-label="Catalogue filters"
        >
          <button
            type="button"
            aria-label="Close filters"
            onClick={() => setMobileOpen(false)}
            className="absolute inset-0 cursor-default bg-navy-950/50 backdrop-blur-sm"
          />
          <div className="absolute inset-y-0 left-0 w-[85%] max-w-sm overflow-y-auto border-r border-border-base bg-surface p-5">
            <div className="mb-6 flex items-center justify-between">
              <h2 className="text-sm font-bold text-fg">Filters</h2>
              <button
                type="button"
                onClick={() => setMobileOpen(false)}
                aria-label="Close filters"
                className="rounded-lg p-2 text-fg-muted hover:bg-surface-2"
              >
                <X aria-hidden className="size-5" />
              </button>
            </div>
            {panel}
          </div>
        </div>
      )}
    </>
  );
}

function FilterGroup({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <h3 className="mb-3 font-mono text-[0.65rem] font-semibold uppercase tracking-[0.16em] text-fg-subtle">
        {title}
      </h3>
      <div className="flex flex-col gap-1">{children}</div>
    </div>
  );
}

function FilterChip({
  label,
  count,
  active,
  onClick,
}: {
  label: string;
  count?: number;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={cn(
        "flex items-center justify-between gap-2 rounded-lg px-3 py-2 text-left text-sm transition-colors",
        active
          ? "bg-spark-50 font-semibold text-spark-700 dark:bg-spark-500/12 dark:text-spark-300"
          : "text-fg-muted hover:bg-surface-2 hover:text-fg",
      )}
    >
      <span className="truncate">{label}</span>
      {typeof count === "number" && count > 0 && (
        <span className="shrink-0 font-mono text-[0.68rem] text-fg-subtle">
          {count}
        </span>
      )}
    </button>
  );
}
