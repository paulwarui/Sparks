"use client";

import Link from "next/link";
import { ArrowUpRight, Check, Plus } from "lucide-react";
import type { Chemical } from "@/lib/types";
import { useQuote } from "@/components/providers/QuoteProvider";
import { Badge, Formula } from "@/components/ui/primitives";
import { cn } from "@/lib/utils";

const gradeTone = {
  Food: "accent",
  Pharma: "accent",
  AR: "navy",
  Technical: "neutral",
  Industrial: "neutral",
} as const;

export function ChemicalCard({
  chemical,
  className,
}: {
  chemical: Chemical;
  className?: string;
}) {
  const { addItem, has } = useQuote();
  const added = has(chemical.slug);

  return (
    <article
      className={cn(
        "group relative flex flex-col rounded-2xl border border-border-base bg-surface p-5 lift",
        className,
      )}
    >
      <div className="mb-3 flex items-start justify-between gap-3">
        <Badge tone={gradeTone[chemical.grade] ?? "neutral"}>
          {chemical.grade} grade
        </Badge>
        {chemical.in_stock !== false && (
          <span className="flex items-center gap-1.5 text-[0.68rem] font-medium text-spark-600 dark:text-spark-400">
            <span
              aria-hidden
              className="size-1.5 rounded-full bg-spark-500"
            />
            In stock
          </span>
        )}
      </div>

      <h3 className="text-base font-bold leading-snug text-fg">
        {/* Stretched link keeps the whole card clickable without nesting
            interactive elements inside an anchor. */}
        <Link
          href={`/products/${chemical.slug}`}
          className="after:absolute after:inset-0 after:content-[''] group-hover:text-spark-700 dark:group-hover:text-spark-300"
        >
          {chemical.name}
        </Link>
      </h3>

      <dl className="mt-2.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-fg-subtle">
        <div className="flex gap-1">
          <dt className="sr-only">CAS number</dt>
          <dd className="font-mono">CAS {chemical.cas_number}</dd>
        </div>
        <span aria-hidden>·</span>
        <div className="flex gap-1">
          <dt className="sr-only">Chemical formula</dt>
          <dd>
            <Formula value={chemical.chemical_formula} />
          </dd>
        </div>
      </dl>

      <p className="mt-3 line-clamp-2 text-sm leading-relaxed text-fg-muted">
        {chemical.description}
      </p>

      <div className="mt-4 flex flex-wrap gap-1.5">
        <span className="rounded-lg bg-surface-2 px-2 py-1 text-[0.68rem] font-medium text-fg-muted">
          {chemical.purity_percentage}
        </span>
        {chemical.category_name && (
          <span className="truncate rounded-lg bg-surface-2 px-2 py-1 text-[0.68rem] font-medium text-fg-muted">
            {chemical.category_name}
          </span>
        )}
      </div>

      <div className="mt-5 flex items-center justify-between gap-3 border-t border-border-base pt-4">
        <span className="flex items-center gap-1 text-xs font-semibold text-fg-muted transition-colors group-hover:text-spark-600 dark:group-hover:text-spark-400">
          View specifications
          <ArrowUpRight aria-hidden className="size-3.5" />
        </span>

        <button
          type="button"
          onClick={() => addItem(chemical)}
          disabled={added}
          aria-label={
            added
              ? `${chemical.name} is in your quotation list`
              : `Add ${chemical.name} to quotation list`
          }
          className={cn(
            // z-10 lifts the button above the card's stretched link.
            "relative z-10 flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-semibold transition-colors",
            added
              ? "bg-spark-50 text-spark-700 dark:bg-spark-500/12 dark:text-spark-300"
              : "bg-navy-800 text-white hover:bg-navy-700 dark:bg-white dark:text-navy-900 dark:hover:bg-navy-100",
          )}
        >
          {added ? (
            <>
              <Check aria-hidden className="size-3.5" />
              Added
            </>
          ) : (
            <>
              <Plus aria-hidden className="size-3.5" />
              Quote
            </>
          )}
        </button>
      </div>
    </article>
  );
}
