"use client";

import { Check, Download, FileText, MessageCircle, Phone, Plus } from "lucide-react";
import type { Chemical } from "@/lib/types";
import { useQuote } from "@/components/providers/QuoteProvider";
import { Button } from "@/components/ui/Button";
import { contact } from "@/lib/site";
import { splitList } from "@/lib/utils";

/**
 * Sticky conversion panel on the product page. Everything a buyer needs to act
 * is here — packaging choice, add-to-RFQ, and the two channels East African
 * buyers actually use to close: phone and WhatsApp.
 */
export function ProductQuoteCard({ chemical }: { chemical: Chemical }) {
  const { addItem, has, openDrawer } = useQuote();
  const added = has(chemical.slug);
  const packaging = splitList(chemical.packaging_options);

  const whatsappText = encodeURIComponent(
    `Hello Sparks Chemicals, I would like a quotation for ${chemical.name} (CAS ${chemical.cas_number}).`,
  );

  return (
    <div className="rounded-2xl border border-border-base bg-surface p-6 shadow-lg">
      <p className="font-mono text-[0.65rem] font-semibold uppercase tracking-[0.16em] text-spark-600 dark:text-spark-400">
        Trade pricing
      </p>
      <p className="mt-2 text-2xl font-extrabold tracking-tight text-fg">
        Quoted per enquiry
      </p>
      <p className="mt-2 text-xs leading-relaxed text-fg-muted">
        Pricing depends on volume, grade and delivery point. Our desk responds
        within two working hours.
      </p>

      {packaging.length > 0 && (
        <div className="mt-5">
          <h3 className="mb-2 text-xs font-semibold text-fg">
            Available packaging
          </h3>
          <ul className="flex flex-wrap gap-1.5">
            {packaging.map((pack) => (
              <li
                key={pack}
                className="rounded-lg bg-surface-2 px-2.5 py-1.5 text-[0.7rem] font-medium text-fg-muted"
              >
                {pack}
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="mt-6 flex flex-col gap-2.5">
        {added ? (
          <Button variant="secondary" onClick={openDrawer} className="w-full">
            <Check aria-hidden className="size-4 text-spark-600" />
            In your list — review &amp; send
          </Button>
        ) : (
          <Button
            variant="accent"
            onClick={() => addItem(chemical)}
            className="w-full"
          >
            <Plus aria-hidden className="size-4" />
            Add to quotation request
          </Button>
        )}

        <a
          href={`${contact.whatsappHref}?text=${whatsappText}`}
          target="_blank"
          rel="noopener noreferrer"
          className="flex h-11 w-full items-center justify-center gap-2 rounded-xl border border-border-strong text-sm font-semibold text-fg transition-colors hover:border-spark-500 hover:text-spark-600 dark:hover:text-spark-400"
        >
          <MessageCircle aria-hidden className="size-4" />
          Enquire on WhatsApp
        </a>

        <a
          href={contact.phoneHref}
          className="flex h-11 w-full items-center justify-center gap-2 rounded-xl text-sm font-semibold text-fg-muted transition-colors hover:text-fg"
        >
          <Phone aria-hidden className="size-4" />
          {contact.phone}
        </a>
      </div>

      {/* Documents */}
      <div className="mt-6 border-t border-border-base pt-5">
        <h3 className="mb-3 text-xs font-semibold text-fg">Documentation</h3>
        <ul className="flex flex-col gap-2">
          <DocumentLink
            href={chemical.sds_url}
            label="Safety Data Sheet (SDS)"
          />
          <DocumentLink
            href={chemical.coa_url}
            label="Certificate of Analysis"
          />
        </ul>
        <p className="mt-3 text-[0.68rem] leading-relaxed text-fg-subtle">
          Batch-specific COA issued with every consignment.
        </p>
      </div>
    </div>
  );
}

function DocumentLink({ href, label }: { href?: string; label: string }) {
  // When a document isn't uploaded yet, point at the contact route rather than
  // rendering a dead link or pretending the file exists.
  if (!href) {
    return (
      <li>
        <a
          href="/contact"
          className="flex items-center gap-2 text-xs text-fg-muted transition-colors hover:text-spark-600 dark:hover:text-spark-400"
        >
          <FileText aria-hidden className="size-3.5" />
          {label} — request a copy
        </a>
      </li>
    );
  }

  return (
    <li>
      <a
        href={href}
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center gap-2 text-xs font-medium text-spark-600 transition-colors hover:underline dark:text-spark-400"
      >
        <Download aria-hidden className="size-3.5" />
        {label}
      </a>
    </li>
  );
}
