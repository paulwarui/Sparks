"use client";

import { useState } from "react";
import { CheckCircle2, Loader2, Send } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { submitInquiry } from "@/lib/api";

const SUBJECTS = [
  "Request a quotation",
  "Technical / product question",
  "Bulk & contract supply",
  "Documentation (SDS / COA)",
  "Export enquiry",
  "Something else",
];

export function ContactForm() {
  const [status, setStatus] = useState<
    "idle" | "submitting" | "success" | "error"
  >("idle");
  const [error, setError] = useState<string>();
  const [form, setForm] = useState({
    full_name: "",
    email: "",
    phone: "",
    company_name: "",
    subject: SUBJECTS[0],
    message: "",
  });

  const setField = (key: keyof typeof form, value: string) =>
    setForm((current) => ({ ...current, [key]: value }));

  async function onSubmit(event: React.FormEvent) {
    event.preventDefault();
    setStatus("submitting");
    setError(undefined);

    const response = await submitInquiry(form);

    if (response.status === "error") {
      setError(response.error ?? "Something went wrong. Please try again.");
      setStatus("error");
      return;
    }
    setStatus("success");
  }

  if (status === "success") {
    return (
      <div
        role="status"
        className="rounded-2xl border border-spark-500/30 bg-spark-50 p-8 text-center dark:bg-spark-500/10"
      >
        <span className="mx-auto mb-4 flex size-14 items-center justify-center rounded-full bg-spark-500 text-white">
          <CheckCircle2 aria-hidden className="size-7" />
        </span>
        <h3 className="text-lg font-bold text-fg">Message received</h3>
        <p className="mx-auto mt-2 max-w-sm text-sm leading-relaxed text-fg-muted">
          Our technical desk will respond within two working hours. For anything
          urgent, call or WhatsApp us directly.
        </p>
      </div>
    );
  }

  return (
    <form
      onSubmit={onSubmit}
      className="rounded-2xl border border-border-base bg-surface p-7"
    >
      <div className="grid gap-4 sm:grid-cols-2">
        <Field
          label="Full name"
          required
          value={form.full_name}
          onChange={(v) => setField("full_name", v)}
          autoComplete="name"
        />
        <Field
          label="Company"
          value={form.company_name}
          onChange={(v) => setField("company_name", v)}
          autoComplete="organization"
        />
        <Field
          label="Email"
          type="email"
          required
          value={form.email}
          onChange={(v) => setField("email", v)}
          autoComplete="email"
        />
        <Field
          label="Phone / WhatsApp"
          type="tel"
          value={form.phone}
          onChange={(v) => setField("phone", v)}
          autoComplete="tel"
        />

        <label className="sm:col-span-2">
          <span className="mb-1.5 block text-xs font-medium text-fg-muted">
            What is this about?
          </span>
          <select
            value={form.subject}
            onChange={(e) => setField("subject", e.target.value)}
            className="w-full rounded-lg border border-border-base bg-surface px-3 py-2.5 text-sm text-fg outline-none focus:border-spark-500"
          >
            {SUBJECTS.map((subject) => (
              <option key={subject} value={subject}>
                {subject}
              </option>
            ))}
          </select>
        </label>

        <label className="sm:col-span-2">
          <span className="mb-1.5 block text-xs font-medium text-fg-muted">
            Your message<span className="text-spark-600"> *</span>
          </span>
          <textarea
            required
            rows={5}
            value={form.message}
            onChange={(e) => setField("message", e.target.value)}
            placeholder="Tell us the chemical, grade, volume and delivery location — or describe the process problem you're solving."
            className="w-full resize-none rounded-lg border border-border-base bg-surface px-3 py-2.5 text-sm text-fg outline-none focus:border-spark-500"
          />
        </label>
      </div>

      {error && (
        <p
          role="alert"
          className="mt-4 rounded-lg border border-red-200 bg-red-50 px-3 py-2.5 text-xs text-red-700 dark:border-red-500/30 dark:bg-red-500/10 dark:text-red-300"
        >
          {error}
        </p>
      )}

      <Button
        type="submit"
        variant="accent"
        className="mt-6 w-full"
        disabled={status === "submitting"}
      >
        {status === "submitting" ? (
          <>
            <Loader2 aria-hidden className="size-4 animate-spin" />
            Sending…
          </>
        ) : (
          <>
            <Send aria-hidden className="size-4" />
            Send message
          </>
        )}
      </Button>
      <p className="mt-3 text-center text-[0.68rem] text-fg-subtle">
        We reply within two working hours, Monday to Saturday.
      </p>
    </form>
  );
}

function Field({
  label,
  value,
  onChange,
  type = "text",
  required,
  autoComplete,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  type?: string;
  required?: boolean;
  autoComplete?: string;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-medium text-fg-muted">
        {label}
        {required && <span className="text-spark-600"> *</span>}
      </span>
      <input
        type={type}
        value={value}
        required={required}
        autoComplete={autoComplete}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-lg border border-border-base bg-surface px-3 py-2.5 text-sm text-fg outline-none focus:border-spark-500"
      />
    </label>
  );
}
