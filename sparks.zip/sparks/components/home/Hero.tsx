"use client";

import { ArrowRight, FileText, Phone, Search, ShieldCheck } from "lucide-react";
import { MolecularField } from "./MolecularField";
import { Button, ButtonLink } from "@/components/ui/Button";
import { Container } from "@/components/ui/primitives";
import { useUI } from "@/components/providers/UIProvider";
import { useQuote } from "@/components/providers/QuoteProvider";
import { contact, trustMetrics } from "@/lib/site";

const QUICK_SEARCHES = [
  { label: "Caustic Soda", q: "caustic soda" },
  { label: "CAS 7664-93-9", q: "7664-93-9" },
  { label: "HTH Chlorine", q: "calcium hypochlorite" },
  { label: "LABSA 96%", q: "labsa" },
];

export function Hero() {
  const { openSearch } = useUI();
  const { openDrawer } = useQuote();

  return (
    <section className="relative isolate overflow-hidden pb-20 pt-32 sm:pb-28 sm:pt-40">
      {/* Layered background: graph paper, molecular field, brand light bloom. */}
      <div aria-hidden className="absolute inset-0 -z-10 grid-bg" />
      <div aria-hidden className="absolute inset-0 -z-10">
        <MolecularField />
      </div>
      <div
        aria-hidden
        className="absolute left-1/2 top-[-12rem] -z-10 h-[34rem] w-[52rem] -translate-x-1/2 rounded-full bg-spark-400/18 blur-[130px] dark:bg-spark-500/12"
      />
      <div
        aria-hidden
        className="absolute -right-40 top-40 -z-10 size-[30rem] rounded-full bg-navy-400/15 blur-[120px] dark:bg-navy-500/12"
      />
      <div
        aria-hidden
        className="absolute inset-x-0 bottom-0 -z-10 h-40 bg-gradient-to-b from-transparent to-bg"
      />

      <Container>
        <div className="mx-auto max-w-4xl text-center">
          <p className="inline-flex items-center gap-2 rounded-full border border-spark-500/30 bg-spark-50/80 px-4 py-1.5 text-xs font-semibold text-spark-700 backdrop-blur-sm animate-fade-in dark:bg-spark-500/10 dark:text-spark-300">
            <ShieldCheck aria-hidden className="size-3.5" />
            ISO 9001:2015 certified · KEBS approved · Serving 12 African markets
          </p>

          <h1 className="mt-7 text-4xl font-extrabold leading-[1.08] tracking-tight sm:text-6xl lg:text-7xl animate-fade-up">
            Powering Africa Through{" "}
            <span className="brand-gradient-text">
              Innovative Chemical Solutions
            </span>
          </h1>

          <p
            className="mx-auto mt-6 max-w-2xl text-base leading-relaxed text-fg-muted sm:text-lg animate-fade-up"
            style={{ animationDelay: "80ms" }}
          >
            Premium industrial, laboratory, food, water treatment, agricultural
            and pharmaceutical chemicals — sourced, tested and delivered from
            Nairobi across East Africa and worldwide.
          </p>

          {/* Search is the primary entry point, so it outranks the CTAs. */}
          <div
            className="mx-auto mt-9 max-w-2xl animate-fade-up"
            style={{ animationDelay: "140ms" }}
          >
            <button
              type="button"
              onClick={openSearch}
              className="group flex w-full items-center gap-3 rounded-2xl border border-border-strong bg-surface/90 p-2 pl-4 text-left shadow-xl backdrop-blur-md transition-colors hover:border-spark-500/60"
            >
              <Search
                aria-hidden
                className="size-5 shrink-0 text-spark-600 dark:text-spark-400"
              />
              <span className="min-w-0 flex-1 truncate py-2.5 text-sm text-fg-subtle">
                Search 1,500+ chemicals by name, CAS number or formula…
              </span>
              <span className="hidden shrink-0 items-center gap-1.5 rounded-xl bg-navy-800 px-4 py-2.5 text-xs font-semibold text-white transition-colors group-hover:bg-navy-700 sm:flex dark:bg-white dark:text-navy-900">
                Search
                <ArrowRight aria-hidden className="size-3.5" />
              </span>
            </button>

            <div className="mt-3 flex flex-wrap items-center justify-center gap-2 text-xs">
              <span className="text-fg-subtle">Popular:</span>
              {QUICK_SEARCHES.map((item) => (
                <a
                  key={item.label}
                  href={`/products?q=${encodeURIComponent(item.q)}`}
                  className="rounded-lg bg-surface-2 px-2.5 py-1 font-medium text-fg-muted transition-colors hover:bg-spark-50 hover:text-spark-700 dark:hover:bg-spark-500/10 dark:hover:text-spark-300"
                >
                  {item.label}
                </a>
              ))}
            </div>
          </div>

          <div
            className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row animate-fade-up"
            style={{ animationDelay: "200ms" }}
          >
            <ButtonLink href="/products" size="lg" className="w-full sm:w-auto">
              Browse chemicals
              <ArrowRight aria-hidden className="size-4" />
            </ButtonLink>
            <Button
              variant="accent"
              size="lg"
              onClick={openDrawer}
              className="w-full sm:w-auto"
            >
              <FileText aria-hidden className="size-4" />
              Request quotation
            </Button>
            <ButtonLink
              href={contact.phoneHref}
              variant="outline"
              size="lg"
              className="w-full sm:w-auto"
            >
              <Phone aria-hidden className="size-4" />
              Contact sales
            </ButtonLink>
          </div>
        </div>

        {/* Proof metrics */}
        <dl
          className="mx-auto mt-16 grid max-w-5xl grid-cols-2 gap-3 sm:mt-20 lg:grid-cols-4 animate-fade-up"
          style={{ animationDelay: "260ms" }}
        >
          {trustMetrics.map((metric) => (
            <div
              key={metric.label}
              className="glass rounded-2xl px-5 py-6 text-left"
            >
              <dt className="sr-only">{metric.label}</dt>
              <dd>
                <span className="block font-mono text-2xl font-extrabold tracking-tight text-fg sm:text-3xl">
                  {metric.value}
                </span>
                <span className="mt-1.5 block text-xs leading-relaxed text-fg-muted">
                  {metric.label}
                </span>
              </dd>
            </div>
          ))}
        </dl>
      </Container>
    </section>
  );
}
