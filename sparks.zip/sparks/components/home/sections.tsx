import Link from "next/link";
import {
  Award,
  Beaker,
  ClipboardCheck,
  Droplets,
  FlaskConical,
  Globe2,
  Headphones,
  Microscope,
  Package,
  ShieldCheck,
  Sprout,
  Truck,
  type LucideIcon,
} from "lucide-react";
import {
  Container,
  Eyebrow,
  Section,
  SectionHeading,
} from "@/components/ui/primitives";
import { ButtonLink } from "@/components/ui/Button";
import { ChemicalCard } from "@/components/catalog/ChemicalCard";
import { certifications, markets } from "@/lib/site";
import { formatDate } from "@/lib/utils";
import type { Article, Chemical, Industry } from "@/lib/types";

/* -------------------------------------------------------------------------- */
/*  Industry iconography                                                      */
/* -------------------------------------------------------------------------- */

/**
 * Industries carry an icon name from the Django admin. Mapping it explicitly
 * keeps the bundle tree-shakeable and guarantees a sensible fallback when an
 * editor types an icon name that doesn't exist.
 */
const INDUSTRY_ICONS: Record<string, LucideIcon> = {
  Droplets,
  Utensils: Package,
  Sprout,
  Pickaxe: Package,
  Building2: Package,
  Pill: Beaker,
  Sparkles: FlaskConical,
  SprayCan: Droplets,
  ShieldCheck,
  Paintbrush: FlaskConical,
  Shirt: Package,
  Flame: FlaskConical,
  TestTube: Microscope,
  TestTube2: Microscope,
};

function industryIcon(name?: string): LucideIcon {
  return (name && INDUSTRY_ICONS[name]) || FlaskConical;
}

/* -------------------------------------------------------------------------- */
/*  Trust bar                                                                 */
/* -------------------------------------------------------------------------- */

export function TrustBar() {
  return (
    <section
      aria-label="Certifications and compliance"
      className="border-y border-border-base bg-surface-2/60 py-6"
    >
      <Container>
        <div className="flex flex-wrap items-center justify-center gap-x-8 gap-y-4">
          <p className="font-mono text-[0.68rem] font-semibold uppercase tracking-[0.18em] text-fg-subtle">
            Certified &amp; compliant
          </p>
          {certifications.map((cert) => (
            <div key={cert.name} className="flex items-center gap-2">
              <Award
                aria-hidden
                className="size-4 text-spark-600 dark:text-spark-400"
              />
              <span className="text-sm font-semibold text-fg-muted">
                {cert.name}
              </span>
            </div>
          ))}
        </div>
      </Container>
    </section>
  );
}

/* -------------------------------------------------------------------------- */
/*  Featured catalogue                                                        */
/* -------------------------------------------------------------------------- */

export function FeaturedChemicals({ chemicals }: { chemicals: Chemical[] }) {
  if (chemicals.length === 0) return null;

  return (
    <Section>
      <Container>
        <div className="flex flex-wrap items-end justify-between gap-6">
          <SectionHeading
            eyebrow="Best sellers"
            title="The chemicals East Africa orders most"
            description="Held in stock at our Nairobi and Mombasa depots, with certificates of analysis and safety data sheets available on every batch."
          />
          <ButtonLink href="/products" variant="outline">
            View full catalogue
          </ButtonLink>
        </div>

        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {chemicals.slice(0, 6).map((chemical) => (
            <ChemicalCard key={chemical.slug} chemical={chemical} />
          ))}
        </div>
      </Container>
    </Section>
  );
}

/* -------------------------------------------------------------------------- */
/*  Industries                                                                */
/* -------------------------------------------------------------------------- */

export function IndustriesGrid({ industries }: { industries: Industry[] }) {
  return (
    <Section className="border-y border-border-base bg-surface-2/40">
      <Container>
        <SectionHeading
          eyebrow="Industries served"
          title="Formulated for how your sector actually works"
          description="Each industry has its own compliance regime, purity thresholds and delivery realities. Choose your sector to see the products and technical guidance that apply to it."
          align="center"
          className="mx-auto items-center"
        />

        <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {industries.map((industry) => {
            const Icon = industryIcon(industry.icon);
            return (
              <Link
                key={industry.slug}
                href={`/industries/${industry.slug}`}
                className="group rounded-2xl border border-border-base bg-surface p-6 lift"
              >
                <span className="mb-4 flex size-11 items-center justify-center rounded-xl bg-navy-50 text-navy-700 transition-colors group-hover:bg-spark-50 group-hover:text-spark-600 dark:bg-navy-400/10 dark:text-navy-200 dark:group-hover:bg-spark-500/12 dark:group-hover:text-spark-400">
                  <Icon aria-hidden className="size-5" />
                </span>
                <h3 className="text-base font-bold text-fg group-hover:text-spark-700 dark:group-hover:text-spark-300">
                  {industry.name}
                </h3>
                <p className="mt-2 line-clamp-3 text-sm leading-relaxed text-fg-muted">
                  {industry.description}
                </p>
                {typeof industry.chemical_count === "number" &&
                  industry.chemical_count > 0 && (
                    <p className="mt-4 font-mono text-[0.68rem] uppercase tracking-wider text-fg-subtle">
                      {industry.chemical_count} products
                    </p>
                  )}
              </Link>
            );
          })}
        </div>
      </Container>
    </Section>
  );
}

/* -------------------------------------------------------------------------- */
/*  Capability / why Sparks                                                   */
/* -------------------------------------------------------------------------- */

const CAPABILITIES = [
  {
    icon: Microscope,
    title: "Verified on arrival",
    body: "Every consignment ships with a certificate of analysis, and we retain samples so any batch can be re-tested against its COA on request.",
  },
  {
    icon: Truck,
    title: "Logistics built for the region",
    body: "Same-day dispatch within Nairobi, next-day to Mombasa and Kisumu, and bonded transit documentation for Uganda, Tanzania, Rwanda and South Sudan.",
  },
  {
    icon: ClipboardCheck,
    title: "Regulatory paperwork handled",
    body: "KEBS import standardisation marks, NEMA handling permits, PCPB registration and GHS-compliant labelling prepared before your goods move.",
  },
  {
    icon: Package,
    title: "Packaging that suits your line",
    body: "From 500g laboratory bottles to 1,000kg jumbo bags and full ISO tankers — repacked in-house under controlled conditions.",
  },
  {
    icon: Headphones,
    title: "Engineers, not order-takers",
    body: "Our technical desk sizes dosing rates, troubleshoots formulations and recommends substitutes when a raw material is constrained.",
  },
  {
    icon: Globe2,
    title: "Global sourcing network",
    body: "Direct relationships with manufacturers across China, India, the Gulf and Europe mean shorter lead times and pricing that holds.",
  },
];

export function Capabilities() {
  return (
    <Section>
      <Container>
        <div className="grid gap-14 lg:grid-cols-[0.9fr_1.1fr]">
          <div className="lg:sticky lg:top-32 lg:self-start">
            <SectionHeading
              eyebrow="Why Sparks"
              title="A chemical supplier that behaves like an engineering partner"
              description="Sourcing raw materials in East Africa usually means opaque pricing, unverifiable quality and paperwork that stalls at the border. We built the opposite."
            />
            <div className="mt-8 flex flex-wrap gap-2">
              {markets.map((market) => (
                <span
                  key={market}
                  className="rounded-lg border border-border-base px-2.5 py-1.5 text-xs font-medium text-fg-muted"
                >
                  {market}
                </span>
              ))}
            </div>
            <ButtonLink href="/about" className="mt-8">
              About our operation
            </ButtonLink>
          </div>

          <ul className="grid gap-4 sm:grid-cols-2">
            {CAPABILITIES.map((item) => (
              <li
                key={item.title}
                className="rounded-2xl border border-border-base bg-surface p-6"
              >
                <span className="mb-4 flex size-10 items-center justify-center rounded-xl bg-spark-50 text-spark-600 dark:bg-spark-500/12 dark:text-spark-400">
                  <item.icon aria-hidden className="size-5" />
                </span>
                <h3 className="text-sm font-bold text-fg">{item.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-fg-muted">
                  {item.body}
                </p>
              </li>
            ))}
          </ul>
        </div>
      </Container>
    </Section>
  );
}

/* -------------------------------------------------------------------------- */
/*  Process                                                                   */
/* -------------------------------------------------------------------------- */

const STEPS = [
  {
    step: "01",
    title: "Tell us what you need",
    body: "Search by name, CAS number or formula — or describe the outcome and let our AI advisor and engineers identify the right material.",
  },
  {
    step: "02",
    title: "Receive a costed quotation",
    body: "Delivered pricing, lead time, packaging options and documentation, back to you within two working hours.",
  },
  {
    step: "03",
    title: "Quality confirmed before dispatch",
    body: "Batch tested against specification, with COA, SDS and compliance marks issued with the consignment.",
  },
  {
    step: "04",
    title: "Delivered and supported",
    body: "Tracked delivery across the region, then ongoing technical support on dosing, storage and handling.",
  },
];

export function ProcessSection() {
  return (
    <Section className="border-y border-border-base bg-navy-900 text-white dark:bg-navy-950">
      <Container>
        <div className="max-w-3xl">
          <Eyebrow className="text-spark-400">How it works</Eyebrow>
          <h2 className="mt-4 text-3xl font-bold tracking-tight sm:text-4xl">
            From enquiry to delivered consignment in four steps
          </h2>
          <p className="mt-4 text-base leading-relaxed text-navy-200/80">
            No account creation, no minimum order barrier, no waiting a week for
            a price.
          </p>
        </div>

        <ol className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {STEPS.map((item) => (
            <li key={item.step} className="relative">
              <span className="font-mono text-3xl font-extrabold text-spark-400/40">
                {item.step}
              </span>
              <h3 className="mt-3 text-base font-bold">{item.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-navy-200/75">
                {item.body}
              </p>
            </li>
          ))}
        </ol>
      </Container>
    </Section>
  );
}

/* -------------------------------------------------------------------------- */
/*  Knowledge centre teaser                                                   */
/* -------------------------------------------------------------------------- */

export function KnowledgeTeaser({ articles }: { articles: Article[] }) {
  if (articles.length === 0) return null;

  return (
    <Section>
      <Container>
        <div className="flex flex-wrap items-end justify-between gap-6">
          <SectionHeading
            eyebrow="Knowledge centre"
            title="Technical guidance from our engineers"
            description="Practical, regionally specific guidance on chemical safety, water treatment, storage and compliance."
          />
          <ButtonLink href="/blog" variant="outline">
            All articles
          </ButtonLink>
        </div>

        <div className="mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {articles.slice(0, 3).map((article) => (
            <Link
              key={article.slug}
              href={`/blog/${article.slug}`}
              className="group flex flex-col rounded-2xl border border-border-base bg-surface p-6 lift"
            >
              {article.category_name && (
                <span className="font-mono text-[0.65rem] font-semibold uppercase tracking-[0.16em] text-spark-600 dark:text-spark-400">
                  {article.category_name}
                </span>
              )}
              <h3 className="mt-3 text-base font-bold leading-snug text-fg group-hover:text-spark-700 dark:group-hover:text-spark-300">
                {article.title}
              </h3>
              <p className="mt-2.5 line-clamp-3 flex-1 text-sm leading-relaxed text-fg-muted">
                {article.summary}
              </p>
              <p className="mt-5 flex items-center gap-2 text-xs text-fg-subtle">
                <time dateTime={article.published_at}>
                  {formatDate(article.published_at)}
                </time>
                <span aria-hidden>·</span>
                <span>{article.read_time_minutes} min read</span>
              </p>
            </Link>
          ))}
        </div>
      </Container>
    </Section>
  );
}

/* -------------------------------------------------------------------------- */
/*  Closing CTA                                                               */
/* -------------------------------------------------------------------------- */

export function ClosingCTA() {
  return (
    <Section className="pb-24">
      <Container>
        <div className="relative isolate overflow-hidden rounded-3xl border border-border-base bg-surface px-8 py-16 text-center sm:px-16">
          <div
            aria-hidden
            className="absolute left-1/2 top-0 -z-10 h-64 w-[40rem] -translate-x-1/2 rounded-full bg-spark-400/15 blur-[100px]"
          />
          <div aria-hidden className="absolute inset-0 -z-10 grid-bg opacity-60" />

          <h2 className="mx-auto max-w-2xl text-3xl font-bold tracking-tight sm:text-4xl">
            Tell us what you need. We&apos;ll price it within two hours.
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-base leading-relaxed text-fg-muted">
            Send a specification, a CAS number, or simply describe the problem
            you&apos;re solving — our technical desk will do the rest.
          </p>
          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <ButtonLink href="/quote" variant="accent" size="lg">
              Request a quotation
            </ButtonLink>
            <ButtonLink href="/contact" variant="outline" size="lg">
              Talk to our engineers
            </ButtonLink>
          </div>
        </div>
      </Container>
    </Section>
  );
}
