import Link from "next/link";
import Image from "next/image";
import { Mail, MapPin, MessageCircle, Phone } from "lucide-react";
import { Container } from "@/components/ui/primitives";
import {
  certifications,
  company,
  contact,
  footerNav,
  markets,
  social,
} from "@/lib/site";
import type { Industry } from "@/lib/types";

export function Footer({ industries }: { industries: Industry[] }) {
  const year = new Date().getFullYear();

  return (
    <footer className="mt-auto border-t border-border-base bg-navy-900 text-navy-100 dark:bg-navy-950">
      <Container className="py-16">
        <div className="grid gap-12 lg:grid-cols-[1.4fr_repeat(3,1fr)]">
          {/* Identity + contact */}
          <div>
            <Image
              src="/sparks-logo-full.png"
              alt={`${company.legalName} logo`}
              width={180}
              height={176}
              className="mb-5 h-auto w-[150px] brightness-0 invert"
            />
            <p className="max-w-sm text-sm leading-relaxed text-navy-200/80">
              {company.description}
            </p>

            <address className="mt-6 flex flex-col gap-3 text-sm not-italic">
              <a
                href={contact.phoneHref}
                className="flex items-center gap-2.5 text-navy-100 transition-colors hover:text-spark-300"
              >
                <Phone aria-hidden className="size-4 text-spark-400" />
                {contact.phone}
              </a>
              <a
                href={contact.emailHref}
                className="flex items-center gap-2.5 text-navy-100 transition-colors hover:text-spark-300"
              >
                <Mail aria-hidden className="size-4 text-spark-400" />
                {contact.email}
              </a>
              <a
                href={contact.whatsappHref}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2.5 text-navy-100 transition-colors hover:text-spark-300"
              >
                <MessageCircle aria-hidden className="size-4 text-spark-400" />
                WhatsApp sales desk
              </a>
              <span className="flex items-start gap-2.5 text-navy-200/80">
                <MapPin aria-hidden className="mt-0.5 size-4 shrink-0 text-spark-400" />
                <span>
                  {contact.address.street}
                  <br />
                  {contact.address.locality}, {contact.address.countryName}
                </span>
              </span>
            </address>
          </div>

          {footerNav.map((column) => (
            <nav key={column.title} aria-label={column.title}>
              <h2 className="mb-4 font-mono text-xs font-semibold uppercase tracking-[0.16em] text-spark-400">
                {column.title}
              </h2>
              <ul className="flex flex-col gap-2.5 text-sm">
                {column.links.map((link) => (
                  <li key={link.href}>
                    <Link
                      href={link.href}
                      className="text-navy-200/85 transition-colors hover:text-white"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </nav>
          ))}
        </div>

        {/* Industry links — a deliberate internal-linking surface for crawlers. */}
        <div className="mt-14 border-t border-white/10 pt-8">
          <h2 className="mb-4 font-mono text-xs font-semibold uppercase tracking-[0.16em] text-spark-400">
            Industries we supply
          </h2>
          <ul className="flex flex-wrap gap-x-5 gap-y-2 text-sm">
            {industries.map((industry) => (
              <li key={industry.slug}>
                <Link
                  href={`/industries/${industry.slug}`}
                  className="text-navy-200/80 transition-colors hover:text-spark-300"
                >
                  {industry.name}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        {/* Certifications */}
        <div className="mt-10 flex flex-wrap gap-3">
          {certifications.map((cert) => (
            <span
              key={cert.name}
              title={cert.detail}
              className="rounded-lg border border-white/12 bg-white/5 px-3 py-1.5 text-xs font-medium text-navy-100"
            >
              {cert.name}
            </span>
          ))}
        </div>

        <p className="mt-8 text-xs leading-relaxed text-navy-300/60">
          Serving {markets.slice(0, -1).join(", ")} and {markets.at(-1)}, with
          export documentation for global destinations.
        </p>
      </Container>

      <div className="border-t border-white/10">
        <Container className="flex flex-col items-center justify-between gap-4 py-6 text-xs text-navy-300/70 sm:flex-row">
          <p>
            © {year} {company.legalName}. All rights reserved.
          </p>
          <div className="flex items-center gap-5">
            <a
              href={social.linkedin}
              target="_blank"
              rel="noopener noreferrer"
              className="transition-colors hover:text-spark-300"
            >
              LinkedIn
            </a>
            <a
              href={social.twitter}
              target="_blank"
              rel="noopener noreferrer"
              className="transition-colors hover:text-spark-300"
            >
              X / Twitter
            </a>
            <Link href="/contact" className="transition-colors hover:text-spark-300">
              Contact
            </Link>
          </div>
        </Container>
      </div>
    </footer>
  );
}
