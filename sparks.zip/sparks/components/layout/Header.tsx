"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import {
  Bot,
  ChevronDown,
  FileText,
  Menu,
  Moon,
  Phone,
  Search,
  Sun,
  X,
} from "lucide-react";
import { SparksLogo } from "@/components/brand/SparksLogo";
import { Button, ButtonLink } from "@/components/ui/Button";
import { useUI } from "@/components/providers/UIProvider";
import { useQuote } from "@/components/providers/QuoteProvider";
import { useTheme } from "@/components/providers/ThemeProvider";
import { contact, primaryNav } from "@/lib/site";
import { cn } from "@/lib/utils";
import type { Industry } from "@/lib/types";

export function Header({ industries }: { industries: Industry[] }) {
  const pathname = usePathname();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [megaOpen, setMegaOpen] = useState(false);
  const { openSearch, openAI } = useUI();
  const { count, openDrawer } = useQuote();
  const { theme, toggleTheme } = useTheme();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Any navigation should dismiss the mobile drawer and the mega menu.
  useEffect(() => {
    setMobileOpen(false);
    setMegaOpen(false);
  }, [pathname]);

  useEffect(() => {
    if (!mobileOpen) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previous;
    };
  }, [mobileOpen]);

  const isActive = (href: string) =>
    href === "/" ? pathname === "/" : pathname.startsWith(href);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-300",
        scrolled
          ? "glass border-b border-border-base shadow-sm"
          : "border-b border-transparent bg-transparent",
      )}
    >
      {/* Utility strip — contact affordances above the primary nav. */}
      <div className="hidden bg-navy-800 text-white lg:block dark:bg-navy-950">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-8 py-1.5 text-xs">
          <p className="text-white/75">
            ISO 9001:2015 certified · KEBS approved · Same-day dispatch in Nairobi
          </p>
          <div className="flex items-center gap-5">
            <a
              href={contact.phoneHref}
              className="flex items-center gap-1.5 text-white/85 transition-colors hover:text-spark-300"
            >
              <Phone aria-hidden className="size-3.5" />
              {contact.phone}
            </a>
            <a
              href={contact.whatsappHref}
              target="_blank"
              rel="noopener noreferrer"
              className="font-medium text-spark-300 transition-colors hover:text-spark-200"
            >
              WhatsApp our sales desk
            </a>
          </div>
        </div>
      </div>

      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-5 py-3 sm:px-8">
        <Link href="/" aria-label="Sparks Chemicals — home" className="shrink-0">
          <SparksLogo size={38} priority />
        </Link>

        {/* Desktop navigation */}
        <nav aria-label="Primary" className="hidden items-center gap-1 lg:flex">
          <div
            className="relative"
            onMouseEnter={() => setMegaOpen(true)}
            onMouseLeave={() => setMegaOpen(false)}
          >
            <Link
              href="/industries"
              aria-expanded={megaOpen}
              className={cn(
                "flex items-center gap-1 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
                isActive("/industries")
                  ? "text-spark-600 dark:text-spark-400"
                  : "text-fg-muted hover:text-fg",
              )}
            >
              Industries
              <ChevronDown
                aria-hidden
                className={cn(
                  "size-3.5 transition-transform",
                  megaOpen && "rotate-180",
                )}
              />
            </Link>

            {megaOpen && (
              <div className="absolute left-1/2 top-full w-[42rem] -translate-x-1/2 pt-3">
                <div className="grid grid-cols-2 gap-1 rounded-2xl border border-border-base bg-surface p-3 shadow-2xl">
                  {industries.slice(0, 12).map((industry) => (
                    <Link
                      key={industry.slug}
                      href={`/industries/${industry.slug}`}
                      className="group rounded-xl px-3 py-2.5 transition-colors hover:bg-surface-2"
                    >
                      <span className="block text-sm font-semibold text-fg group-hover:text-spark-600 dark:group-hover:text-spark-400">
                        {industry.name}
                      </span>
                      <span className="mt-0.5 line-clamp-1 block text-xs text-fg-subtle">
                        {industry.description}
                      </span>
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </div>

          {primaryNav
            .filter((link) => link.href !== "/industries")
            .map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={cn(
                  "rounded-lg px-3 py-2 text-sm font-medium transition-colors",
                  isActive(link.href)
                    ? "text-spark-600 dark:text-spark-400"
                    : "text-fg-muted hover:text-fg",
                )}
              >
                {link.label}
              </Link>
            ))}
        </nav>

        {/* Actions */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={openSearch}
            className="flex items-center gap-2 rounded-xl border border-border-base bg-surface-2 px-3 py-2 text-xs text-fg-subtle transition-colors hover:border-spark-500/50 hover:text-fg"
          >
            <Search
              aria-hidden
              className="size-4 text-spark-600 dark:text-spark-400"
            />
            <span className="hidden xl:inline">Search name, CAS or formula</span>
            <kbd className="hidden rounded border border-border-base bg-surface px-1.5 py-0.5 font-mono text-[10px] xl:inline">
              ⌘K
            </kbd>
            <span className="sr-only">Open global chemical search</span>
          </button>

          <button
            type="button"
            onClick={openAI}
            aria-label="Open the Sparks AI technical advisor"
            className="hidden rounded-xl border border-spark-500/30 bg-spark-50 p-2.5 text-spark-700 transition-colors hover:bg-spark-100 sm:block dark:bg-spark-500/10 dark:text-spark-300 dark:hover:bg-spark-500/20"
          >
            <Bot aria-hidden className="size-4" />
          </button>

          <button
            type="button"
            onClick={toggleTheme}
            aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} theme`}
            className="rounded-xl border border-border-base p-2.5 text-fg-muted transition-colors hover:text-fg"
          >
            {theme === "dark" ? (
              <Sun aria-hidden className="size-4" />
            ) : (
              <Moon aria-hidden className="size-4" />
            )}
          </button>

          <Button
            variant="accent"
            size="sm"
            onClick={openDrawer}
            className="relative hidden sm:inline-flex"
          >
            <FileText aria-hidden className="size-4" />
            Request quote
            {count > 0 && (
              <span className="ml-1 inline-flex size-5 items-center justify-center rounded-full bg-white text-[10px] font-bold text-spark-700 dark:bg-navy-950 dark:text-spark-300">
                {count}
              </span>
            )}
          </Button>

          <button
            type="button"
            onClick={() => setMobileOpen((open) => !open)}
            aria-expanded={mobileOpen}
            aria-controls="mobile-nav"
            aria-label={mobileOpen ? "Close menu" : "Open menu"}
            className="rounded-xl border border-border-base p-2.5 text-fg lg:hidden"
          >
            {mobileOpen ? (
              <X aria-hidden className="size-5" />
            ) : (
              <Menu aria-hidden className="size-5" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div
          id="mobile-nav"
          className="max-h-[calc(100vh-4rem)] overflow-y-auto border-t border-border-base bg-surface px-5 py-6 lg:hidden"
        >
          <nav aria-label="Mobile" className="flex flex-col gap-1">
            {primaryNav.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={cn(
                  "rounded-xl px-3 py-3 text-base font-medium transition-colors",
                  isActive(link.href)
                    ? "bg-spark-50 text-spark-700 dark:bg-spark-500/10 dark:text-spark-300"
                    : "text-fg hover:bg-surface-2",
                )}
              >
                {link.label}
              </Link>
            ))}
          </nav>

          <div className="mt-5 flex flex-col gap-2.5 border-t border-border-base pt-5">
            <Button variant="accent" onClick={openDrawer}>
              <FileText aria-hidden className="size-4" />
              Request quotation {count > 0 && `(${count})`}
            </Button>
            <Button variant="outline" onClick={openAI}>
              <Bot aria-hidden className="size-4" />
              Ask Sparks AI
            </Button>
            <ButtonLink variant="ghost" href={contact.phoneHref}>
              <Phone aria-hidden className="size-4" />
              {contact.phone}
            </ButtonLink>
          </div>
        </div>
      )}
    </header>
  );
}
