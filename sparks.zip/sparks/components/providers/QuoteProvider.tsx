"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import type { Chemical, QuoteLineItem } from "@/lib/types";

const STORAGE_KEY = "sparks-quote-cart";

interface QuoteContextValue {
  items: QuoteLineItem[];
  count: number;
  isOpen: boolean;
  has: (slug: string) => boolean;
  addItem: (chemical: Chemical, overrides?: Partial<QuoteLineItem>) => void;
  updateItem: (slug: string, patch: Partial<QuoteLineItem>) => void;
  removeItem: (slug: string) => void;
  clear: () => void;
  openDrawer: () => void;
  closeDrawer: () => void;
}

const QuoteContext = createContext<QuoteContextValue | null>(null);

/**
 * The quotation basket. Persisted to localStorage so a buyer assembling a
 * 20-line enquiry across several sessions never loses their list — abandoning
 * a half-built RFQ is the single biggest conversion leak on supplier sites.
 */
export function QuoteProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<QuoteLineItem[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setItems(JSON.parse(raw) as QuoteLineItem[]);
    } catch {
      // Corrupt or unavailable storage — start with an empty basket.
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return; // Don't overwrite storage before the initial read.
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
    } catch {
      // Ignore quota / private-mode failures.
    }
  }, [items, hydrated]);

  // Lock body scroll while the drawer is open.
  useEffect(() => {
    if (!isOpen) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previous;
    };
  }, [isOpen]);

  const addItem = useCallback(
    (chemical: Chemical, overrides: Partial<QuoteLineItem> = {}) => {
      setItems((current) => {
        if (current.some((i) => i.slug === chemical.slug)) return current;
        const firstPack =
          chemical.packaging_options?.split(",")[0]?.trim() ?? "Bulk";
        return [
          ...current,
          {
            slug: chemical.slug,
            name: chemical.name,
            cas_number: chemical.cas_number,
            grade: chemical.grade,
            quantity: "1",
            packaging: firstPack,
            ...overrides,
          },
        ];
      });
      setIsOpen(true);
    },
    [],
  );

  const updateItem = useCallback(
    (slug: string, patch: Partial<QuoteLineItem>) => {
      setItems((current) =>
        current.map((i) => (i.slug === slug ? { ...i, ...patch } : i)),
      );
    },
    [],
  );

  const removeItem = useCallback((slug: string) => {
    setItems((current) => current.filter((i) => i.slug !== slug));
  }, []);

  const clear = useCallback(() => setItems([]), []);
  const openDrawer = useCallback(() => setIsOpen(true), []);
  const closeDrawer = useCallback(() => setIsOpen(false), []);

  const value = useMemo<QuoteContextValue>(
    () => ({
      items,
      count: items.length,
      isOpen,
      has: (slug) => items.some((i) => i.slug === slug),
      addItem,
      updateItem,
      removeItem,
      clear,
      openDrawer,
      closeDrawer,
    }),
    [items, isOpen, addItem, updateItem, removeItem, clear, openDrawer, closeDrawer],
  );

  return (
    <QuoteContext.Provider value={value}>{children}</QuoteContext.Provider>
  );
}

export function useQuote() {
  const ctx = useContext(QuoteContext);
  if (!ctx) throw new Error("useQuote must be used inside <QuoteProvider>");
  return ctx;
}
