"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";

interface UIContextValue {
  searchOpen: boolean;
  openSearch: () => void;
  closeSearch: () => void;
  aiOpen: boolean;
  openAI: () => void;
  closeAI: () => void;
  toggleAI: () => void;
}

const UIContext = createContext<UIContextValue | null>(null);

/**
 * Holds the state for the two global overlays (command search and the AI
 * advisor) so any component — header, hero, product page, empty states — can
 * summon them without prop drilling.
 */
export function UIProvider({ children }: { children: React.ReactNode }) {
  const [searchOpen, setSearchOpen] = useState(false);
  const [aiOpen, setAIOpen] = useState(false);

  const openSearch = useCallback(() => setSearchOpen(true), []);
  const closeSearch = useCallback(() => setSearchOpen(false), []);
  const openAI = useCallback(() => setAIOpen(true), []);
  const closeAI = useCallback(() => setAIOpen(false), []);
  const toggleAI = useCallback(() => setAIOpen((v) => !v), []);

  // ⌘K / Ctrl+K opens search; Escape closes whichever overlay is on top.
  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "k" && (event.metaKey || event.ctrlKey)) {
        event.preventDefault();
        setSearchOpen((open) => !open);
      }
      if (event.key === "Escape") {
        setSearchOpen(false);
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);

  const value = useMemo(
    () => ({
      searchOpen,
      openSearch,
      closeSearch,
      aiOpen,
      openAI,
      closeAI,
      toggleAI,
    }),
    [searchOpen, aiOpen, openSearch, closeSearch, openAI, closeAI, toggleAI],
  );

  return <UIContext.Provider value={value}>{children}</UIContext.Provider>;
}

export function useUI() {
  const ctx = useContext(UIContext);
  if (!ctx) throw new Error("useUI must be used inside <UIProvider>");
  return ctx;
}
