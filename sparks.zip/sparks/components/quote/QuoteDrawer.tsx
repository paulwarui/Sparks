"use client";

import { useState } from "react";
import Link from "next/link";
import {
  CheckCircle2,
  FileText,
  Loader2,
  MessageCircle,
  Trash2,
  X,
} from "lucide-react";
import { useQuote } from "@/components/providers/QuoteProvider";
import { Button } from "@/components/ui/Button";
import { submitQuoteRequest } from "@/lib/api";
import { contact, markets } from "@/lib/site";

type Status = "idle" | "submitting" | "success" | "error";

/**
 * Slide-over RFQ basket. A chemical enquiry is nearly always multi-line, so
 * the whole flow is built around assembling a list first and submitting one
 * consolidated request — not a per-product "contact us" form.
 */
export function QuoteDrawer() {
  const { items, isOpen, closeDrawer, removeItem, updateItem, clear } =
    useQuote();

  const [status, setStatus] = useState<Status>("idle");
  const [reference, setReference] = useState<string>();
  const [error, setError] = useState<string>();

  const [form, setForm] = useState({
    full_name: "",
    company_name: "",
    email: "",
    phone: "",
    country: "Kenya",
    message: "",
  });

  const setField = (key: keyof typeof form, value: string) =>
    setForm((current) => ({ ...current, [key]: value }));

  async function handleSubmit(event: React.FormEvent) {
    event.preventDefault();
    setStatus("submitting");
    setError(undefined);

    const response = await submitQuoteRequest({
      ...form,
      items: items.map((item) => ({
        chemical_name: item.name,
        cas_number: item.cas_number,
        quantity: item.quantity,
        packaging: item.packaging,
      })),
    });

    if (response.status === "error") {
      setError(response.error ?? "Something went wrong. Please try again.");
      setStatus("error");
      return;
    }

    setReference(response.reference_number);
    setStatus("success");
    clear();
  }

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-[95]"
      role="dialog"
      aria-modal="true"
      aria-label="Quotation request"
    >
      <button
        type="button"
        aria-label="Close quotation panel"
        onClick={closeDrawer}
        className="absolute inset-0 cursor-default bg-navy-950/55 backdrop-blur-sm animate-fade-in"
      />

      <div className="absolute inset-y-0 right-0 flex w-full max-w-lg flex-col border-l border-border-base bg-surface shadow-2xl">
        <header className="flex items-center justify-between border-b border-border-base px-5 py-4">
          <div className="flex items-center gap-2.5">
            <span className="flex size-9 items-center justify-center rounded-lg bg-spark-50 text-spark-600 dark:bg-spark-500/12 dark:text-spark-400">
              <FileText aria-hidden className="size-4" />
            </span>
            <div>
              <h2 className="text-sm font-bold text-fg">Request a quotation</h2>
              <p className="text-xs text-fg-subtle">
                Response within 2 working hours
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={closeDrawer}
            aria-label="Close"
            className="rounded-lg p-2 text-fg-muted transition-colors hover:bg-surface-2 hover:text-fg"
          >
            <X aria-hidden className="size-5" />
          </button>
        </header>

        {status === "success" ? (
          <div className="flex flex-1 flex-col items-center justify-center px-8 text-center">
            <span className="mb-5 flex size-16 items-center justify-center rounded-full bg-spark-50 text-spark-600 dark:bg-spark-500/12 dark:text-spark-400">
              <CheckCircle2 aria-hidden className="size-8" />
            </span>
            <h3 className="text-lg font-bold text-fg">Quotation request sent</h3>
            {reference && (
              <p className="mt-2 font-mono text-sm text-spark-600 dark:text-spark-400">
                Reference {reference}
              </p>
            )}
            <p className="mt-3 max-w-sm text-sm leading-relaxed text-fg-muted">
              Our technical sales desk is preparing your pricing. You will
              receive an email confirmation shortly — for urgent orders, message
              us directly on WhatsApp.
            </p>
            <div className="mt-6 flex w-full flex-col gap-2.5">
              <a href={contact.whatsappHref} target="_blank" rel="noopener noreferrer">
                <Button variant="accent" className="w-full">
                  <MessageCircle aria-hidden className="size-4" />
                  Continue on WhatsApp
                </Button>
              </a>
              <Button variant="outline" onClick={closeDrawer}>
                Keep browsing the catalogue
              </Button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="flex flex-1 flex-col overflow-hidden">
            <div className="flex-1 overflow-y-auto px-5 py-5">
              {/* Line items */}
              <h3 className="mb-3 font-mono text-[0.65rem] font-semibold uppercase tracking-[0.16em] text-fg-subtle">
                Products ({items.length})
              </h3>

              {items.length === 0 ? (
                <div className="rounded-xl border border-dashed border-border-strong px-5 py-8 text-center">
                  <p className="text-sm font-medium text-fg">
                    Your request list is empty
                  </p>
                  <p className="mt-1.5 text-xs leading-relaxed text-fg-muted">
                    Add products from the catalogue, or describe what you need in
                    the message field below and we will identify it for you.
                  </p>
                  <Link
                    href="/products"
                    onClick={closeDrawer}
                    className="mt-3 inline-block text-xs font-semibold text-spark-600 hover:underline dark:text-spark-400"
                  >
                    Browse chemicals →
                  </Link>
                </div>
              ) : (
                <ul className="flex flex-col gap-2.5">
                  {items.map((item) => (
                    <li
                      key={item.slug}
                      className="rounded-xl border border-border-base bg-surface-2 p-3"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0">
                          <p className="truncate text-sm font-semibold text-fg">
                            {item.name}
                          </p>
                          <p className="mt-0.5 font-mono text-[0.7rem] text-fg-subtle">
                            CAS {item.cas_number} · {item.grade}
                          </p>
                        </div>
                        <button
                          type="button"
                          onClick={() => removeItem(item.slug)}
                          aria-label={`Remove ${item.name}`}
                          className="rounded-md p-1.5 text-fg-subtle transition-colors hover:bg-red-50 hover:text-red-600 dark:hover:bg-red-500/10"
                        >
                          <Trash2 aria-hidden className="size-4" />
                        </button>
                      </div>

                      <div className="mt-2.5 grid grid-cols-2 gap-2">
                        <label className="block">
                          <span className="sr-only">
                            Quantity for {item.name}
                          </span>
                          <input
                            value={item.quantity}
                            onChange={(e) =>
                              updateItem(item.slug, { quantity: e.target.value })
                            }
                            placeholder="Qty e.g. 20 MT"
                            className="w-full rounded-lg border border-border-base bg-surface px-2.5 py-1.5 text-xs text-fg outline-none focus:border-spark-500"
                          />
                        </label>
                        <label className="block">
                          <span className="sr-only">
                            Packaging for {item.name}
                          </span>
                          <input
                            value={item.packaging}
                            onChange={(e) =>
                              updateItem(item.slug, { packaging: e.target.value })
                            }
                            placeholder="Packaging"
                            className="w-full rounded-lg border border-border-base bg-surface px-2.5 py-1.5 text-xs text-fg outline-none focus:border-spark-500"
                          />
                        </label>
                      </div>
                    </li>
                  ))}
                </ul>
              )}

              {/* Buyer details */}
              <h3 className="mb-3 mt-7 font-mono text-[0.65rem] font-semibold uppercase tracking-[0.16em] text-fg-subtle">
                Your details
              </h3>
              <div className="grid grid-cols-2 gap-3">
                <Field
                  label="Full name"
                  required
                  value={form.full_name}
                  onChange={(v) => setField("full_name", v)}
                  autoComplete="name"
                />
                <Field
                  label="Company"
                  required
                  value={form.company_name}
                  onChange={(v) => setField("company_name", v)}
                  autoComplete="organization"
                />
                <Field
                  label="Work email"
                  type="email"
                  required
                  value={form.email}
                  onChange={(v) => setField("email", v)}
                  autoComplete="email"
                />
                <Field
                  label="Phone / WhatsApp"
                  type="tel"
                  required
                  value={form.phone}
                  onChange={(v) => setField("phone", v)}
                  autoComplete="tel"
                />
                <label className="col-span-2 block">
                  <span className="mb-1.5 block text-xs font-medium text-fg-muted">
                    Delivery country
                  </span>
                  <select
                    value={form.country}
                    onChange={(e) => setField("country", e.target.value)}
                    className="w-full rounded-lg border border-border-base bg-surface px-3 py-2 text-sm text-fg outline-none focus:border-spark-500"
                  >
                    {markets.map((market) => (
                      <option key={market} value={market}>
                        {market}
                      </option>
                    ))}
                    <option value="Other">Other / export</option>
                  </select>
                </label>
                <label className="col-span-2 block">
                  <span className="mb-1.5 block text-xs font-medium text-fg-muted">
                    Specifications, volumes or delivery notes
                  </span>
                  <textarea
                    value={form.message}
                    onChange={(e) => setField("message", e.target.value)}
                    rows={3}
                    placeholder="e.g. Monthly supply of 20 MT, need COA and MSDS, delivery to Mombasa."
                    className="w-full resize-none rounded-lg border border-border-base bg-surface px-3 py-2 text-sm text-fg outline-none focus:border-spark-500"
                  />
                </label>
              </div>

              {error && (
                <p
                  role="alert"
                  className="mt-4 rounded-lg border border-red-200 bg-red-50 px-3 py-2.5 text-xs text-red-700 dark:border-red-500/30 dark:bg-red-500/10 dark:text-red-300"
                >
                  {error}
                </p>
              )}
            </div>

            <footer className="border-t border-border-base bg-surface-2 px-5 py-4">
              <Button
                type="submit"
                variant="accent"
                className="w-full"
                disabled={status === "submitting"}
              >
                {status === "submitting" ? (
                  <>
                    <Loader2 aria-hidden className="size-4 animate-spin" />
                    Sending request…
                  </>
                ) : (
                  <>
                    <FileText aria-hidden className="size-4" />
                    Send quotation request
                  </>
                )}
              </Button>
              <p className="mt-2.5 text-center text-[0.68rem] leading-relaxed text-fg-subtle">
                No obligation. Your details are used only to prepare this
                quotation.
              </p>
            </footer>
          </form>
        )}
      </div>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  type = "text",
  required,
  autoComplete,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  type?: string;
  required?: boolean;
  autoComplete?: string;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-medium text-fg-muted">
        {label}
        {required && <span className="text-spark-600"> *</span>}
      </span>
      <input
        type={type}
        value={value}
        required={required}
        autoComplete={autoComplete}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-lg border border-border-base bg-surface px-3 py-2 text-sm text-fg outline-none focus:border-spark-500"
      />
    </label>
  );
}
