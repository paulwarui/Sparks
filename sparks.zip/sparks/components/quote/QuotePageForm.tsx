"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { CheckCircle2, Loader2, MessageCircle, Plus, Send, Trash2 } from "lucide-react";
import { useQuote } from "@/components/providers/QuoteProvider";
import { Button } from "@/components/ui/Button";
import { submitQuoteRequest } from "@/lib/api";
import { contact, markets } from "@/lib/site";

interface ManualLine {
  id: number;
  chemical_name: string;
  quantity: string;
  packaging: string;
}

const emptyLine = (): ManualLine => ({
  id: Date.now() + Math.random(),
  chemical_name: "",
  quantity: "",
  packaging: "",
});

/**
 * Full-page RFQ form. Pre-populates from the quotation basket the visitor has
 * been building while browsing, but also accepts free-text lines so someone
 * who arrived directly on this page — or wants something not in the catalogue
 * — can still submit without hunting through the catalogue first.
 */
export function QuotePageForm() {
  const { items, removeItem, updateItem, clear } = useQuote();
  const [manualLines, setManualLines] = useState<ManualLine[]>([]);
  const [status, setStatus] = useState<
    "idle" | "submitting" | "success" | "error"
  >("idle");
  const [reference, setReference] = useState<string>();
  const [error, setError] = useState<string>();

  const [form, setForm] = useState({
    full_name: "",
    company_name: "",
    email: "",
    phone: "",
    country: "Kenya",
    message: "",
  });

  // Someone landing here with an empty basket needs a line to type into.
  useEffect(() => {
    if (items.length === 0 && manualLines.length === 0) {
      setManualLines([emptyLine()]);
    }
    // Intentionally only reacts to the basket emptying, not to line edits.
  }, [items.length, manualLines.length]);

  const setField = (key: keyof typeof form, value: string) =>
    setForm((current) => ({ ...current, [key]: value }));

  const updateLine = (id: number, patch: Partial<ManualLine>) =>
    setManualLines((lines) =>
      lines.map((line) => (line.id === id ? { ...line, ...patch } : line)),
    );

  async function onSubmit(event: React.FormEvent) {
    event.preventDefault();

    const lines = [
      ...items.map((item) => ({
        chemical_name: item.name,
        cas_number: item.cas_number,
        quantity: item.quantity,
        packaging: item.packaging,
      })),
      ...manualLines
        .filter((line) => line.chemical_name.trim())
        .map((line) => ({
          chemical_name: line.chemical_name.trim(),
          quantity: line.quantity.trim() || "To be advised",
          packaging: line.packaging.trim(),
        })),
    ];

    if (lines.length === 0) {
      setError("Add at least one product, or describe what you need below.");
      setStatus("error");
      return;
    }

    setStatus("submitting");
    setError(undefined);

    const response = await submitQuoteRequest({ ...form, items: lines });

    if (response.status === "error") {
      setError(response.error ?? "Something went wrong. Please try again.");
      setStatus("error");
      return;
    }

    setReference(response.reference_number);
    setStatus("success");
    clear();
    setManualLines([]);
  }

  if (status === "success") {
    return (
      <div className="rounded-2xl border border-spark-500/30 bg-spark-50 p-10 text-center dark:bg-spark-500/10">
        <span className="mx-auto mb-5 flex size-16 items-center justify-center rounded-full bg-spark-500 text-white">
          <CheckCircle2 aria-hidden className="size-8" />
        </span>
        <h2 className="text-xl font-bold text-fg">Quotation request received</h2>
        {reference && (
          <p className="mt-2 font-mono text-sm text-spark-700 dark:text-spark-300">
            Reference {reference}
          </p>
        )}
        <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-fg-muted">
          Our technical desk is preparing your pricing and will respond within
          two working hours. For urgent requirements, message us on WhatsApp and
          quote your reference.
        </p>
        <div className="mt-7 flex flex-wrap justify-center gap-3">
          <a href={contact.whatsappHref} target="_blank" rel="noopener noreferrer">
            <Button variant="accent">
              <MessageCircle aria-hidden className="size-4" />
              Continue on WhatsApp
            </Button>
          </a>
          <Link href="/products">
            <Button variant="outline">Back to the catalogue</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className="flex flex-col gap-8">
      {/* Basket lines */}
      <section>
        <h2 className="mb-4 text-lg font-bold text-fg">Products you need</h2>

        {items.length > 0 && (
          <ul className="mb-3 flex flex-col gap-2.5">
            {items.map((item) => (
              <li
                key={item.slug}
                className="rounded-xl border border-border-base bg-surface p-4"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-fg">{item.name}</p>
                    <p className="mt-0.5 font-mono text-[0.7rem] text-fg-subtle">
                      CAS {item.cas_number} · {item.grade}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => removeItem(item.slug)}
                    aria-label={`Remove ${item.name}`}
                    className="rounded-md p-1.5 text-fg-subtle transition-colors hover:bg-red-50 hover:text-red-600 dark:hover:bg-red-500/10"
                  >
                    <Trash2 aria-hidden className="size-4" />
                  </button>
                </div>
                <div className="mt-3 grid gap-2 sm:grid-cols-2">
                  <input
                    value={item.quantity}
                    onChange={(e) =>
                      updateItem(item.slug, { quantity: e.target.value })
                    }
                    aria-label={`Quantity for ${item.name}`}
                    placeholder="Quantity e.g. 20 MT"
                    className="rounded-lg border border-border-base bg-surface px-3 py-2 text-sm outline-none focus:border-spark-500"
                  />
                  <input
                    value={item.packaging}
                    onChange={(e) =>
                      updateItem(item.slug, { packaging: e.target.value })
                    }
                    aria-label={`Packaging for ${item.name}`}
                    placeholder="Packaging"
                    className="rounded-lg border border-border-base bg-surface px-3 py-2 text-sm outline-none focus:border-spark-500"
                  />
                </div>
              </li>
            ))}
          </ul>
        )}

        <ul className="flex flex-col gap-2.5">
          {manualLines.map((line, index) => (
            <li
              key={line.id}
              className="rounded-xl border border-dashed border-border-strong bg-surface p-4"
            >
              <div className="grid gap-2 sm:grid-cols-[1.6fr_1fr_1fr_auto]">
                <input
                  value={line.chemical_name}
                  onChange={(e) =>
                    updateLine(line.id, { chemical_name: e.target.value })
                  }
                  aria-label={`Chemical name for line ${index + 1}`}
                  placeholder="Chemical name or CAS number"
                  className="rounded-lg border border-border-base bg-surface px-3 py-2 text-sm outline-none focus:border-spark-500"
                />
                <input
                  value={line.quantity}
                  onChange={(e) =>
                    updateLine(line.id, { quantity: e.target.value })
                  }
                  aria-label={`Quantity for line ${index + 1}`}
                  placeholder="Quantity"
                  className="rounded-lg border border-border-base bg-surface px-3 py-2 text-sm outline-none focus:border-spark-500"
                />
                <input
                  value={line.packaging}
                  onChange={(e) =>
                    updateLine(line.id, { packaging: e.target.value })
                  }
                  aria-label={`Packaging for line ${index + 1}`}
                  placeholder="Packaging"
                  className="rounded-lg border border-border-base bg-surface px-3 py-2 text-sm outline-none focus:border-spark-500"
                />
                <button
                  type="button"
                  onClick={() =>
                    setManualLines((lines) =>
                      lines.filter((l) => l.id !== line.id),
                    )
                  }
                  aria-label={`Remove line ${index + 1}`}
                  className="rounded-lg p-2 text-fg-subtle transition-colors hover:bg-red-50 hover:text-red-600 dark:hover:bg-red-500/10"
                >
                  <Trash2 aria-hidden className="size-4" />
                </button>
              </div>
            </li>
          ))}
        </ul>

        <button
          type="button"
          onClick={() => setManualLines((lines) => [...lines, emptyLine()])}
          className="mt-3 inline-flex items-center gap-1.5 text-sm font-semibold text-spark-600 hover:underline dark:text-spark-400"
        >
          <Plus aria-hidden className="size-4" />
          Add another product
        </button>

        <p className="mt-3 text-xs text-fg-subtle">
          Prefer to pick from the catalogue?{" "}
          <Link
            href="/products"
            className="font-semibold text-spark-600 hover:underline dark:text-spark-400"
          >
            Browse chemicals
          </Link>
          .
        </p>
      </section>

      {/* Contact details */}
      <section>
        <h2 className="mb-4 text-lg font-bold text-fg">Your details</h2>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field
            label="Full name"
            required
            value={form.full_name}
            onChange={(v) => setField("full_name", v)}
            autoComplete="name"
          />
          <Field
            label="Company"
            required
            value={form.company_name}
            onChange={(v) => setField("company_name", v)}
            autoComplete="organization"
          />
          <Field
            label="Work email"
            type="email"
            required
            value={form.email}
            onChange={(v) => setField("email", v)}
            autoComplete="email"
          />
          <Field
            label="Phone / WhatsApp"
            type="tel"
            required
            value={form.phone}
            onChange={(v) => setField("phone", v)}
            autoComplete="tel"
          />

          <label className="block">
            <span className="mb-1.5 block text-xs font-medium text-fg-muted">
              Delivery country
            </span>
            <select
              value={form.country}
              onChange={(e) => setField("country", e.target.value)}
              className="w-full rounded-lg border border-border-base bg-surface px-3 py-2.5 text-sm text-fg outline-none focus:border-spark-500"
            >
              {markets.map((market) => (
                <option key={market} value={market}>
                  {market}
                </option>
              ))}
              <option value="Other">Other / export</option>
            </select>
          </label>

          <label className="block sm:col-span-2">
            <span className="mb-1.5 block text-xs font-medium text-fg-muted">
              Anything else we should know?
            </span>
            <textarea
              rows={4}
              value={form.message}
              onChange={(e) => setField("message", e.target.value)}
              placeholder="Delivery address, required certifications, target price, contract frequency, or a description of the process if you're unsure which chemical you need."
              className="w-full resize-none rounded-lg border border-border-base bg-surface px-3 py-2.5 text-sm text-fg outline-none focus:border-spark-500"
            />
          </label>
        </div>
      </section>

      {error && (
        <p
          role="alert"
          className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-500/30 dark:bg-red-500/10 dark:text-red-300"
        >
          {error}
        </p>
      )}

      <div>
        <Button
          type="submit"
          variant="accent"
          size="lg"
          disabled={status === "submitting"}
          className="w-full sm:w-auto"
        >
          {status === "submitting" ? (
            <>
              <Loader2 aria-hidden className="size-4 animate-spin" />
              Sending request…
            </>
          ) : (
            <>
              <Send aria-hidden className="size-4" />
              Send quotation request
            </>
          )}
        </Button>
        <p className="mt-3 text-xs text-fg-subtle">
          No obligation. Your details are used only to prepare this quotation.
        </p>
      </div>
    </form>
  );
}

function Field({
  label,
  value,
  onChange,
  type = "text",
  required,
  autoComplete,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  type?: string;
  required?: boolean;
  autoComplete?: string;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-medium text-fg-muted">
        {label}
        {required && <span className="text-spark-600"> *</span>}
      </span>
      <input
        type={type}
        value={value}
        required={required}
        autoComplete={autoComplete}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-lg border border-border-base bg-surface px-3 py-2.5 text-sm text-fg outline-none focus:border-spark-500"
      />
    </label>
  );
}
