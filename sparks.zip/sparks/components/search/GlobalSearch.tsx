"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import {
  ArrowRight,
  Clock,
  CornerDownLeft,
  FlaskConical,
  Loader2,
  Search,
  Sparkles,
  TrendingUp,
  X,
} from "lucide-react";
import { fetchAutocomplete } from "@/lib/api";
import type { ChemicalSuggestion, Industry } from "@/lib/types";
import { useUI } from "@/components/providers/UIProvider";
import { Formula } from "@/components/ui/primitives";
import { cn } from "@/lib/utils";

const RECENTS_KEY = "sparks-recent-searches";
const MAX_RECENTS = 5;

const POPULAR = [
  "Caustic Soda 99%",
  "Sulphuric Acid 98%",
  "HTH Chlorine 70%",
  "LABSA 96%",
  "Citric Acid",
  "Ethanol 96%",
];

/**
 * Global command palette. Searches the catalogue by product name, CAS number,
 * chemical formula and synonym in a single field — buyers arrive knowing any
 * one of those four, and forcing them to pick the right search mode is the
 * main reason supplier-site search fails.
 */
export function GlobalSearch({ industries }: { industries: Industry[] }) {
  const { searchOpen, closeSearch } = useUI();
  const router = useRouter();
  const inputRef = useRef<HTMLInputElement>(null);

  const [query, setQuery] = useState("");
  const [results, setResults] = useState<ChemicalSuggestion[]>([]);
  const [loading, setLoading] = useState(false);
  const [activeIndex, setActiveIndex] = useState(0);
  const [recents, setRecents] = useState<string[]>([]);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(RECENTS_KEY);
      if (raw) setRecents(JSON.parse(raw) as string[]);
    } catch {
      // No stored history available.
    }
  }, []);

  // Focus the field and reset transient state each time the palette opens.
  useEffect(() => {
    if (!searchOpen) return;
    setActiveIndex(0);
    const timer = setTimeout(() => inputRef.current?.focus(), 40);
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      clearTimeout(timer);
      document.body.style.overflow = previous;
    };
  }, [searchOpen]);

  // Debounced, abortable autocomplete so fast typists don't race responses.
  useEffect(() => {
    const trimmed = query.trim();
    if (trimmed.length < 2) {
      setResults([]);
      setLoading(false);
      return;
    }

    setLoading(true);
    const controller = new AbortController();
    const timer = setTimeout(async () => {
      const found = await fetchAutocomplete(trimmed, controller.signal);
      if (!controller.signal.aborted) {
        setResults(found);
        setActiveIndex(0);
        setLoading(false);
      }
    }, 180);

    return () => {
      controller.abort();
      clearTimeout(timer);
    };
  }, [query]);

  const rememberSearch = useCallback((term: string) => {
    setRecents((current) => {
      const next = [term, ...current.filter((r) => r !== term)].slice(
        0,
        MAX_RECENTS,
      );
      try {
        localStorage.setItem(RECENTS_KEY, JSON.stringify(next));
      } catch {
        // Storage unavailable — history is best-effort.
      }
      return next;
    });
  }, []);

  const goTo = useCallback(
    (href: string, term?: string) => {
      if (term) rememberSearch(term);
      closeSearch();
      setQuery("");
      router.push(href);
    },
    [closeSearch, rememberSearch, router],
  );

  const submitFreeText = useCallback(
    (term: string) => {
      const trimmed = term.trim();
      if (!trimmed) return;
      goTo(`/products?q=${encodeURIComponent(trimmed)}`, trimmed);
    },
    [goTo],
  );

  const onKeyDown = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === "ArrowDown") {
      event.preventDefault();
      setActiveIndex((i) => Math.min(i + 1, results.length - 1));
    } else if (event.key === "ArrowUp") {
      event.preventDefault();
      setActiveIndex((i) => Math.max(i - 1, 0));
    } else if (event.key === "Enter") {
      event.preventDefault();
      const active = results[activeIndex];
      if (active) goTo(`/products/${active.slug}`, active.name);
      else submitFreeText(query);
    }
  };

  // A CAS number is three groups of digits — detect it to reassure the user
  // that their identifier was understood.
  const looksLikeCAS = useMemo(
    () => /^\d{2,7}-\d{2}-\d$/.test(query.trim()),
    [query],
  );

  if (!searchOpen) return null;

  const showEmptyState = query.trim().length < 2;

  return (
    <div
      className="fixed inset-0 z-[90] flex items-start justify-center px-4 pt-[8vh] sm:pt-[12vh]"
      role="dialog"
      aria-modal="true"
      aria-label="Search the chemical catalogue"
    >
      <button
        type="button"
        aria-label="Close search"
        onClick={closeSearch}
        className="absolute inset-0 cursor-default bg-navy-950/55 backdrop-blur-sm animate-fade-in"
      />

      <div className="relative w-full max-w-2xl overflow-hidden rounded-2xl border border-border-base bg-surface shadow-2xl animate-fade-up">
        {/* Input row */}
        <div className="flex items-center gap-3 border-b border-border-base px-4 py-3.5">
          {loading ? (
            <Loader2
              aria-hidden
              className="size-5 shrink-0 animate-spin text-spark-500"
            />
          ) : (
            <Search aria-hidden className="size-5 shrink-0 text-spark-500" />
          )}
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={onKeyDown}
            placeholder="Search by product, CAS number, formula or application…"
            aria-label="Search chemicals"
            aria-autocomplete="list"
            className="min-w-0 flex-1 bg-transparent text-[0.95rem] text-fg outline-none placeholder:text-fg-subtle"
          />
          {query && (
            <button
              type="button"
              onClick={() => setQuery("")}
              aria-label="Clear search"
              className="rounded-md p-1 text-fg-subtle transition-colors hover:text-fg"
            >
              <X aria-hidden className="size-4" />
            </button>
          )}
          <kbd className="hidden rounded border border-border-base bg-surface-2 px-1.5 py-0.5 font-mono text-[10px] text-fg-subtle sm:inline">
            ESC
          </kbd>
        </div>

        <div className="max-h-[58vh] overflow-y-auto">
          {looksLikeCAS && (
            <p className="flex items-center gap-2 border-b border-border-base bg-spark-50 px-4 py-2.5 text-xs font-medium text-spark-700 dark:bg-spark-500/10 dark:text-spark-300">
              <Sparkles aria-hidden className="size-3.5" />
              Recognised CAS registry number — searching exact matches.
            </p>
          )}

          {/* Results */}
          {!showEmptyState && results.length > 0 && (
            <ul className="p-2" role="listbox" aria-label="Search results">
              {results.map((item, index) => (
                <li key={item.id}>
                  <button
                    type="button"
                    role="option"
                    aria-selected={index === activeIndex}
                    onMouseEnter={() => setActiveIndex(index)}
                    onClick={() => goTo(`/products/${item.slug}`, item.name)}
                    className={cn(
                      "flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left transition-colors",
                      index === activeIndex ? "bg-surface-2" : "hover:bg-surface-2",
                    )}
                  >
                    <span className="flex size-9 shrink-0 items-center justify-center rounded-lg bg-spark-50 text-spark-600 dark:bg-spark-500/12 dark:text-spark-400">
                      <FlaskConical aria-hidden className="size-4" />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-sm font-semibold text-fg">
                        {item.name}
                      </span>
                      <span className="mt-0.5 flex items-center gap-2 text-xs text-fg-subtle">
                        <span className="font-mono">CAS {item.cas_number}</span>
                        <span aria-hidden>·</span>
                        <Formula value={item.chemical_formula} />
                        {item.category && (
                          <>
                            <span aria-hidden>·</span>
                            <span className="truncate">{item.category}</span>
                          </>
                        )}
                      </span>
                    </span>
                    {index === activeIndex && (
                      <CornerDownLeft
                        aria-hidden
                        className="size-4 shrink-0 text-fg-subtle"
                      />
                    )}
                  </button>
                </li>
              ))}
            </ul>
          )}

          {/* No matches */}
          {!showEmptyState && !loading && results.length === 0 && (
            <div className="px-5 py-10 text-center">
              <p className="text-sm font-medium text-fg">
                No catalogue match for “{query}”.
              </p>
              <p className="mx-auto mt-1.5 max-w-sm text-xs leading-relaxed text-fg-muted">
                We source over 1,500 products and can import to order. Send us
                the specification and our technical desk will respond with
                availability and pricing.
              </p>
              <button
                type="button"
                onClick={() => submitFreeText(query)}
                className="mt-4 inline-flex items-center gap-1.5 text-xs font-semibold text-spark-600 hover:underline dark:text-spark-400"
              >
                Search the full catalogue anyway
                <ArrowRight aria-hidden className="size-3.5" />
              </button>
            </div>
          )}

          {/* Default state: recents, popular, industries */}
          {showEmptyState && (
            <div className="p-4">
              {recents.length > 0 && (
                <section className="mb-5">
                  <h3 className="mb-2 flex items-center gap-1.5 px-1 font-mono text-[0.65rem] font-semibold uppercase tracking-[0.16em] text-fg-subtle">
                    <Clock aria-hidden className="size-3" />
                    Recent searches
                  </h3>
                  <div className="flex flex-wrap gap-1.5">
                    {recents.map((term) => (
                      <button
                        key={term}
                        type="button"
                        onClick={() => submitFreeText(term)}
                        className="rounded-lg border border-border-base px-2.5 py-1.5 text-xs text-fg-muted transition-colors hover:border-spark-500/50 hover:text-fg"
                      >
                        {term}
                      </button>
                    ))}
                  </div>
                </section>
              )}

              <section className="mb-5">
                <h3 className="mb-2 flex items-center gap-1.5 px-1 font-mono text-[0.65rem] font-semibold uppercase tracking-[0.16em] text-fg-subtle">
                  <TrendingUp aria-hidden className="size-3" />
                  Most requested
                </h3>
                <div className="flex flex-wrap gap-1.5">
                  {POPULAR.map((term) => (
                    <button
                      key={term}
                      type="button"
                      onClick={() => submitFreeText(term)}
                      className="rounded-lg bg-surface-2 px-2.5 py-1.5 text-xs font-medium text-fg-muted transition-colors hover:bg-spark-50 hover:text-spark-700 dark:hover:bg-spark-500/10 dark:hover:text-spark-300"
                    >
                      {term}
                    </button>
                  ))}
                </div>
              </section>

              <section>
                <h3 className="mb-2 px-1 font-mono text-[0.65rem] font-semibold uppercase tracking-[0.16em] text-fg-subtle">
                  Browse by industry
                </h3>
                <div className="grid grid-cols-2 gap-1">
                  {industries.slice(0, 8).map((industry) => (
                    <button
                      key={industry.slug}
                      type="button"
                      onClick={() => goTo(`/industries/${industry.slug}`)}
                      className="truncate rounded-lg px-2.5 py-2 text-left text-xs font-medium text-fg-muted transition-colors hover:bg-surface-2 hover:text-fg"
                    >
                      {industry.name}
                    </button>
                  ))}
                </div>
              </section>
            </div>
          )}
        </div>

        <div className="flex items-center justify-between border-t border-border-base bg-surface-2 px-4 py-2.5 text-[0.68rem] text-fg-subtle">
          <span className="flex items-center gap-3">
            <span>↑↓ navigate</span>
            <span>↵ open</span>
            <span>esc close</span>
          </span>
          <span>Searches name, CAS, formula &amp; synonyms</span>
        </div>
      </div>
    </div>
  );
}
