import Link from "next/link";
import { cn } from "@/lib/utils";

type Variant = "primary" | "secondary" | "outline" | "ghost" | "accent";
type Size = "sm" | "md" | "lg";

const base =
  "inline-flex items-center justify-center gap-2 font-semibold rounded-xl " +
  "transition-[transform,background-color,border-color,box-shadow,color] duration-200 " +
  "active:scale-[0.98] disabled:opacity-55 disabled:pointer-events-none whitespace-nowrap";

const variants: Record<Variant, string> = {
  // Navy — the primary corporate action.
  primary:
    "bg-navy-800 text-white hover:bg-navy-700 shadow-lg shadow-navy-900/20 " +
    "dark:bg-white dark:text-navy-900 dark:hover:bg-navy-100",
  // Scientific green — reserved for the highest-intent conversion action.
  accent:
    "bg-spark-500 text-white hover:bg-spark-600 shadow-lg shadow-spark-600/25 " +
    "dark:bg-spark-400 dark:text-navy-950 dark:hover:bg-spark-300",
  secondary:
    "bg-surface-2 text-fg hover:bg-border-base border border-border-base",
  outline:
    "border border-border-strong text-fg hover:border-spark-500 hover:text-spark-600 " +
    "dark:hover:text-spark-400 bg-transparent",
  ghost: "text-fg-muted hover:text-fg hover:bg-surface-2",
};

const sizes: Record<Size, string> = {
  sm: "h-9 px-3.5 text-xs",
  md: "h-11 px-5 text-sm",
  lg: "h-13 px-7 text-[0.95rem]",
};

interface CommonProps {
  variant?: Variant;
  size?: Size;
  className?: string;
  children: React.ReactNode;
}

export function Button({
  variant = "primary",
  size = "md",
  className,
  children,
  ...props
}: CommonProps & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      className={cn(base, variants[variant], sizes[size], className)}
      {...props}
    >
      {children}
    </button>
  );
}

export function ButtonLink({
  variant = "primary",
  size = "md",
  className,
  children,
  href,
  ...props
}: CommonProps &
  Omit<React.ComponentProps<typeof Link>, "className" | "children">) {
  return (
    <Link
      href={href}
      className={cn(base, variants[variant], sizes[size], className)}
      {...props}
    >
      {children}
    </Link>
  );
}
