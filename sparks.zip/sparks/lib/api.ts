import type {
  Article,
  ArticleCategory,
  Category,
  Chemical,
  ChemicalQuery,
  ChemicalSuggestion,
  Industry,
} from "./types";
import { FALLBACK_CHEMICALS, FALLBACK_INDUSTRIES } from "./fallback-data";

/**
 * The API has two addresses and which one is correct depends on who is asking.
 *
 * - The browser reaches it through the public origin (Nginx), e.g. /api.
 * - The Next.js server, running inside its own container, must call the
 *   backend service directly — routing back out through the public hostname
 *   would fail or needlessly hairpin through the proxy.
 *
 * Both come from the root .env; nothing is hardcoded to a host.
 */
const PUBLIC_API_URL =
  process.env.NEXT_PUBLIC_API_URL ?? "http://127.0.0.1:8000/api";

/**
 * Resolved per call rather than once at module load: a client component's
 * module is evaluated both on the server (during SSR) and in the browser, so a
 * module-level constant would freeze the wrong base URL into one of them.
 */
function apiBase(): string {
  if (typeof window === "undefined") {
    return process.env.INTERNAL_API_URL ?? PUBLIC_API_URL;
  }
  return PUBLIC_API_URL;
}

/**
 * Catalogue content changes rarely and must be statically generated for Core
 * Web Vitals and crawlability, so requests are cached and revalidated on a
 * timer rather than opting every page into dynamic rendering.
 */
const REVALIDATE = {
  catalog: 3600, // 1 hour
  editorial: 1800, // 30 minutes
} as const;

type FetchOptions = {
  revalidate?: number;
  tags?: string[];
};

/**
 * Wraps fetch so a backend outage degrades to fallback content instead of
 * failing the render. Returns `null` on any non-OK or network condition and
 * lets each caller decide what to substitute.
 */
async function getJSON<T>(
  path: string,
  { revalidate = REVALIDATE.catalog, tags }: FetchOptions = {},
): Promise<T | null> {
  try {
    const res = await fetch(`${apiBase()}${path}`, {
      next: { revalidate, tags },
      headers: { Accept: "application/json" },
    });
    if (!res.ok) return null;
    return (await res.json()) as T;
  } catch {
    // Backend unreachable (dev without Django running, or a build-time blip).
    return null;
  }
}

/** DRF returns either a bare array or a paginated `{ results: [] }` envelope. */
function unwrap<T>(payload: unknown): T[] {
  if (Array.isArray(payload)) return payload as T[];
  if (payload && typeof payload === "object" && "results" in payload) {
    const results = (payload as { results?: unknown }).results;
    if (Array.isArray(results)) return results as T[];
  }
  return [];
}

/**
 * The catalogue is rendered in full on one page and is enumerated for static
 * params and the sitemap, so request the API's maximum page size rather than
 * accepting the default page of 24 and silently losing products.
 */
const CATALOG_PAGE_SIZE = 500;

function buildQuery(params: ChemicalQuery = {}) {
  const search = new URLSearchParams({ page_size: String(CATALOG_PAGE_SIZE) });
  if (params.q) search.set("q", params.q);
  if (params.cas) search.set("cas", params.cas);
  if (params.formula) search.set("formula", params.formula);
  if (params.industry) search.set("industry", params.industry);
  if (params.category) search.set("category", params.category);
  if (params.grade) search.set("grade", params.grade);
  if (params.featured) search.set("featured", "true");
  const qs = search.toString();
  return qs ? `?${qs}` : "";
}

/** Mirrors the server-side filters, applied to fallback data. */
function filterLocally(items: Chemical[], params: ChemicalQuery = {}) {
  let out = [...items];
  if (params.q) {
    const q = params.q.toLowerCase();
    out = out.filter((c) =>
      [
        c.name,
        c.cas_number,
        c.chemical_formula,
        c.synonyms ?? "",
        c.applications,
        c.description,
      ]
        .join(" ")
        .toLowerCase()
        .includes(q),
    );
  }
  if (params.cas) {
    const cas = params.cas.toLowerCase();
    out = out.filter((c) => c.cas_number.toLowerCase().includes(cas));
  }
  if (params.formula) {
    const f = params.formula.toLowerCase();
    out = out.filter((c) => c.chemical_formula.toLowerCase().includes(f));
  }
  if (params.grade) {
    out = out.filter(
      (c) => c.grade.toLowerCase() === params.grade!.toLowerCase(),
    );
  }
  if (params.category) {
    out = out.filter((c) => c.category_slug === params.category);
  }
  if (params.industry) {
    const target = FALLBACK_INDUSTRIES.find((i) => i.slug === params.industry);
    if (target) out = out.filter((c) => c.industries_names?.includes(target.name));
  }
  if (params.featured) out = out.filter((c) => c.is_featured);
  return out;
}

/* -------------------------------------------------------------------------- */
/*  Catalogue                                                                 */
/* -------------------------------------------------------------------------- */

export async function fetchChemicals(
  params: ChemicalQuery = {},
): Promise<Chemical[]> {
  const data = await getJSON<unknown>(`/products/${buildQuery(params)}`, {
    tags: ["chemicals"],
  });
  if (data === null) return filterLocally(FALLBACK_CHEMICALS, params);
  return unwrap<Chemical>(data);
}

export async function fetchChemicalBySlug(
  slug: string,
): Promise<Chemical | null> {
  const data = await getJSON<Chemical>(`/products/${slug}/`, {
    tags: ["chemicals", `chemical:${slug}`],
  });
  if (data) return data;
  return FALLBACK_CHEMICALS.find((c) => c.slug === slug) ?? null;
}

/**
 * Related products: same category scores highest, then shared industries, then
 * matching grade. Computed here rather than in the API so the internal-linking
 * the SEO brief depends on works regardless of backend capability.
 */
export async function fetchRelatedChemicals(
  chemical: Chemical,
  limit = 4,
): Promise<Chemical[]> {
  const pool = await fetchChemicals();
  const others = pool.filter((c) => c.slug !== chemical.slug);

  const score = (c: Chemical) => {
    let s = 0;
    if (c.category_name && c.category_name === chemical.category_name) s += 3;
    s += (c.industries_names ?? []).filter((i) =>
      (chemical.industries_names ?? []).includes(i),
    ).length;
    if (c.grade === chemical.grade) s += 1;
    return s;
  };

  const ranked = others
    .map((c) => ({ c, s: score(c) }))
    .sort((a, b) => b.s - a.s)
    .filter((entry) => entry.s > 0)
    .slice(0, limit)
    .map((entry) => entry.c);

  // Never show an empty "related" rail — pad with other catalogue entries.
  if (ranked.length < limit) {
    for (const c of others) {
      if (ranked.length >= limit) break;
      if (!ranked.some((r) => r.slug === c.slug)) ranked.push(c);
    }
  }
  return ranked;
}

export async function fetchIndustries(): Promise<Industry[]> {
  const data = await getJSON<unknown>("/industries/", { tags: ["industries"] });
  if (data === null) return FALLBACK_INDUSTRIES;
  const list = unwrap<Industry>(data);
  return list.length ? list : FALLBACK_INDUSTRIES;
}

export async function fetchIndustryBySlug(
  slug: string,
): Promise<Industry | null> {
  const data = await getJSON<Industry>(`/industries/${slug}/`, {
    tags: ["industries"],
  });
  if (data) return data;
  return FALLBACK_INDUSTRIES.find((i) => i.slug === slug) ?? null;
}

export async function fetchCategories(): Promise<Category[]> {
  const data = await getJSON<unknown>("/categories/", { tags: ["categories"] });
  if (data === null) return [];
  return unwrap<Category>(data);
}

/* -------------------------------------------------------------------------- */
/*  Editorial                                                                 */
/* -------------------------------------------------------------------------- */

export async function fetchArticles(): Promise<Article[]> {
  const data = await getJSON<unknown>("/articles/", {
    revalidate: REVALIDATE.editorial,
    tags: ["articles"],
  });
  if (data === null) return [];
  return unwrap<Article>(data);
}

export async function fetchArticleBySlug(slug: string): Promise<Article | null> {
  return getJSON<Article>(`/articles/${slug}/`, {
    revalidate: REVALIDATE.editorial,
    tags: ["articles", `article:${slug}`],
  });
}

export async function fetchArticleCategories(): Promise<ArticleCategory[]> {
  const data = await getJSON<unknown>("/article-categories/", {
    revalidate: REVALIDATE.editorial,
  });
  if (data === null) return [];
  return unwrap<ArticleCategory>(data);
}

/* -------------------------------------------------------------------------- */
/*  Interactive endpoints (client-side, always live)                          */
/* -------------------------------------------------------------------------- */

export async function fetchAutocomplete(
  query: string,
  signal?: AbortSignal,
): Promise<ChemicalSuggestion[]> {
  if (query.trim().length < 2) return [];
  try {
    const res = await fetch(
      `${apiBase()}/products/autocomplete/?q=${encodeURIComponent(query)}`,
      { cache: "no-store", signal },
    );
    if (!res.ok) throw new Error("autocomplete unavailable");
    return unwrap<ChemicalSuggestion>(await res.json());
  } catch (err) {
    if (err instanceof DOMException && err.name === "AbortError") return [];
    const q = query.toLowerCase();
    return FALLBACK_CHEMICALS.filter((c) =>
      `${c.name} ${c.cas_number} ${c.chemical_formula} ${c.synonyms ?? ""}`
        .toLowerCase()
        .includes(q),
    )
      .slice(0, 8)
      .map((c) => ({
        id: c.id,
        name: c.name,
        slug: c.slug,
        cas_number: c.cas_number,
        chemical_formula: c.chemical_formula,
        grade: c.grade,
        category: c.category_name,
      }));
  }
}

export interface QuotePayload {
  full_name: string;
  company_name: string;
  email: string;
  phone: string;
  country: string;
  message?: string;
  items: {
    chemical_name: string;
    cas_number?: string;
    quantity: string;
    packaging?: string;
  }[];
}

export async function submitQuoteRequest(
  payload: QuotePayload,
): Promise<{ status: string; reference_number?: string; error?: string }> {
  try {
    const res = await fetch(`${apiBase()}/quotes/`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (res.ok) return await res.json();
    return { status: "error", error: `Request failed (${res.status}).` };
  } catch {
    return {
      status: "error",
      error:
        "We could not reach our quotation service. Please WhatsApp or call us and we will respond immediately.",
    };
  }
}

export interface InquiryPayload {
  full_name: string;
  email: string;
  phone?: string;
  company_name?: string;
  subject: string;
  message: string;
}

export async function submitInquiry(
  payload: InquiryPayload,
): Promise<{ status: string; error?: string }> {
  try {
    const res = await fetch(`${apiBase()}/inquiries/`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (res.ok) return { status: "success" };
    return { status: "error", error: `Request failed (${res.status}).` };
  } catch {
    return {
      status: "error",
      error: "We could not reach our servers. Please call or WhatsApp us.",
    };
  }
}

export interface AIReply {
  reply: string;
  suggested_chemicals?: { name: string; cas: string; slug: string }[];
}

export async function queryAIAssistant(message: string): Promise<AIReply> {
  try {
    const res = await fetch(`${apiBase()}/ai/advisor/`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message }),
      cache: "no-store",
    });
    if (res.ok) return await res.json();
    throw new Error("advisor unavailable");
  } catch {
    return {
      reply:
        "I'm temporarily offline, but our technical team answers within minutes on WhatsApp. In the meantime you can search the catalogue by name, CAS number or formula.",
    };
  }
}
