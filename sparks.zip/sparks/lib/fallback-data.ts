import type { Chemical, Industry } from "./types";

/**
 * Resilience net only — the real catalogue lives in Django.
 *
 * If the API is unreachable (a build-time blip, or local dev without the
 * backend running) the site still renders a credible catalogue instead of
 * throwing. Keep this list small and curated; it is not the source of truth.
 */

export const FALLBACK_INDUSTRIES: Industry[] = [
  {
    id: 1,
    name: "Water Treatment",
    slug: "water-treatment",
    icon: "Droplets",
    description:
      "Coagulants, disinfectants, pH adjusters, scale and corrosion inhibitors for municipal supply and industrial effluent plants.",
    chemical_count: 8,
  },
  {
    id: 2,
    name: "Food Processing & Beverage",
    slug: "food-processing-beverage",
    icon: "Utensils",
    description:
      "Food-grade preservatives, acidity regulators, CIP sanitisers and processing aids compliant with KEBS and FCC standards.",
    chemical_count: 6,
  },
  {
    id: 3,
    name: "Agriculture & Agrochemicals",
    slug: "agriculture-agrochemicals",
    icon: "Sprout",
    description:
      "Soluble fertilisers, micronutrients, soil conditioners, drip-line cleaners and foliar spray adjuvants.",
    chemical_count: 5,
  },
  {
    id: 4,
    name: "Mining & Minerals",
    slug: "mining-minerals",
    icon: "Pickaxe",
    description:
      "Flotation reagents, leaching acids, precipitants and dust suppressants for East African mining operations.",
    chemical_count: 7,
  },
  {
    id: 5,
    name: "Construction & Admixtures",
    slug: "construction-admixtures",
    icon: "Building2",
    description:
      "Concrete plasticisers, set accelerators and retarders, waterproofing compounds and structural adhesives.",
    chemical_count: 4,
  },
  {
    id: 6,
    name: "Pharmaceuticals & Healthcare",
    slug: "pharmaceuticals-healthcare",
    icon: "Pill",
    description:
      "BP/USP excipients, API intermediates, high-purity solvents and hospital-grade disinfectants.",
    chemical_count: 6,
  },
  {
    id: 7,
    name: "Cosmetics & Personal Care",
    slug: "cosmetics-personal-care",
    icon: "Sparkles",
    description:
      "Emulsifiers, surfactants, thickeners, humectants and preservatives for skincare and haircare manufacturing.",
    chemical_count: 5,
  },
  {
    id: 8,
    name: "Cleaning & Detergents",
    slug: "cleaning-detergents",
    icon: "SprayCan",
    description:
      "Raw materials for laundry powders, dishwashing liquids, industrial degreasers and surface disinfectants.",
    chemical_count: 9,
  },
  {
    id: 9,
    name: "Paints, Coatings & Inks",
    slug: "paints-coatings-inks",
    icon: "Paintbrush",
    description:
      "Titanium dioxide pigments, binder resins, solvents, in-can biocides and rheology modifiers.",
    chemical_count: 5,
  },
  {
    id: 10,
    name: "Textile & Leather Tanning",
    slug: "textile-leather-tanning",
    icon: "Shirt",
    description:
      "Dyeing auxiliaries, chrome tanning salts, enzymes, wetting agents and finishing chemicals.",
    chemical_count: 4,
  },
  {
    id: 11,
    name: "Oil, Gas & Energy",
    slug: "oil-gas-energy",
    icon: "Flame",
    description:
      "Drilling mud additives, demulsifiers, scale and corrosion inhibitors, and glycol gas dehydrators.",
    chemical_count: 3,
  },
  {
    id: 12,
    name: "Laboratories & Research",
    slug: "laboratories-research",
    icon: "TestTube",
    description:
      "Analytical reagent (AR) grade chemicals, titrants, volumetric standards and HPLC-grade solvents.",
    chemical_count: 6,
  },
];

export const FALLBACK_CHEMICALS: Chemical[] = [
  {
    id: 1,
    name: "Sodium Hydroxide (Caustic Soda Pearls / Flakes 99%)",
    slug: "sodium-hydroxide-caustic-soda-pearls-flakes-99",
    cas_number: "1310-73-2",
    chemical_formula: "NaOH",
    synonyms: "Caustic Soda, Sodium Hydrate, Lye",
    molecular_weight: "39.997 g/mol",
    grade: "Industrial",
    purity_percentage: "99.0% min",
    appearance: "White translucent pearls / flakes",
    density: "2.13 g/cm³",
    category_name: "Inorganic Acids & Bases",
    category_slug: "inorganic-acids-bases",
    industries_names: [
      "Cleaning & Detergents",
      "Water Treatment",
      "Food Processing & Beverage",
      "Textile & Leather Tanning",
    ],
    ghs_hazard_class: "Corrosive to Metals, Skin Corrosion Category 1A",
    hazard_statements:
      "H314: Causes severe skin burns and eye damage. H290: May be corrosive to metals.",
    un_number: "UN 1824 / UN 1823",
    storage_conditions:
      "Store in airtight containers in a cool, dry, well-ventilated area away from moisture and acids.",
    packaging_options: "25kg PP bags with PE liner, 1000kg jumbo bags",
    description:
      "High-purity caustic soda (sodium hydroxide 99%) used in soap and detergent manufacturing, water treatment neutralisation, paper pulp processing and food-grade CIP sanitisation across Kenya and East Africa.",
    technical_overview:
      "Strong alkaline base that dissolves readily in water with significant exothermic heat generation.",
    applications:
      "Soap manufacturing, pH adjustment in water treatment, textile mercerising, alumina extraction, vegetable oil refining.",
    benefits:
      "Consistent 99% purity, dust-free pearls, rapid solubility, competitive bulk pricing.",
    is_featured: true,
    is_popular: true,
    in_stock: true,
  },
  {
    id: 2,
    name: "Sulphuric Acid 98%",
    slug: "sulphuric-acid-98",
    cas_number: "7664-93-9",
    chemical_formula: "H2SO4",
    synonyms: "Oil of Vitriol, Hydrogen Sulfate",
    molecular_weight: "98.079 g/mol",
    grade: "Industrial",
    purity_percentage: "98.0% min",
    appearance: "Clear, oily liquid",
    density: "1.84 g/cm³",
    category_name: "Inorganic Acids & Bases",
    category_slug: "inorganic-acids-bases",
    industries_names: [
      "Mining & Minerals",
      "Agriculture & Agrochemicals",
      "Water Treatment",
    ],
    ghs_hazard_class: "Skin Corrosion Category 1A, Serious Eye Damage Category 1",
    hazard_statements: "H314: Causes severe skin burns and eye damage.",
    un_number: "UN 1830",
    storage_conditions:
      "Store in an acid-resistant tank in a cool, dry location away from water and organic matter.",
    packaging_options: "35kg carboys, 250kg HDPE drums, bulk ISO tanker",
    description:
      "Premium industrial grade 98% concentrated sulphuric acid for battery electrolyte manufacturing, fertiliser synthesis, metal leaching in mining and wastewater neutralisation.",
    technical_overview:
      "Extremely strong mineral acid with powerful dehydrating and oxidising properties.",
    applications:
      "Fertiliser production, mineral processing (copper and gold leaching), battery manufacture, chemical synthesis.",
    benefits:
      "High concentration, low iron impurity, available in bulk road tankers across East Africa.",
    is_featured: true,
    is_popular: true,
    in_stock: true,
  },
  {
    id: 3,
    name: "Aluminium Sulphate (Alum 17% Non-Ferric)",
    slug: "aluminum-sulphate-alum-17-non-ferric",
    cas_number: "10043-01-3",
    chemical_formula: "Al2(SO4)3.18H2O",
    synonyms: "Water Alum, Filter Alum, Cake Alum",
    molecular_weight: "666.44 g/mol",
    grade: "Technical",
    purity_percentage: "17% Al2O3 min",
    appearance: "White coarse powder / granular / lumps",
    density: "1.69 g/cm³",
    category_name: "Water Treatment Chemicals",
    category_slug: "water-treatment-chemicals",
    industries_names: ["Water Treatment", "Paints, Coatings & Inks"],
    ghs_hazard_class: "Serious Eye Damage Category 1",
    hazard_statements:
      "H318: Causes serious eye damage. H302: Harmful if swallowed.",
    un_number: "Not restricted for transport",
    storage_conditions:
      "Keep dry; avoid moisture absorption in cool, covered storage.",
    packaging_options: "50kg woven PP bags, 1000kg jumbo bags",
    description:
      "Primary coagulant for municipal water treatment plants and industrial effluent treatment across Kenya, Uganda and Tanzania. Precipitates suspended solids, colour and turbidity.",
    technical_overview:
      "Hydrolyses in water to form aluminium hydroxide flocs that rapidly settle colloidal particles.",
    applications:
      "Drinking water purification, paper sizing, wastewater clarification, lake restoration.",
    benefits:
      "Non-ferric formulation prevents water discolouration; rapid flocculation.",
    is_featured: true,
    is_popular: true,
    in_stock: true,
  },
  {
    id: 4,
    name: "Calcium Hypochlorite 70% (Granular Chlorine)",
    slug: "calcium-hypochlorite-70-granular-chlorine",
    cas_number: "7778-54-3",
    chemical_formula: "Ca(ClO)2",
    synonyms: "HTH Chlorine, Hypo, Bleaching Powder",
    molecular_weight: "142.98 g/mol",
    grade: "Technical",
    purity_percentage: "70.0% available chlorine min",
    appearance: "White granular powder",
    density: "2.35 g/cm³",
    category_name: "Water Treatment Chemicals",
    category_slug: "water-treatment-chemicals",
    industries_names: [
      "Water Treatment",
      "Food Processing & Beverage",
      "Pharmaceuticals & Healthcare",
    ],
    ghs_hazard_class:
      "Oxidising Solid Category 2, Acute Toxicity Category 4, Skin Corrosion Category 1B",
    hazard_statements:
      "H272: May intensify fire; oxidiser. H302: Harmful if swallowed. H314: Causes severe skin burns.",
    un_number: "UN 2880",
    storage_conditions:
      "Store in original drums in a cool, shaded area away from heat and combustibles.",
    packaging_options: "45kg plastic drums with inner liner",
    description:
      "High-test 70% granular calcium hypochlorite for swimming pool disinfection, drinking water treatment, hospital sanitisation and food factory hygiene.",
    technical_overview:
      "Potent chlorine-releasing biocide with fast bactericidal and virucidal efficacy.",
    applications:
      "Pool shock chlorination, municipal water chlorination, dairy equipment sanitisation.",
    benefits: "70% active chlorine, stable shelf life, dust-reduced process.",
    is_featured: true,
    is_popular: true,
    in_stock: true,
  },
  {
    id: 5,
    name: "Linear Alkyl Benzene Sulphonic Acid (LABSA 96%)",
    slug: "linear-alkyl-benzene-sulphonic-acid-labsa-96",
    cas_number: "27176-87-0",
    chemical_formula: "CH3(CH2)11C6H4SO3H",
    synonyms: "LABSA, Dodecylbenzene Sulfonic Acid",
    molecular_weight: "326.49 g/mol",
    grade: "Industrial",
    purity_percentage: "96.0% min",
    appearance: "Viscous brown liquid",
    density: "1.06 g/cm³",
    category_name: "Surfactants & Detergent Raws",
    category_slug: "surfactants-detergent-raws",
    industries_names: ["Cleaning & Detergents", "Cosmetics & Personal Care"],
    ghs_hazard_class: "Acute Toxicity Category 4, Skin Corrosion Category 1C",
    hazard_statements:
      "H302: Harmful if swallowed. H314: Causes severe skin burns and eye damage.",
    un_number: "UN 2586",
    storage_conditions:
      "Store in plastic drums or stainless steel tanks in dry conditions.",
    packaging_options: "210kg plastic drums, 1000kg IBC totes",
    description:
      "Core anionic surfactant for liquid detergents, dishwashing liquids, washing powders and industrial degreasers, offering strong foaming and soil suspension.",
    technical_overview:
      "Sulfonated linear alkylbenzene providing high biodegradability and detergency.",
    applications:
      "Laundry powder, dishwashing liquid, car wash shampoo, industrial floor cleaners.",
    benefits: "96% active content, low free oil, fast alkali neutralisation.",
    is_featured: true,
    is_popular: true,
    in_stock: true,
  },
  {
    id: 6,
    name: "Citric Acid Anhydrous (Food Grade)",
    slug: "citric-acid-anhydrous-monohydrate-food-grade",
    cas_number: "77-92-9",
    chemical_formula: "C6H8O7",
    synonyms: "2-hydroxypropane-1,2,3-tricarboxylic acid",
    molecular_weight: "192.12 g/mol",
    grade: "Food",
    purity_percentage: "99.5% – 100.5% BP/USP/FCC",
    appearance: "White translucent crystalline powder",
    density: "1.66 g/cm³",
    category_name: "Food Preservatives & Additives",
    category_slug: "food-preservatives-additives",
    industries_names: [
      "Food Processing & Beverage",
      "Pharmaceuticals & Healthcare",
      "Cosmetics & Personal Care",
    ],
    ghs_hazard_class: "Eye Irritation Category 2",
    hazard_statements: "H319: Causes serious eye irritation.",
    un_number: "Not restricted for transport",
    storage_conditions:
      "Store in a dry room away from high humidity to prevent caking.",
    packaging_options: "25kg multi-wall paper bags",
    description:
      "Premium food grade citric acid used as an acidulant, flavour enhancer, antioxidant synergist and pH buffer in soft drinks, juices, jams, confectionery and pharmaceuticals.",
    technical_overview:
      "Natural organic acid with strong chelating action and a crisp sour taste.",
    applications:
      "Beverage acidifier, candy preservation, effervescent tablets, cosmetic pH adjustment.",
    benefits: "BP/USP/FCC compliant, non-GMO, bright white crystals.",
    is_featured: true,
    is_popular: true,
    in_stock: true,
  },
];
