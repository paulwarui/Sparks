import type { Metadata } from "next";
import { SITE_URL, company, contact, social } from "./site";
import type { Article, Chemical } from "./types";

/**
 * Builds page metadata with a canonical URL always set. Canonicals matter
 * disproportionately here because the catalogue is filterable — without them
 * every `?grade=`/`?industry=` permutation becomes a duplicate-content page.
 */
export function buildMetadata({
  title,
  description,
  path,
  image,
  keywords,
  type = "website",
  noIndex = false,
  publishedTime,
  authors,
}: {
  title: string;
  description: string;
  path: string;
  image?: string;
  keywords?: string[];
  type?: "website" | "article";
  noIndex?: boolean;
  publishedTime?: string;
  authors?: string[];
}): Metadata {
  const url = `${SITE_URL}${path}`;
  const ogImage = image ?? `${SITE_URL}/og-image.png`;

  return {
    title,
    description,
    keywords,
    alternates: { canonical: url },
    robots: noIndex
      ? { index: false, follow: false }
      : {
          index: true,
          follow: true,
          googleBot: {
            index: true,
            follow: true,
            "max-image-preview": "large",
            "max-snippet": -1,
            "max-video-preview": -1,
          },
        },
    openGraph: {
      title,
      description,
      url,
      siteName: company.name,
      locale: "en_KE",
      type,
      images: [{ url: ogImage, width: 1200, height: 630, alt: title }],
      ...(publishedTime && { publishedTime }),
      ...(authors && { authors }),
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      images: [ogImage],
    },
  };
}

/* -------------------------------------------------------------------------- */
/*  Structured data builders                                                  */
/* -------------------------------------------------------------------------- */

export function organizationSchema() {
  return {
    "@context": "https://schema.org",
    "@type": "Organization",
    "@id": `${SITE_URL}/#organization`,
    name: company.legalName,
    alternateName: company.name,
    url: SITE_URL,
    logo: {
      "@type": "ImageObject",
      url: `${SITE_URL}/icon-512.png`,
      width: 512,
      height: 512,
    },
    description: company.description,
    foundingDate: String(company.foundingYear),
    email: contact.email,
    telephone: contact.phone,
    address: {
      "@type": "PostalAddress",
      streetAddress: contact.address.street,
      addressLocality: contact.address.locality,
      addressRegion: contact.address.region,
      postalCode: contact.address.postalCode,
      addressCountry: contact.address.country,
    },
    sameAs: [social.linkedin, social.twitter, social.facebook, social.instagram],
    contactPoint: [
      {
        "@type": "ContactPoint",
        telephone: contact.phone,
        contactType: "sales",
        email: contact.email,
        areaServed: ["KE", "UG", "TZ", "RW", "BI", "SS", "ET"],
        availableLanguage: ["en", "sw"],
      },
      {
        "@type": "ContactPoint",
        telephone: contact.emergency,
        contactType: "emergency",
        contactOption: "TollFree",
        areaServed: "KE",
      },
    ],
  };
}

export function localBusinessSchema() {
  return {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    "@id": `${SITE_URL}/#localbusiness`,
    name: company.legalName,
    image: `${SITE_URL}/icon-512.png`,
    url: SITE_URL,
    telephone: contact.phone,
    email: contact.email,
    priceRange: "$$",
    address: {
      "@type": "PostalAddress",
      streetAddress: contact.address.street,
      addressLocality: contact.address.locality,
      addressRegion: contact.address.region,
      postalCode: contact.address.postalCode,
      addressCountry: contact.address.country,
    },
    geo: {
      "@type": "GeoCoordinates",
      latitude: contact.geo.latitude,
      longitude: contact.geo.longitude,
    },
    openingHours: contact.openingHoursSpec,
    areaServed: [
      "Kenya",
      "Uganda",
      "Tanzania",
      "Rwanda",
      "Burundi",
      "South Sudan",
      "Ethiopia",
    ],
  };
}

export function websiteSchema() {
  return {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "@id": `${SITE_URL}/#website`,
    url: SITE_URL,
    name: company.name,
    publisher: { "@id": `${SITE_URL}/#organization` },
    potentialAction: {
      "@type": "SearchAction",
      target: {
        "@type": "EntryPoint",
        urlTemplate: `${SITE_URL}/products?q={search_term_string}`,
      },
      "query-input": "required name=search_term_string",
    },
  };
}

/**
 * Product schema for a chemical. Deliberately omits `offers.price` — Sparks
 * quotes per enquiry, and publishing a fabricated price would be both
 * dishonest and a Merchant-listing policy violation.
 */
export function productSchema(chemical: Chemical) {
  const url = `${SITE_URL}/products/${chemical.slug}`;
  return {
    "@context": "https://schema.org",
    "@type": "Product",
    "@id": `${url}/#product`,
    name: chemical.name,
    description: chemical.description,
    sku: chemical.slug,
    category: chemical.category_name,
    ...(chemical.image_url && { image: [chemical.image_url] }),
    brand: { "@type": "Brand", name: company.name },
    manufacturer: { "@id": `${SITE_URL}/#organization` },
    url,
    additionalProperty: [
      { name: "CAS Number", value: chemical.cas_number },
      { name: "Chemical Formula", value: chemical.chemical_formula },
      { name: "Grade", value: chemical.grade },
      { name: "Purity", value: chemical.purity_percentage },
      { name: "Appearance", value: chemical.appearance },
      ...(chemical.molecular_weight
        ? [{ name: "Molecular Weight", value: chemical.molecular_weight }]
        : []),
      ...(chemical.un_number
        ? [{ name: "UN Number", value: chemical.un_number }]
        : []),
    ].map((prop) => ({
      "@type": "PropertyValue",
      name: prop.name,
      value: prop.value,
    })),
    offers: {
      "@type": "Offer",
      url,
      availability: chemical.in_stock
        ? "https://schema.org/InStock"
        : "https://schema.org/PreOrder",
      priceCurrency: "KES",
      priceSpecification: {
        "@type": "PriceSpecification",
        // Quote-based pricing: signal that a price exists on enquiry rather
        // than inventing a number.
        valueAddedTaxIncluded: false,
      },
      seller: { "@id": `${SITE_URL}/#organization` },
      areaServed: ["KE", "UG", "TZ", "RW", "BI", "SS", "ET"],
    },
  };
}

export function faqSchema(faqs: { question: string; answer: string }[]) {
  return {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map((faq) => ({
      "@type": "Question",
      name: faq.question,
      acceptedAnswer: { "@type": "Answer", text: faq.answer },
    })),
  };
}

export function articleSchema(article: Article) {
  const url = `${SITE_URL}/blog/${article.slug}`;
  return {
    "@context": "https://schema.org",
    "@type": "BlogPosting",
    "@id": `${url}/#article`,
    headline: article.title,
    description: article.summary,
    ...(article.image_url && { image: [article.image_url] }),
    datePublished: article.published_at,
    dateModified: article.published_at,
    author: {
      "@type": "Person",
      name: article.author,
      jobTitle: article.author_role,
    },
    publisher: { "@id": `${SITE_URL}/#organization` },
    mainEntityOfPage: { "@type": "WebPage", "@id": url },
    articleSection: article.category_name,
    wordCount: article.content?.split(/\s+/).length,
  };
}

/** Generates buyer-intent FAQs for a chemical, used for UI and FAQ schema. */
export function chemicalFaqs(chemical: Chemical) {
  const faqs = [
    {
      question: `What is the CAS number of ${chemical.name}?`,
      answer: `The CAS registry number for ${chemical.name} is ${chemical.cas_number}, with the chemical formula ${chemical.chemical_formula}${
        chemical.molecular_weight
          ? ` and a molecular weight of ${chemical.molecular_weight}`
          : ""
      }.`,
    },
    {
      question: `What packaging is ${chemical.name} supplied in?`,
      answer: `Sparks Chemicals supplies ${chemical.name} in ${chemical.packaging_options}. Bulk and custom packaging can be arranged for contract volumes across East Africa.`,
    },
    {
      question: `What is ${chemical.name} used for?`,
      answer: chemical.applications,
    },
  ];

  if (chemical.storage_conditions) {
    faqs.push({
      question: `How should ${chemical.name} be stored?`,
      answer: chemical.storage_conditions,
    });
  }

  faqs.push({
    question: `Do you deliver ${chemical.name} outside Kenya?`,
    answer: `Yes. We deliver across Kenya, Uganda, Tanzania, Rwanda, Burundi, South Sudan and Ethiopia, and prepare full export documentation for other destinations. Request a quotation for delivered pricing to your location.`,
  });

  return faqs;
}
