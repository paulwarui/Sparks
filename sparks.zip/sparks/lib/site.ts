/**
 * Company identity, contact details and navigation.
 *
 * Every value is sourced from the project-root `.env` (via NEXT_PUBLIC_*
 * variables) so nothing here is hardcoded — the same build can be deployed for
 * a different address, phone number or domain by changing one file.
 *
 * These values appear in both the UI and the structured data, so keeping them
 * in a single place is also what stops name/address/phone drift, which Google
 * penalises.
 *
 * NOTE: NEXT_PUBLIC_* variables are inlined at build time, so they must be
 * referenced as full literals (`process.env.NEXT_PUBLIC_X`) rather than looked
 * up dynamically.
 */

function env(value: string | undefined, fallback: string): string {
  const trimmed = value?.trim();
  return trimmed ? trimmed : fallback;
}

/** Splits a comma-separated env value into a trimmed list. */
function envList(value: string | undefined, fallback: string): string[] {
  return env(value, fallback)
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);
}

export const SITE_URL = env(
  process.env.NEXT_PUBLIC_SITE_URL,
  "http://localhost:3000",
).replace(/\/$/, "");

export const company = {
  legalName: env(
    process.env.NEXT_PUBLIC_COMPANY_LEGAL_NAME,
    "Sparks Chemicals Ltd",
  ),
  name: env(process.env.NEXT_PUBLIC_COMPANY_NAME, "Sparks Chemicals"),
  tagline: env(process.env.NEXT_PUBLIC_COMPANY_TAGLINE, "Chemical Experts"),
  descriptor: env(
    process.env.NEXT_PUBLIC_COMPANY_DESCRIPTOR,
    "Kenya • East Africa • Global",
  ),
  foundingYear: Number(
    env(process.env.NEXT_PUBLIC_COMPANY_FOUNDING_YEAR, "2013"),
  ),
  description:
    "Sparks Chemicals is East Africa's technology-driven chemical supplier — industrial, laboratory, food-grade, water treatment, agricultural and pharmaceutical chemicals delivered across Kenya, Uganda, Tanzania, Rwanda and beyond.",
  shortDescription:
    "Premium industrial, laboratory, food, water treatment, agricultural and pharmaceutical chemicals.",
} as const;

const phone = env(process.env.NEXT_PUBLIC_CONTACT_PHONE, "+254 700 000 000");
const emergency = env(
  process.env.NEXT_PUBLIC_CONTACT_EMERGENCY,
  "+254 700 000 911",
);
const email = env(
  process.env.NEXT_PUBLIC_CONTACT_EMAIL,
  "sales@sparkschemicals.co.ke",
);
const whatsapp = env(process.env.NEXT_PUBLIC_WHATSAPP_NUMBER, "254700000000");

/** Strips spaces and punctuation so a display number works in a tel: link. */
const telHref = (value: string) => `tel:${value.replace(/[^\d+]/g, "")}`;

export const contact = {
  phone,
  phoneHref: telHref(phone),
  phoneSecondary: env(
    process.env.NEXT_PUBLIC_CONTACT_PHONE_SECONDARY,
    "+254 733 000 000",
  ),
  emergency,
  emergencyHref: telHref(emergency),
  whatsapp,
  whatsappHref: `https://wa.me/${whatsapp}`,
  email,
  emailHref: `mailto:${email}`,
  technicalEmail: env(
    process.env.NEXT_PUBLIC_CONTACT_TECHNICAL_EMAIL,
    "technical@sparkschemicals.co.ke",
  ),
  address: {
    street: env(
      process.env.NEXT_PUBLIC_ADDRESS_STREET,
      "Enterprise Road, Industrial Area",
    ),
    locality: env(process.env.NEXT_PUBLIC_ADDRESS_LOCALITY, "Nairobi"),
    region: env(process.env.NEXT_PUBLIC_ADDRESS_REGION, "Nairobi County"),
    postalCode: env(process.env.NEXT_PUBLIC_ADDRESS_POSTAL_CODE, "00500"),
    country: env(process.env.NEXT_PUBLIC_ADDRESS_COUNTRY, "KE"),
    countryName: env(process.env.NEXT_PUBLIC_ADDRESS_COUNTRY_NAME, "Kenya"),
  },
  geo: {
    latitude: Number(env(process.env.NEXT_PUBLIC_GEO_LATITUDE, "-1.3031")),
    longitude: Number(env(process.env.NEXT_PUBLIC_GEO_LONGITUDE, "36.8494")),
  },
  hours: [
    { days: "Monday – Friday", time: "8:00 AM – 6:00 PM" },
    { days: "Saturday", time: "8:00 AM – 1:00 PM" },
    { days: "Sunday & Public Holidays", time: "Emergency dispatch only" },
  ],
  /** schema.org openingHours format */
  openingHoursSpec: ["Mo-Fr 08:00-18:00", "Sa 08:00-13:00"],
} as const;

export const social = {
  linkedin: env(
    process.env.NEXT_PUBLIC_SOCIAL_LINKEDIN,
    "https://www.linkedin.com/company/sparkschemicals",
  ),
  twitter: env(
    process.env.NEXT_PUBLIC_SOCIAL_TWITTER,
    "https://twitter.com/sparkschemicals",
  ),
  facebook: env(
    process.env.NEXT_PUBLIC_SOCIAL_FACEBOOK,
    "https://www.facebook.com/sparkschemicals",
  ),
  instagram: env(
    process.env.NEXT_PUBLIC_SOCIAL_INSTAGRAM,
    "https://www.instagram.com/sparkschemicals",
  ),
} as const;

/** Markets served — drives the footer, about page and structured data. */
export const markets = envList(
  process.env.NEXT_PUBLIC_MARKETS,
  "Kenya,Uganda,Tanzania,Rwanda,Burundi,South Sudan,Ethiopia,Somalia,DR Congo,Zambia",
);

export const trustMetrics = [
  {
    value: env(process.env.NEXT_PUBLIC_METRIC_PRODUCTS, "1,500+"),
    label: "Chemical products catalogued",
  },
  {
    value: env(process.env.NEXT_PUBLIC_METRIC_COUNTRIES, "12"),
    label: "Countries served across Africa",
  },
  {
    value: env(process.env.NEXT_PUBLIC_METRIC_YEARS, "10+"),
    label: "Years of technical trading",
  },
  { value: "24/7", label: "Technical & logistics dispatch" },
] as const;

/**
 * Certifications, configured as "Name|Detail" pairs. Only advertise
 * accreditations actually held — these are published as fact on the site.
 */
export const certifications = envList(
  process.env.NEXT_PUBLIC_CERTIFICATIONS,
  "ISO 9001:2015|Quality management system,KEBS Approved|Kenya Bureau of Standards,NEMA Licensed|Environmental handling permit,GHS Compliant|Globally harmonised labelling,PCPB Registered|Pest Control Products Board,REACH Aligned|EU import documentation",
).map((entry) => {
  const [name, detail = ""] = entry.split("|");
  return { name: name.trim(), detail: detail.trim() };
});

export type NavLink = {
  href: string;
  label: string;
  description?: string;
};

export const primaryNav: NavLink[] = [
  { href: "/products", label: "Chemicals" },
  { href: "/industries", label: "Industries" },
  { href: "/blog", label: "Knowledge" },
  { href: "/about", label: "About" },
  { href: "/contact", label: "Contact" },
];

export const footerNav: { title: string; links: NavLink[] }[] = [
  {
    title: "Catalogue",
    links: [
      { href: "/products", label: "All chemicals" },
      { href: "/products?grade=Food", label: "Food grade" },
      { href: "/products?grade=AR", label: "Laboratory reagents" },
      { href: "/products?grade=Pharma", label: "Pharmaceutical grade" },
      { href: "/industries/water-treatment", label: "Water treatment" },
    ],
  },
  {
    title: "Company",
    links: [
      { href: "/about", label: "About Sparks" },
      { href: "/industries", label: "Industries served" },
      { href: "/blog", label: "Knowledge centre" },
      { href: "/contact", label: "Contact sales" },
      { href: "/quote", label: "Request a quotation" },
    ],
  },
  {
    title: "Support",
    links: [
      { href: "/contact#technical", label: "Technical support" },
      { href: "/contact#emergency", label: "Emergency response" },
      { href: "/blog", label: "Safety guidance" },
      { href: "/sitemap.xml", label: "Sitemap" },
    ],
  },
];
