export type Grade = "Technical" | "Food" | "AR" | "Pharma" | "Industrial";

export interface Industry {
  id: number;
  name: string;
  slug: string;
  icon: string;
  description: string;
  hero_title?: string;
  key_challenges?: string;
  chemical_count?: number;
}

export interface Category {
  id: number;
  name: string;
  slug: string;
  description?: string;
  image_url?: string;
  chemical_count?: number;
}

export interface Chemical {
  id: number;
  name: string;
  slug: string;
  cas_number: string;
  chemical_formula: string;
  synonyms?: string;
  molecular_weight?: string;
  grade: Grade;
  purity_percentage: string;
  appearance: string;
  density?: string;
  category_name?: string;
  category_slug?: string;
  industries_names?: string[];
  ghs_hazard_class?: string;
  hazard_statements?: string;
  un_number?: string;
  storage_conditions?: string;
  packaging_options: string;
  description: string;
  technical_overview?: string;
  applications: string;
  benefits?: string;
  image_url?: string;
  sds_url?: string;
  coa_url?: string;
  is_featured?: boolean;
  is_popular?: boolean;
  in_stock?: boolean;
}

/** Lightweight shape returned by the autocomplete endpoint. */
export interface ChemicalSuggestion {
  id: number;
  name: string;
  slug: string;
  cas_number: string;
  chemical_formula: string;
  grade: string;
  category?: string;
}

export interface QuoteLineItem {
  slug: string;
  name: string;
  cas_number: string;
  grade: string;
  quantity: string;
  packaging: string;
}

export interface Article {
  id: number;
  title: string;
  slug: string;
  category_name?: string;
  category_slug?: string;
  summary: string;
  content: string;
  author: string;
  author_role: string;
  image_url?: string;
  read_time_minutes: number;
  is_featured?: boolean;
  published_at: string;
}

export interface ArticleCategory {
  id: number;
  name: string;
  slug: string;
  description?: string;
}

export interface ChemicalQuery {
  q?: string;
  cas?: string;
  formula?: string;
  industry?: string;
  category?: string;
  grade?: string;
  featured?: boolean;
}
