import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/** "Sodium Hydroxide, Lye, Caustic" -> ["Sodium Hydroxide", "Lye", "Caustic"] */
export function splitList(value?: string | null): string[] {
  if (!value) return [];
  return value
    .split(/[,;\n•]+/)
    .map((item) => item.trim())
    .filter(Boolean);
}

/** Splits prose written as sentences or bullets into displayable points. */
export function toBullets(value?: string | null): string[] {
  if (!value) return [];
  const byLine = value
    .split(/\n+|•/)
    .map((s) => s.trim())
    .filter(Boolean);
  if (byLine.length > 1) return byLine;
  return value
    .split(/(?<=\.)\s+(?=[A-Z0-9])/)
    .map((s) => s.trim())
    .filter(Boolean);
}

export function formatDate(input: string) {
  const date = new Date(input);
  if (Number.isNaN(date.getTime())) return "";
  return date.toLocaleDateString("en-KE", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

/**
 * Renders a chemical formula with proper subscripts — "Al2(SO4)3" reads as a
 * real formula rather than a string of digits. Returns segments so callers can
 * emit semantic <sub> elements instead of dangerously setting HTML.
 */
export function formulaSegments(formula: string) {
  const segments: { text: string; sub: boolean }[] = [];
  const pattern = /(\d+)|([^\d]+)/g;
  let match: RegExpExecArray | null;
  while ((match = pattern.exec(formula)) !== null) {
    if (match[1]) segments.push({ text: match[1], sub: true });
    else segments.push({ text: match[2], sub: false });
  }
  return segments;
}

export function truncate(value: string, max: number) {
  if (value.length <= max) return value;
  return `${value.slice(0, max - 1).trimEnd()}…`;
}
