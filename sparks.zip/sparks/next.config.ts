import type { NextConfig } from "next";

/**
 * Remote image hosts are configured from the environment so a deployment can
 * pull product photography from whichever CDN or object store it uses without
 * editing code:
 *
 *   NEXT_IMAGE_HOSTS=images.unsplash.com,cdn.example.com
 */
const imageHosts = (process.env.NEXT_IMAGE_HOSTS ?? "")
  .split(",")
  .map((host) => host.trim())
  .filter(Boolean);

const nextConfig: NextConfig = {
  // Emits a self-contained server bundle so the runtime image doesn't need
  // node_modules — keeps the production container small.
  output: "standalone",

  poweredByHeader: false,
  compress: true,

  images: {
    formats: ["image/avif", "image/webp"],
    remotePatterns: imageHosts.flatMap((hostname) => [
      { protocol: "https" as const, hostname },
      { protocol: "http" as const, hostname },
    ]),
  },

  async headers() {
    return [
      {
        source: "/:path*",
        headers: [
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          {
            key: "Permissions-Policy",
            value: "camera=(), microphone=(), geolocation=()",
          },
        ],
      },
    ];
  },
};

export default nextConfig;
